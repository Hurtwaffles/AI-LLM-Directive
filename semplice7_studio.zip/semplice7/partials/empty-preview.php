<div class="no-content">
	<div class="title bold">Empty content</div>
	<div class="text regular">Before getting a preview of your page or project please add<br /> some content in our editor, save it and hit preview again.</div>
</div>