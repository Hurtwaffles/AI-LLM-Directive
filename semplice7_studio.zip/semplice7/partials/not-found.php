<div class="no-content">
	<div class="title bold">404 - Not found</div>
	<div class="text regular">This page could not be found.<br />Continue to the <a href="<?php echo home_url(); ?>">Homepage</a></div>
</div>