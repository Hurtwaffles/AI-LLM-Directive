<div class="no-content">
	<div class="title bold">No Posts</div>
	<div class="text regular">You have no posts in your blog.<br />Start adding some posts in your dashboard.</div>
</div>