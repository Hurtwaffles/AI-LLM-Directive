<div class="no-content">
	<div class="title bold">Empty content</div>
	<div class="text regular">It appears that you have a totally empty page. Please<br />visit our editor and add some content to your page.</div>
</div>