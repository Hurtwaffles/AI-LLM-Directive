<?php
	use Semplice\Admin\Customize;
	use Semplice\Helper\Get;
?>
<template id="smp-tpl-navigations-toolbar">
	<div class="navigations-toolbar admin-column">
		<div class="navigations-back icon-button">
			<button class="click-handler" data-handler="run" data-action-type="customize" data-setting-type="navigations" data-action="toggleMode" data-mode="list"><?php echo Get::svg('admin', 'customize/navigations/back'); ?> Back</button>
		</div>
		<div class="navigations-add">
			<ul class="modules">
				<?php
					$modules = array('menu', 'link', 'text', 'image', 'button', 'spacer', 'lottie', 'code');
					foreach($modules as $module) {
						echo '<li class="has-tooltip" data-tooltip="' . ucfirst($module) . '" data-tooltip-settings="bottom,center,auto" data-tooltip-theme="invert"><a class="add-nav-content" data-module="' . $module . '">' . Get::svg('admin', 'customize/navigations/modules/' . $module) . '</a></li>';
					}
				?>
			</ul>
		</div>
		<div class="navigations-reorder icon-button">
			<button class="click-handler nav-reorder" data-handler="run" data-action-type="customize" data-setting-type="navigations" data-action="reOrder" data-mode="order">Re-Order</button>
			<p class="reorder-note">Empty rows &amp; columns will get removed automatically on save.</p>
		</div>
		<div class="navigations-view-label">
			<span>Switch View</span>
		</div>
		<div class="navigations-view">
			<button class="click-handler active-view has-tooltip" data-handler="run" data-action-type="customize" data-setting-type="navigations" data-action="toggleView" data-view="navbar" data-tooltip="Top & Bottom Navbars" data-tooltip-settings="bottom,center,auto" data-tooltip-theme="invert">Navbars</button>
			<button class="click-handler has-tooltip" data-handler="run" data-action-type="customize" data-setting-type="navigations" data-action="toggleView" data-view="overlay" data-tooltip="Hamburger Overlay" data-tooltip-settings="bottom,center,auto" data-tooltip-theme="invert">Overlay</button>
		</div>
		<div class="navigations-settings icon-button icon-only">
			<button class="nav-settings"><?php echo Get::svg('admin', 'customize/navigations/settings'); ?></button>
		</div>
		<?php echo Customize::actions('navigations-edit'); ?>
	</div>
</template>

<template id="smp-tpl-navigations-list-item">
	<li id="{{id}}" class="navigation{{class}}">
		<div class="navigation-thumbnail">
			<img src="{{thumbnail}}">
			<div class="actions">
				<ul>
					<li class="nav-list-edit has-tooltip" data-tooltip="Edit" data-tooltip-settings="top,center,auto" data-tooltip-theme="invert">
						<button class="click-handler" data-handler="run" data-action-type="customize" data-setting-type="navigations" data-action="toggleMode" data-mode="edit" data-nav-id="{{id}}"><?php echo Get::svg('admin', 'post/edit'); ?></button>
					</li>
					<li class="nav-list-duplicate has-tooltip" data-tooltip="Duplicate" data-tooltip-settings="top,center,auto" data-tooltip-theme="invert">
						<button class="click-handler" data-handler="run" data-action-type="customize" data-setting-type="navigations" data-action="duplicateNav" data-nav-id="{{id}}"><?php echo Get::svg('admin', 'post/duplicate'); ?></button>
					</li>
					<li class="nav-list-delete has-tooltip" data-tooltip="Delete" data-tooltip-settings="top,center,auto" data-tooltip-theme="invert">
						<button class="click-handler" data-handler="run" data-action-type="dialog" data-setting-type="core" data-action="deleteNav" data-nav-id="{{id}}"><?php echo Get::svg('admin', 'post/delete'); ?></button>
					</li>
					<li class="nav-list-default has-tooltip" data-tooltip="Make default" data-tooltip-settings="top,center,auto" data-tooltip-theme="invert">
						<button class="click-handler" data-handler="run" data-action-type="customize" data-setting-type="navigations" data-action="defaultNav" data-nav-id="{{id}}"><?php echo Get::svg('admin', 'customize/navigations/default'); ?></button>
					</li>
				</ul>
			</div>
		</div>
		<a class="click-handler" data-handler="run" data-action-type="customize" data-setting-type="navigations" data-action="toggleMode" data-mode="edit" data-nav-id="{{id}}">{{name}}{{defaultNav}}</a>
		{{legacy}}
	</li>
</template>

<template id="smp-tpl-navigations-edit">
	<div class="smp-browser" data-view="navbar">
		<div class="inner">{{content}}</div>
	</div>
</template>

<template id="smp-tpl-navigations-presets">
	<div class="navigation-presets admin-container{{classes}}">
		<div class="admin-row header-row">
			<div class="admin-header admin-column">
				<div class="heading">
					<h2 class="admin-title">Select your navigation preset</h2>
				</div>
				<div class="actions preset-actions">
				<button class="click-handler close-presets" data-handler="run" data-action-type="customize" data-setting-type="navigations" data-action="addNavDialog" data-state="close">Close</button>
				</div>
			</div>
		</div>
		<?php
			$presets = Get::nav_preset_ids();
			// iterate presets
			$presets_html = '<div class="admin-row">';
			$count = 1;
			foreach($presets as $preset_id => $preset_num) {
				$presets_html .= '
					<div class="preset admin-column add-nav" data-preset="' . $preset_id . '" data-xl-width="4">
						<div class="preset-img">
							<img src="' . SEMPLICE_URI . '/assets/images/admin/customize/navigations/presets/' . $preset_num . '.png">
						</div>
						<div class="preset-info">' . ucwords(str_replace('_', ' ', ($preset_id == 'scratch') ? 'From Scratch' : $preset_id)) . '</div>
					</div>';
				if($count % 3 == 0) {
					$presets_html .= '</div><div class="admin-row">';
				}
				$count++;
			}
			// close last row
			$presets_html .= '</div>';
		?>
		<div class="presets">
			<?php echo $presets_html; ?>
		</div>
	</div>
</template>