<?php
	use Semplice\Helper\Get;
	use Semplice\Helper\PostQueries;
?>

<template id="smp-tpl-ep-item">
	<li class="ep-item" data-item-id="{{itemId}}" data-expand-type="{{expandType}}">
		<div class="ep-item-inner">
			<div class="ep-item-meta ep-item-expand">
				<div class="ep-item-handle"></div>
				<div class="ep-item-title">
					<p>{{title}}</p>
				</div>
				<div class="ep-item-actions">
					<div class="ep-item-action ep-item-remove click-handler" data-handler="run" data-action-type="{{expandType}}" data-action="{{action}}" {{actionids}}></div>
					<div class="ep-item-action"></div>
				</div>
			</div>
			<div class="ep-item-options"></div>
		</div>
	</li>
</template>

<template id="smp-tpl-ep-items-dropdown">	
	<div class="ep-items-dropdown">
		<div class="ep-items-close click-handler" data-handler="run" data-action-type="{{expandType}}" data-action="hideAddItemDropdown"><?php echo Get::svg('admin', 'edit-popup/expand/close'); ?></div>
		<div class="ep-items-input"><input class="ep-items-search" type="text" placeholder="Search for pages or projects"></div>
		<ul>{{content}}</ul>
	</div>
</template>

<template id="smp-tpl-ep-add-post">
	<li class="ep-add-item" data-item-id="{{postId}}" data-item-title="{{postTitleLowerCase}}" data-id="{{contentId}}">
		<div class="ep-add-meta">
			<div class="title">
				<p>{{postTitle}}</p>
			</div>
		</div>
	</li>
</template>

<template id="smp-tpl-ep-profiles-dropdown">	
	<?php
		$profiles = Get::social_profiles();
		// output
		$output = '';
		// iterate profiles
		foreach ($profiles as $profile_id => $profile) {
			$output .= '
				<li class="ep-add-profile" data-profile="' . $profile_id . '" data-post-title="' . $profile_id . '" data-id="{{id}}" data-item-title="' . $profile['name'] . '">
					' . $profile['svg'] . '
				</li>
			';
		}
		// return
		echo $output;
	?>
</template>

<template id="smp-tpl-ep-post-options">
	<option-line>
		<option-input data-size="4" data-var-support="false">
			<label>Custom Thumbnail</label>
			{{upload}}
		</option-input>
		<option-input data-size="2" data-var-support="false">
			<label>Classes</label>
			<input type="text" name="custom_class" data-option-id="option_epposclas" data-sub-type="apgPostsOption" data-type="apg" data-save-option="true" data-target="{{postId}}" value="{{custom_class}}" placeholder="Classes" data-id="{{contentId}}" data-input-type="text">
		</option-input>
		{{link}}
	</option-line>
</template>

</template>
<template id="smp-tpl-ep-post-options-link">
	<option-input data-size="2" data-var-support="false">
		<label>External Link</label>
		<input type="text" name="link" data-option-id="option_epposlink" data-sub-type="apgPostsOption" data-type="apg" data-save-option="true" value="{{link}}" data-target="{{postId}}" placeholder="https://www.semplice.com" data-id="{{contentId}}" data-input-type="text">
	</option-input>
</template>

<template id="smp-tpl-ep-profile-options">
	<option-line>
		<option-input data-size="4" data-var-support="false">
			<label>{{usernamePrefix}}</label>
			<input type="text" name="username" data-option-id="option_spousrnam" data-sub-type="profileOption" data-type="socialprofiles" value="{{username}}" placeholder="{{usernamePrefix}}" data-id="{{id}}" data-profile="{{profile}}" data-input-type="text">
		</option-input>
		<option-input data-size="2" data-var-support="false">
			<label>Link</label>
			<div class="color-picker {{pickerId}}" data-picker-id="{{pickerId}}" data-holder="ep" data-show-color="true" data-mode="solid">
				<div class="color-preview" style="background: {{color}};"></div>
				<span class="solid">#</span>
				<input type="text" value="{{color}}" data-input-type="color" data-gradient="false" data-sub-type="profileOption" data-option-id="option_spolnkcol" data-type="socialprofiles" name="color" data-profile="{{profile}}" data-id="{{id}}">
			</div>
		</option-input>
		<option-input data-size="2" data-var-support="false">
			<label>Hover</label>
			<div class="color-picker {{pickerHoverId}}" data-picker-id="{{pickerHoverId}}" data-holder="ep" data-show-color="true" data-mode="solid">
				<div class="color-preview" style="background: {{hoverColor}};"></div>
				<span class="solid">#</span>
				<input type="text" value="{{hoverColor}}" data-input-type="color" data-gradient="false" data-sub-type="profileOption" data-option-id="option_spohovcol" data-type="socialprofiles" name="hoverColor" data-profile="{{profile}}" data-id="{{id}}">
			</div>
		</option-input>
	</option-line>
</template>

<template id="smp-tpl-ep-menu-item">
	<li class="ep-item{{depth}}" data-menu-id="{{id}}" data-item-id="{{itemId}}" data-order="{{order}}">
		<div class="ep-item-inner">
			<div class="ep-item-meta ep-item-expand">
				<div class="ep-item-handle"></div>
				<div class="ep-item-title">
					<p>{{title}}</p>
				</div>
				<div class="ep-item-actions">
					<div class="ep-item-action ep-item-remove click-handler" data-handler="run" data-action-type="menu" data-action="removeItem" data-delete-id="{{itemId}}"></div>
					<div class="ep-item-action"></div>
				</div>
			</div>
			<div class="ep-menu-item-options"></div>
		</div>
	</li>
</template>

<template id="smp-tpl-ep-menu-items">
	<ul class="ep-menu-items">{{items}}</ul>
	<div class="ep-menu-actions" data-type="menu">
		<button class="menu-cancel click-handler" data-handler="run" data-action-type="menu" data-action="save" data-menu-id="{{id}}" data-mode="cancel">Cancel</button>
		<button class="menu-save click-handler" data-handler="run" data-action-type="menu" data-action="save" data-menu-id="{{id}}" data-mode="save">Save Menu</button>
	</div>
</template>

<template id="smp-tpl-add-menu-item">
	<div class="add-menu-item">
		<div class="title">
			<p>Add new item</p>
		</div>
		<div class="menu-item-options" data-link-type="page">
			<option-input>
				<label>Link Type</label>
				<div class="toggle-button menu-type-toggle" data-size="4" data-toggle-options='{"page": "Page", "project": "Project", "post", "Post", "custom": "Custom"}'>
					<div class="toggle-state"></div>
					<ul>
						<li class="selected">
							<button class="toggle-option" data-name="menu-link-type" data-input-type="toggleButton" data-val="page" data-inline="true">Page</button>
						</li>
						<li>
							<button class="toggle-option" data-name="menu-link-type" data-input-type="toggleButton" data-val="project" data-inline="true">Project</button>
						</li>
						<li>
							<button class="toggle-option" data-name="menu-link-type" data-input-type="toggleButton" data-val="post" data-inline="true">Post</button>
						</li>
						<li>
							<button class="toggle-option" data-name="menu-link-type" data-input-type="toggleButton" data-val="custom" data-inline="true">Custom</button>
						</li>
					</ul>
				</div>
			</option-input>
			{{postSelect}}	
			<option-input class="menu-custom">
				<label>Title</label>
				<input type="text" class="menu-item-title" placeholder="Title">
			</option-input>	
			<option-input class="menu-custom">
				<label>Link</label>
				<input type="text" class="menu-item-link" placeholder="https://www.semplice.com">
			</option-input>
		</div>
		<div class="ep-menu-actions" data-type="item">
			<button class="menu-cancel click-handler" data-handler="run" data-action-type="menu" data-action="saveItem" data-mode="cancel">Cancel</button>
			<button class="menu-save click-handler" data-handler="run" data-action-type="menu" data-action="saveItem" data-mode="save">Save</button>
		</div>
	</div>
</template>

<template id="smp-tpl-edit-menu-item">
	<option-input data-size="4">
			<label>Title</label>
			<input type="text" data-type="menuItem" data-name="title" placeholder="Title" value="{{title}}">
		</option-input>	
	<option-input data-size="4">
		<label>Target</label>
		<div class="toggle-button menu-target-toggle" data-size="2" data-toggle-options='{"_self": "Same Tab", "_blank": "New Tab"}'>
			<div class="toggle-state"></div>
			<ul>
				<li>
					<button class="toggle-option menu-target-option" data-type="menuItem" data-name="target" data-input-type="toggleButton" data-val="_self" data-inline="true">Same Tab</button>
				</li>
				<li>
					<button class="toggle-option menu-target-option" data-type="menuItem" data-name="target" data-input-type="toggleButton" data-val="_blank" data-inline="true">New Tab</button>
				</li>
			</ul>
		</div>
	</option-input>
	<option-input data-size="4">
		<label>CSS Classes</label>
		<input type="text" data-type="menuItem" data-name="classes" placeholder="css classes" value="{{classes}}">
	</option-input>
</template>

<template id="smp-tpl-select-taxonomy">
	<div class="select-taxonomy">
		<div class="content">
			<div class="ep-expand-search">
				<input type="text" class="taxonomy-search" placeholder="Search {{searchLabel}}" data-taxonomy="{{taxonomy}}">
			</div>
			<ul {{attributes}}>
			</ul>
		</div>
	</div>
</template>