<?php
	use Semplice\Helper\Get;
?>

<template id="smp-tpl-picker-addons">
	<div class="pcr-header">
		<ul>
			<li class="click-handler" data-handler="run" data-action-type="picker" data-action="changeMode" data-color-mode="solid">Solid</li>
			<li class="click-handler" data-handler="run" data-action-type="picker" data-action="changeMode" data-color-mode="linear">Linear</li>
			<li class="click-handler" data-handler="run" data-action-type="picker" data-action="changeMode" data-color-mode="radial">Radial</li>
			<li class="click-handler" data-handler="run" data-action-type="picker" data-action="changeMode" data-color-mode="mesh">Mesh</li>
		</ul>
	</div>
	<div class="pcr-gradient">
		<div class="gradient-bar" data-angle="{{angle}}" style="background: {{gradient}};"><div class="gradient-inner-bar">{{gradientHandles}}</div></div>
		<div class="gradient-angle"><div class="angle-circle"><div class="angle-dot" style="transform: rotate({{angle}}deg);"></div><div class="angle-debug">{{angle}}&deg;</div></div></div>
	</div>
	<div class="pcr-mesh">
		<div class="mesh-ep-preview"></div>
		<option-input>
			<div class="ep-button">
				<button class="click-handler edit-mesh" data-button-color="yellow" data-handler="run" data-action-type="mesh" data-action="init"><?php echo Get::svg('admin', 'edit'); ?><span>Edit Mesh Gradient</span></button>
			</div>
		</option-input>
	</div>
</template>

<template id="smp-tpl-empty-posts">
	<div class="no-posts">
		<div class="inner">
			<h3>Pro tip: To finish your portfolio,<br />start building your portfolio.</h3>
			<button class="click-handler" data-button-color="yellow" data-handler="run" data-action-type="dialog" data-setting-type="post" data-action="add" data-post-type="{{postType}}">Add a {{postType}}</button>
		</div>
	</div>
</template>
<template id="smp-tpl-empty-footers">
	<div class="no-footer">
		<h3>You have no footers added yet.<br>Start adding one by clicking below<br /></h3>
		<button class="click-handler" data-button-icon="plus" data-button-icon-color="white" data-button-color="dark-gray" data-handler="run" data-action-type="dialog" data-setting-type="post" data-action="add" data-post-type="footer"><span></span>Add footer</button>
	</div>
</template>