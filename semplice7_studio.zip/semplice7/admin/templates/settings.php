<?php
	use Semplice\Helper\Get;
?>
<template id="smp-tpl-settings">
	<div class="smp-settings admin-container" data-setting="{{setting}}" data-mode="{{mode}}">
		{{header}}
		<div class="admin-row settings-content settings-{{setting}}">
			{{content}}
		</div>
	</div>
</template>

<template id="smp-tpl-settings-header">
	<div class="admin-row header-row">
		<div class="admin-header admin-column settings-header">
			<ul class="settings-menu">
				<li><a href="#settings/general" data-setting="general">General</a></li>
				<li><a href="#settings/license" data-setting="license">License</a></li>
			</ul>
			{{actions}}
		</div>
	</div>
</template>

<template id="smp-tpl-semplice-activated">
	<div class="semplice-activated">
		<div class="license-meta">
			<p class="heading">About your license</p>
			<div class="meta-inner">
				<div class="meta-inner-content">
					<p><span>Current License</span><?php echo Get::svg('admin', 'settings/license/seven'); ?>{{license}}</p>
				</div>
				<div class="meta-inner-content">
					<p><span>Installed Version</span><?php echo SEMPLICE_VER ?></p>
				</div>
				<div class="meta-inner-content">
					<p><span>Status</span>{{status}}</p>
				</div>
				<div class="meta-inner-content">
					<p><span>Support</span><a href="https://help.semplice.com" target="_blank">Visit Helpdesk</a></p>
				</div>
			</div>
			<button class="click-handler release-license" data-button-color="dark-gray" data-handler="run" data-action-type="helper" data-setting-type="license" data-action="release">Deactivate license</button>
		</div>
		<div class="license-card">
			<img src="<?php echo SEMPLICE_URI; ?>/assets/images/admin/settings/license/card.png">
			<div class="license-name">{{name}}</div>
		</div>
	</div>
</template>

<template id="smp-tpl-update">
	<div class="semplice-update update-notice">
		<div class="inner">
			<p><span>Update available!</span> New version: {{newVersion}} &mdash; <a href="https://www.semplice.com/changelog" target="_blank">View Changelog</a></p>
			<div class="update-button">
				<a href="<?php echo admin_url('themes.php'); ?>">Update to Version {{newVersion}}</a>
			</div>
		</div>
	</div>
</template>

<template id="smp-tpl-update-edition">
	<div class="semplice-update update-notice">
		<div class="inner">
			<p><span>Studio Upgrade available!</span> Please upgrade to the studio edition now!</p>
			<div class="update-button">
				<a href="<?php echo admin_url('themes.php'); ?>">Upgrade to Studio</a>	
			</div>
		</div>
	</div>
</template>

<template id="smp-tpl-wrong-folder">
	<div class="wrong-folder update-notice">
		<div class="inner">
			<div class="wrong-folder-icon"><?php echo Get::svg('admin', 'important'); ?></div>
			<p>To activate the Semplice One-click Update, your theme root folder must be called <span>/semplice7</span>. At the moment your theme root folder is: <span>/<?php echo get_template(); ?></span>. Please <a href="https://help.semplice.com/hc/en-us/articles/360035159731" target="_blank">read our small guide</a> on how to change that. Don't worry it's pretty easy and straight forward.</p>
		</div>
	</div>
</template>