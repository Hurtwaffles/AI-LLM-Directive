<?php 
	use Semplice\Helper\Get;
?>
<template id="smp-tpl-media-library">
	<div id="semplice-media-library" data-view="thumbnails">
		<div class="dragover">
			<div class="dragover-inner"><p>Drop files to upload</p></div>
		</div>
		<div class="sml-inner inner">
			<div class="sml-header">
				<div class="sml-header-inner">
					<div class="sml-status">
						<?php echo Get::svg('admin', 'loader'); ?>
						<div class="sml-status-text">Loading Folder</div>
					</div>
					<div class="sml-filename-header"></div>
					<div class="sml-header-right">
						<div class="sml-view">
							<button class="click-handler change-ml-view active" data-handler="run" data-action-type="mediaLibrary" data-action="changeView" data-view="thumbnails"><?php echo Get::svg('admin', '/media-library/view_thumbnails'); ?></button>
							<button class="click-handler change-ml-view" data-handler="run" data-action-type="mediaLibrary" data-action="changeView" data-view="details"><?php echo Get::svg('admin', '/media-library/view_details'); ?></button>
						</div>
						<div class="sml-search">
							<input type="text" placeholder="Search for title" class="sml-search-term" name="sml-search">
						</div>
					</div>
				</div>
				<div class="sml-search-results"></div>
			</div>
			<div class="sml-upload">
				<button class="sml-upload-button">Upload Media</button>
				<input type="file" name="files[]" id="sml-file-upload" data-input-type="fileUpload" multiple />
			</div>
			<div class="sml-footer">
				<div class="sml-footer-left">
					<a class="sml-delete-media click-handler" data-handler="run" data-action-type="dialog" data-action="deleteAttachment" data-setting-type="mediaLibrary"><?php echo Get::svg('admin', '/media-library/delete'); ?>Delete</a>
				</div>
				<div class="sml-footer-right">
					<a class="cancel click-handler" data-handler="run" data-action-type="mediaLibrary" data-action="close">Cancel</a>
					<button class="sml-insert-media">Insert Media</button>
				</div>
			</div>
			<div class="sml-content"></div>
		</div>
	</div>
</template>

<template id="smp-tpl-media-library-edit-meta">
	<div id="sml-edit-meta">
		<div class="inner">
			<div class="sml-meta-details">
				<div class="sml-meta-preview">
					<div class="sml-meta-url"><a href="{{url}}" target="_blank"><?php echo Get::svg('admin', 'media-library/meta_url'); ?></a></div>
					<div class="sml-meta-thumbnail {{ratio}} {{mimeClass}}">
						<div class="centered">
							{{preview}}
						</div>
					</div>
				</div>
				<div class="sml-attachment-meta">
					<div class="sml-meta-filename"><span>{{filename}}</span></div>
					<div class="sml-meta-date"><span><?php echo Get::svg('admin', '/media-library/meta_date'); ?></span> {{date}}</div>
					<div class="sml-meta-size"><span><?php echo Get::svg('admin', '/media-library/meta_size'); ?></span> {{size}}</div>
					<div class="sml-meta-dimension"><span><?php echo Get::svg('admin', '/media-library/meta_dimension'); ?></span> {{dimension}}</div>
				</div>
			</div>
			<div class="options">
				<div class="option">
					<option-input>
						<label>Title</label>
						<input type="text" value="{{title}}" name="sml-meta-title">
					</option-input>
					<option-input>
						<label>Caption</label>
						<textarea type="text" name="sml-meta-caption">{{caption}}</textarea>
					</option-input>
					<option-input>
						<label>Alternative Text</label>
						<input type="text" value="{{alt}}" name="sml-meta-alt">
					</option-input>
					<option-input>
						<label>Description</label>
						<textarea type="text" name="sml-meta-description">{{description}}</textarea>
					</option-input>
				</div>
			</div>
			<div class="sml-meta-footer">
				<button class="click-handler cancel" data-handler="run" data-action-type="mlMeta" data-action="close" data-close-mode="{{saveMode}}">Cancel</button>
				<button class="click-handler save" data-handler="run" data-action-type="mlMeta" data-action="save" data-attachment-id="{{id}}" data-save-mode="{{saveMode}}">Save</button>
			</div>
		</div>
	</div>
</template>

<template id="smp-tpl-media-library-blank-attachment">
	<div class="sml-attachment sml-attachment-slot">
		<div class="sml-attachment-inner">
			<div id="{{id}}" class="sml-upload-progress"><div class="progress-inner"></div><div class="progress-inner-bg"></div></div>
		</div>
	</div>
</template>

<template id="smp-tpl-media-library-upload-attachment">
	<div id="attachment-{{id}}" class="sml-attachment" data-attachment-id="{{id}}" data-attachment-mime="{{mimeType}}" data-attachment-url="{{src}}" data-attachment-sizes='{"medium": "{{srcMedium}}", "medium_large": "{{srcMediumLarge}}"}' data-attachment-width="{{width}}" data-attachment-height="{{height}}">
		<div class="sml-attachment-inner">
			<div class="sml-thumbnail {{classes}} {{ratio}}" data-mime-type="{{mimeType}}">
				<div class="centered">
					{{thumbnail}}
				</div>
				{{title}}
				<div class="sml-meta"><a class="sml-show-meta click-handler" data-handler="run" data-action-type="mlMeta" data-action="get" data-attachment-id="{{id}}"></a></div>
			</div>
		</div>
		<div class="sml-filename">{{filename}}</div>
		<div class="sml-details">
			<div class="filename">{{filenameDetails}}</div>
			<div class="type">{{mimeType}}</div>
			<div class="dimension"><span>{{width}}</span> × <span>{{height}}</span></div>
			<div class="size">{{size}} kb</div>
		</div>
	</div>
</template>

<template id="smp-tpl-media-library-upload-image">
	<div class="semplice-upload ml-dropzone {{classes}}" {{atts}}>
		<div class="icon"><?php echo Get::svg('admin', '/media-library/upload'); ?></div>
		<div class="ep-upload-status">
			<svg width="40" height="40">
				<circle class="progress-circle" stroke="#555555" stroke-width="2" fill="transparent" r="16" cx="20" cy="20" style="stroke-dasharray: 100.53, 100.53; stroke-dashoffset: 101px;"></circle>
			</svg>
			<div class="finishing">Processing upload</div>
		</div>
		<div class="image-preview-wrapper">
			<div class="ep-thumbnail {{ratio}}">
				<div class="centered">
					<img class="image image-preview" src="{{src}}">
				</div>
			</div>
			<div class="upload-icon"><?php echo Get::svg('admin/media-library', 'upload'); ?></div>
			<div class="edit-image">
				<ul>
					<li><a class="click-handler mlEdit" data-handler="run" data-action="init" data-action-type="mediaLibrary" data-media-type="image" {{atts}}><?php echo Get::svg('admin', 'edit'); ?></a></li>
					<li><a class="click-handler mlEdit" data-handler="remove" data-remove-type="image" {{atts}}><?php echo Get::svg('admin', 'delete'); ?></a></li>
				</ul>
			</div>
		</div>
	</div>
</template>

<template id="smp-tpl-media-library-upload-gallery">
	<ul class="gallery-images" data-module="{{module}}">{{galleryAttachments}}</ul>
	<div class="semplice-upload ml-dropzone {{classes}}" {{atts}}>
		<div class="icon"><?php echo Get::svg('admin', '/media-library/upload'); ?></div>
		<div class="ep-upload-status">
			<svg width="40" height="40">
				<circle class="progress-circle" stroke="#555555" stroke-width="2" fill="transparent" r="16" cx="20" cy="20" style="stroke-dasharray: 100.53, 100.53; stroke-dashoffset: 101px;"></circle>
			</svg>
			<div class="finishing">Processing upload</div>
		</div>
	</div>
</template>

<template id="smp-tpl-media-library-upload-video">
	<div class="semplice-upload video-upload {{classes}}" {{atts}}>
		<span>{{src}}</span>
		<a class="click-handler mlEdit remove-video has-tooltip" data-handler="remove" data-remove-type="video" data-tooltip="Remove" data-tooltip-settings="left,center,auto" {{atts}}><?php echo Get::svg('admin', 'delete'); ?></a>
	</div>
</template>

<template id="smp-tpl-media-library-upload-json">
	<div class="semplice-upload json-upload ml-dropzone {{classes}}" {{atts}}>
		<div class="icon"><?php echo Get::svg('admin', '/media-library/upload'); ?></div>
		<div class="json-note">Upload JSON</div>
		<div class="ep-upload-status">
			<svg width="40" height="40">
				<circle class="progress-circle" stroke="#555555" stroke-width="2" fill="transparent" r="16" cx="20" cy="20" style="stroke-dasharray: 100.53, 100.53; stroke-dashoffset: 101px;"></circle>
			</svg>
			<div class="finishing">Processing upload</div>
		</div>
		<div class="json-preview">
			<div class="json-meta">
				<div class="json-icon"><?php echo Get::svg('admin/media-library', 'json'); ?></div>
				<div class="json-filename"><span class="label">Uploaded File</span><br /><span class="name">{{filename}}</span></div>
			</div>
			<div class="json-edit">
				<a><?php echo Get::svg('admin', 'edit'); ?></a>
			</div>
		</div>
	</div>
</template>

<template id="smp-tpl-media-library-upload-font">
	<div class="semplice-upload font-upload ml-dropzone {{classes}}" {{atts}}>
		<div class="icon"><?php echo Get::svg('admin', '/media-library/upload'); ?></div>
		<div class="font-note">Upload Fonts</div>
		<div class="ep-upload-status">
			<svg width="40" height="40">
				<circle class="progress-circle" stroke="#555555" stroke-width="2" fill="transparent" r="16" cx="20" cy="20" style="stroke-dasharray: 100.53, 100.53; stroke-dashoffset: 101px;"></circle>
			</svg>
			<div class="finishing">Processing upload</div>
		</div>
		<ul class="font-preview"></ul>
	</div>
	<p class="font-add-to-list">Click or drag and drop on the list to add more fonts.</p>
</template>

<template id="smp-tpl-gallery-image">
	<li id="{{imageId}}">
		{{mediaPreview}}
		<a class="remove-gallery-image click-handler" data-handler="remove" data-name="gallery" data-remove-type="image" data-id="{{contentId}}"><?php echo Get::svg('admin', 'delete'); ?></a>
		<a class="change-gallery-meta click-handler" data-handler="run" data-action-type="mediaLibrary" data-action="init" data-id="{{contentId}}" data-image-id="{{imageId}}" data-after-init="editMeta"><?php echo Get::svg('admin', 'edit'); ?></a>
		<a class="link-gallery-image click-handler" data-handler="run" data-action-type="helper" data-setting-type="core" data-action="linkMarqueeImg" data-id="{{contentId}}" data-image-id="{{imageId}}"><?php echo Get::svg('admin', 'link'); ?></a>
	</li>
</template>