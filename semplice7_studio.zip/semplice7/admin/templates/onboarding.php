<?php
	use Semplice\Helper\Get;
?>
<template id="smp-tpl-onboarding" type="text/template">
	<div class="content">
		<div class="ob-badge"><img src="<?php echo SEMPLICE_URI; ?>/assets/images/admin/onboarding/badge.png"><div class="meta"></div></div>
		<div class="heading">
			<div class="ob-heading"><div class="ob-stagger">{{title}}</div></div>
			<div class="ob-sub"><div class="ob-stagger">{{sub}}</div></div>
		</div>
		<div class="input">{{input}}</div>
		<div class="ob-content">{{content}}</div>
		<div class="footer">
			<div class="button-wrapper">
				<button class="ob-button ob-stagger ob-step-nav ob-back" data-button-color="dark-gray" data-step="{{stepNavBack}}">Back</button> 
				<button class="ob-button ob-stagger ob-step-nav ob-continue" data-button-color="yellow" data-step="{{stepNav}}">Continue</button> 
			</div>
		</div>
	</div>
</template>
<template id="smp-tpl-onboarding-start" type="text/template">
	<div class="bg-start"><?php echo Get::svg('admin', 'onboarding/eagle'); ?></div>
</template>
<template id="smp-tpl-onboarding-one" type="text/template">
	<div class="browser">
		<div class="ob-stagger">
			<?php echo Get::svg('admin', 'onboarding/browser'); ?>
			<div class="browser-heading"><span class="site_title">Sergio Rambotta</span> <span class="mdash">—</span> <span class="site_tagline">Graphic Designer</span></div>
		</div>
	</div>
</template>
<template id="smp-tpl-onboarding-two" type="text/template">
	<div class="browser">
		<div class="ob-stagger">
			<?php echo Get::svg('admin', 'onboarding/browser'); ?>
			<div class="browser-heading"><span class="site_title">Sergio Rambotta</span> <span class="mdash">—</span> <span class="site_tagline">Graphic Designer</span></div>
		</div>
	</div>
</template>
<template id="smp-tpl-onboarding-three" type="text/template">
	<div class="ob-navs">
		<?php
			$navs = array(
				'right'  => array(
					'title'  => 'Right Aligned',
					'preset' => 'logo_left_menu_right'
				),
				'left'   => array(
					'title'  => 'Left Aligned',
					'preset' => 'logo_right_menu_left'
				),
				'center' => array(
					'title'  => 'Center Aligned',
					'preset' => 'logo_middle_menu_stacked'
				),
				'stacked' => array(
					'title'  => 'Center Stacked',
					'preset' => 'logo_left_menu_left'
				)
			);			
			foreach($navs as $dir => $nav) {
				echo '
					<div class="ob-nav" data-preset="' . $nav['preset'] . '">
						<div class="ob-nav-title">' . $nav['title'] . '</div>
						<div class="ob-nav-image">' . Get::svg('admin', 'onboarding/nav-' . $dir) . '</div>
					</div>
				';
			}
		?>
	</div>
</template>
<template id="smp-tpl-onboarding-four" type="text/template">
	<div class="browser-pages">
		<div class="ob-stagger">
			<?php echo Get::svg('admin', 'onboarding/browser-pages'); ?>
			<div class="ob-pages">
				<div class="ob-page"><?php echo Get::svg('admin', 'onboarding/pages-home'); ?></div>
				<div class="ob-page"><?php echo Get::svg('admin', 'onboarding/pages-about'); ?></div>
			</div>
			<div class="ob-projects">
				<div class="ob-project"><?php echo Get::svg('admin', 'onboarding/projects-first'); ?></div>
			</div>
		</div>
	</div>
</template>
<template id="smp-tpl-onboarding-five" type="text/template"></template>