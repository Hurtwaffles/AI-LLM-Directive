<?php
	use Semplice\Helper\Get;
?>
<template id="smp-tpl-edit-popup">
	<ep-content-wrapper>
		<ep-regular>
			<ep-tabs-nav></ep-tabs-nav>
			<ep-save></ep-save>
			<ep-tabs></ep-tabs>
			<ep-footer>
				<ep-actions></ep-actions>
			</ep-footer>	
		</ep-regular>
		<ep-expand-options>
		</ep-expand-options>
	</ep-content-wrapper>
</template>

<template id="smp-tpl-expand-options">
	<div class="head">
		<div class="back">
			<a class="close-expand-options" data-options="{{expandOptions}}" data-id="{{id}}"><?php echo Get::svg('admin', '/edit-popup/arrow_back'); ?></a>
		</div>
		<div class="title">
			{{title}}
		</div>
		<div class="expand-save">
			<a class="close-edit-popup" data-module="{{module}}" data-id="{{id}}"><!-- close ep options --></a>
		</div>
	</div>
	<div class="ep-expand-content">
		{{content}}
	</div>
</template>

<template id="smp-tpl-edit-popup-locked">
	<div class="locked-content has-tooltip" data-tooltip="Locked content for blog templates<br />can't be duplicated, saved as<br />a block or removed." data-tooltip-settings="top,center,auto" data-tooltip-theme="invert">
		<div class="inner"><span><?php echo Get::svg('admin', 'edit-popup/locked'); ?></span> Locked Content</div>
	</div>
</template>