<?php
	use Semplice\Helper\Get;
?>
<template id="smp-tpl-not-found">
	<div class="semplice-error">
		<span><?php echo Get::svg('admin', 'important'); ?></span>
		<h1>It looks like your permalinks are not working.<br/>Please make sure that permalinks are enabled and<br />that you have a working .htaccess file in place.</h1>
		<a data-button-color="yellow" href="<?php echo admin_url('options-permalink.php'); ?>">Permalink Settings</a>
	</div>
</template>

<template id="smp-tpl-no-rest-api">
	<div class="semplice-error">
		<span><?php echo Get::svg('admin', 'important'); ?></span>
		<h1>Semplice requires WordPress 4.4 or higher with an activated<br />Rest-API. Please update your site and try again.</h1>
		<button data-button-color="yellow" class="click-handler" data-handler="run" data-action-type="helper" data-setting-type="core" data-action="exit">Exit to Wordpress</button>
	</div>
</template>

<template id="smp-tpl-php-error">
	<div class="semplice-error">
		<span><?php echo Get::svg('admin', 'important'); ?></span>
		<h1>Semplice requires PHP version 7.0 or higher.<br />Please contact your web host to update your PHP version.</h1>
		<button data-button-color="yellow" class="click-handler" data-handler="run" data-action-type="helper" data-setting-type="core" data-action="exit">Exit to Wordpress</button>
	</div>
</template>