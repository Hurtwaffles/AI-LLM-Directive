<template id="smp-tpl-post-settings">
	<div id="post-settings-sidebar">
		<div class="sidebar-inner">
			<div class="sidebar-content">
				<ul class="sidebar-tabs-nav"></ul>
				<div class="sidebar-active-line"></div>
				<div class="sidebar-gradient"></div>
				<div class="tab-content"></div>
			</div>
		</div>
	</div>
</template>

<template id="smp-tpl-post-settings-save">
	<div class="post-setting-save">
		<button class="click-handler cancel" data-button-color="dark-gray" data-handler="run" data-action-type="postSettings" data-setting-type="sidebar" data-action="hide" data-origin="{{origin}}" data-id="{{id}}" data-content-id="{{contentId}}" data-mode="cancel">Cancel</button>
		<button class="click-handler confirm" data-button-color="yellow" data-handler="run" data-action-type="postSettings" data-setting-type="sidebar" data-action="hide" data-origin="{{origin}}" data-id="{{id}}" data-content-id="{{contentId}}" data-mode="save">Save</button>
	</div>
</template>

<template id="smp-tpl-categories">
	<div class="meta-categories">
		<div class="select-wrapper">
			<div class="search">
				<input type="text" class="categories-search" placeholder="Search Categories">
			</div>
			<ul {{atts}}><?php wp_category_checklist(); ?></ul>
		</div>
		<div class="add-new-category">
			<div class="add-category-form hide">
				<input type="text" name="category-name" placeholder="Category Name">
				<input type="hidden" name="category-parent">
				<div class="categories-dropdown"><div class="select-box"><div class="sb-arrow"></div><?php wp_dropdown_categories('hide_empty=0&depth=5&hierarchical=1'); ?></div></div>
				<button class="click-handler" data-button-color="dark-gray" data-handler="run" data-action-type="postSettings" data-setting-type="categories" data-action="add">Add Category</a>
			</div>
			<button class="click-handler" data-button-color="dark-gray" data-handler="run" data-action-type="postSettings" data-setting-type="categories" data-action="showForm">Add Category</a>
		</div>
	</div>
</template>

<template id="smp-tpl-no-yoast">
	<div class="no-yoast">
		<h3>Please install Yoast SEO</h3>
		<p>To enable the SEO options in Semplice, you need to install the <a href="https://wordpress.org/plugins/wordpress-seo/" target="_blank">Yoast SEO Plugin</a>.<br /><br />Please note that our admin panel and the 'Single Page App' mode only supports the Yoast SEO Plugin. If you would rather manage your SEO settings in the standard Wordpress admin and you don't plan on using the 'Single Page App' mode, you can use any SEO plugin you prefer.</p>
	</div>
</template>