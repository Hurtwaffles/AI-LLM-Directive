<?php
	use Semplice\Helper\Get;
?>
<template id="smp-tpl-navigations-module-menu">
	<smp-nav-content id="{{id}}" data-module="{{module}}" data-menu-type="text">
		<div class="text">
			{{content}}
		</div>
		<div class="hamburger">
			<div class="hamburger"><a class="open-menu menu-icon"><span></span></a></div>
		</div>
	</smp-nav-content>
</template>

<template id="smp-tpl-navigations-module-link">
	<smp-nav-content id="{{id}}" data-module="{{module}}">
		<a href="https://www.semplice.com" class="is-content">Link</a>
	</smp-nav-content>
</template>

<template id="smp-tpl-navigations-module-image">
	<smp-nav-content id="{{id}}" data-module="{{module}}">
		<img class="is-content" src="<?php echo SEMPLICE_URI . '/assets/images/admin/customize/navigations/logo.svg'; ?>">
	</smp-nav-content>
</template>

<template id="smp-tpl-navigations-module-text">
	<smp-nav-content id="{{id}}" data-module="{{module}}">
		<div class="is-content">Sample text, double click to edit me!</div>
	</smp-nav-content>
</template>

<template id="smp-tpl-navigations-module-button">
	<smp-nav-content id="{{id}}" data-module="{{module}}">
		<button class="smp-nav-button is-content"><span class="text">Button</span></button>
	</smp-nav-content>
</template>

<template id="smp-tpl-navigations-module-spacer">
	<smp-nav-content id="{{id}}" data-module="{{module}}">
		<div class="spacer-container">
			<div class="is-content">
				<div class="spacer"></div>
			</div>
		</div>
	</smp-nav-content>
</template>

<template id="smp-tpl-navigations-module-lottie">
	<smp-nav-content id="{{id}}" data-module="{{module}}">
		<div class="smp-nav-lottie is-content"></div>
	</smp-nav-content>
</template>

<template id="smp-tpl-navigations-module-code">
	<smp-nav-content id="{{id}}" data-module="{{module}}">
		<div class="smp-nav-code is-content"><?php echo Get::svg('admin', 'customize/navigations/modules/code'); ?><span>Code Module</span></div>
	</smp-nav-content>
</template>

