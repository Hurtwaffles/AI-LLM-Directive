<?php
	use Semplice\Helper\Get;
?>

<template id="smp-tpl-customize">
	<div class="smp-customize admin-container" data-setting="{{setting}}" data-mode="{{mode}}" data-customize-bp="xl">
		{{header}}
		<div class="admin-row customize-content customize-{{setting}}">
			{{content}}
		</div>
	</div>
</template>

<template id="smp-tpl-customize-header">
	<div class="admin-row header-row">
		<div class="admin-header admin-column">
			<div class="heading">
				<h2 class="admin-title">{{title}}</h2>
				<p class="customize-description">{{description}}</p>
			</div>
			{{actions}}
		</div>
	</div>
</template>

<template id="smp-tpl-customize-header-settings">
	<div class="admin-row header-row">
		<div class="admin-header admin-column settings-header">
			<ul class="settings-menu">
				<li><a href="#customize/advanced" data-setting="advanced">Global</a></li>
				<li><a href="#customize/cursor" data-setting="cursor">Cursor</a></li>
				<li><a href="#customize/ppc" data-setting="ppc">Password Protected</a></li>
			</ul>
			{{actions}}
		</div>
	</div>
</template>

<template id="smp-tpl-typography-empty-styles">
	<div class="typography-empty-styles">
		<img src="<?php echo SEMPLICE_URI; ?>/assets/images/admin/customize/typography/empty-styles.png">
		<p class="heading">Custom Styles</p>
		<p class="description">Define global custom styles for headings or <br />paragraphs which can be selected in the WYSIWYG editor.</p>
	</div>
</template>

<template id="smp-tpl-typography-custom-style">
	<li id="{{id}}" class="custom-style cs-overwrite"  data-preview-bg="{{previewBg}}" data-element-type="{{elementType}}">
		<div class="name"><span class="{{elementType}}">{{elementName}}</span>{{name}}</div>
		<div class="preview">Designed to be used and loved by millions. Made with pride by HOVS.</div>
		<button class="click-handler remove-custom-style" data-handler="run" data-action-type="customStyles" data-action="remove" data-id="{{id}}"><?php echo Get::svg('admin', 'delete'); ?></button>
	</li>
</template>