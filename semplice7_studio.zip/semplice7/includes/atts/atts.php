<?php

// namespace
namespace Semplice;

// use
use Semplice\Helper\PostQueries;
use Semplice\Helper\Menu;
use Semplice\Helper\Typography;
use Semplice\Helper\Get;

// -----------------------------------------
// semplice atts
// -----------------------------------------

class Atts {

	// -----------------------------------------
	// generate atts for localize script
	// -----------------------------------------

	public static function generate() {
		$atts = array();
		// define structure
		$json_files = json_decode(file_get_contents(SEMPLICE_DIR . '/assets/json/atts/list.json'), true);
		// transform path names with a -
		$make_cc = array(
			'post-settings' => 'postSettings',
			'nav-styles' 	=> 'navStyles',
			'nav-modules'	=> 'navModules',
			'local-options' => 'localOptions'
		);
		// read files
		foreach($json_files as $path => $files) {
			foreach($files as $file_name) {
				// path
				if($path == 'misc') {
					$file = SEMPLICE_DIR . '/assets/json/atts/' . $file_name . '.json';
				} else {
					$file = SEMPLICE_DIR . '/assets/json/atts/' . $path . '/' . $file_name . '.json';
				}
				// get json
				$json = file_get_contents($file);
				// set decode path
				$decode_path = (isset($make_cc[$path])) ? $make_cc[$path] : $path;
				// decode
				$atts[$decode_path][$file_name] = json_decode($json, true);
			}
		}
		// dynamic atts
		$atts['dynamic'] = self::dynamic();
		// return
		return $atts;
	}

	// -----------------------------------------
	// dynamic atts
	// -----------------------------------------

	public static function dynamic() {
		// width
		$width = array();
		for($i=1; $i<=12; $i++) {
			$width[$i] = $i . ' Col';
		}
		// thumbnail width
		$thumbnail_width = $width;
		$thumbnail_width['full'] = 'Fullscreen';
		// dynamic atts import
		$json = json_decode(file_get_contents(SEMPLICE_DIR . '/assets/json/atts/dynamic.json'), true);
		// atts
		$atts = array(
			// fonts
			'fonts' 		 => Typography::get_default_fonts('display', false),
			'width' 		 => $width,
			'thumbnailWidth' => $thumbnail_width,
			'gsapEasings'	 => $json['gsap_easings'],
			'cssEasings'	 => $json['css_easings'],
			'blendModes'	 => $json['blend_modes'],
			'cursorTypes'	 => $json['cursor_types'],
			'menus'			 => Menu::list(),
			'navigations'	 => Get::nav_dropdown(),
			// post dropdowns
			'posts' 		 => PostQueries::post_dropdown('post'),
			'pages' 		 => PostQueries::post_dropdown('page'),
			'projects' 		 => PostQueries::post_dropdown('project'),
			'footers' 		 => PostQueries::post_dropdown('footer')
		);
		// return
		return $atts;
	}
}
new Atts;
?>