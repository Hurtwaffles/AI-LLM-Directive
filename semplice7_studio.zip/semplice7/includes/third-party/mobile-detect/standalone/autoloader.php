<?php
$md_dir = dirname(__FILE__);

spl_autoload_register(function ($class) use ($md_dir) {
    $classMap = [
        // "mobiledetect/mobiledetectlib"
        "Detection\Cache\Cache" => $md_dir . "/../src/Cache/Cache.php",
        "Detection\Cache\CacheException" => $md_dir . "/../src/Cache/CacheException.php",
        "Detection\Cache\CacheInvalidArgumentException" => $md_dir . "/../src/Cache/CacheInvalidArgumentException.php",
        "Detection\Exception\MobileDetectException" => $md_dir . "/../src/Exception/MobileDetectException.php",
        "Detection\Exception\MobileDetectExceptionCode" => $md_dir . "/../src/Exception/MobileDetectExceptionCode.php",
        "Detection\MobileDetect" => $md_dir . "/../src/MobileDetect.php",

        // "psr/simple-cache"
        "Psr\SimpleCache\CacheException" => $md_dir . "/deps/simple-cache/src/CacheException.php",
        "Psr\SimpleCache\CacheInterface" => $md_dir . "/deps/simple-cache/src/CacheInterface.php",
        "Psr\SimpleCache\InvalidArgumentException" => $md_dir . "/deps/simple-cache/src/InvalidArgumentException.php",
    ];

    $fileFound = $classMap[$class] ?? false;

    if ($fileFound) {
        require $fileFound;
        return true;
    }

    return false;
});
