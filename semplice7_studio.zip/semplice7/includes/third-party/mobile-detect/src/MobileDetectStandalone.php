<?php

namespace Detection;

require_once dirname(__FILE__) . '/../standalone/autoloader.php';

class MobileDetectStandalone extends MobileDetect
{
}
