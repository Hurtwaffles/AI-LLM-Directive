<?php

declare(strict_types=1);

namespace Detection\Exception;

class MobileDetectException extends \Exception
{
}
