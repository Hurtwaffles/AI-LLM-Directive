<?php

declare(strict_types=1);

namespace Detection\Cache;

class CacheException extends \Exception implements \Psr\SimpleCache\CacheException
{
}
