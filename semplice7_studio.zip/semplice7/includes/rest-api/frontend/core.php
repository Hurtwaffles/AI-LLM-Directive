<?php

// namespace
namespace Semplice\RestApi\Frontend;

// use
use Semplice\Editor;
use Semplice\Content;
use Semplice\Admin\Customize;
use Semplice\Helper\Basic;
use Semplice\Helper\Get;
use Semplice\Helper\PostQueries;
use Semplice\Helper\RestApi;
use WP_REST_Response;

// -----------------------------------------
// core api
// -----------------------------------------

class RestApiFrontend {

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// call register routes on rest api init
		add_action('rest_api_init', array(&$this, 'register_routes'));
	}

	// -----------------------------------------
	// rest routes
	// -----------------------------------------

	public function register_routes() {
		// version
		$ver = '1';
		$namespace = 'semplice/v' . $ver . '/frontend';
		// routes
		$routes = array(
			'/posts' 	 		 => array('readable', 'post'),
			'/posts/(?P<id>\d+)' => array('readable', 'post'),
			'/notfound' 		 => array('readable', 'post'),
			'/lazy-load'		 => array('readable', 'masonry_lazy_load')
		);
		// register routes
		RestApi::register_route($namespace, $routes, $this, new RestApi);
	}

	// -----------------------------------------
	// get post
	// -----------------------------------------

	public function post($request) {
		// archives
		$archives = array('posts', 'category', 'post_tag', 'author', 'search');
		// get post data
		$post_data = $this->post_data($request, $archives);
		// make array
		if(isset($post_data['post']) && is_object($post_data['post'])) {
			// get post
			$post = $post_data['post'];
			// get content
			$content = Content::get($post_data['id'], false, intval($request['page']), $post_data['filter'], $request['url'], true);
			// format output
			$output = $this->format_output($post->ID, $post->post_name, $post->post_title, $content, $post_data['has_password'],$post->post_type,false);
			// add post settings
			if($output['content']['is_semplice']) {
				$post_settings = json_decode(get_post_meta($post->ID, '_semplice_post_settings', true), true);
				if(null !== $post_settings) {
					$output['post_settings'] = $post_settings;
				}
			}
			// navbar
			if(isset($output['content']['navbar'])) {
				$output['navbar'] = $output['content']['navbar'];
			} else if(isset($output['post_settings'])) {
				$meta = $output['post_settings']['meta'];
				if(!isset($meta['navbar_visibility']) || Basic::boolval($meta['navbar_visibility'])) {
					$output['navbar'] = (isset($meta['navbar'])) ? Get::navbar($meta['navbar']) : Get::navbar(false);
				}
			} else {
				$output['navbar'] = Get::navbar(false);
			}
			// get title
			$output['title'] = Get::spa_title($output['title'], $post_data['id'], $post);
		} else if(in_array($post_data['id'], $archives)) {
			// get title
			$title = $this->post_title($post_data);
			// content
			$content = Content::posts($post_data['filter'], $request['url'], intval($request['page']), true);
			// format output
			$output = $this->format_output($request['id'], '', $title, $content, $post_data['has_password'], 'category', false);
			// already has navbar(=wp-template) ?
			$output['navbar'] = (!isset($output['content']['navbar'])) ? Get::navbar(false) : $output['content']['navbar'];
		} else {
			// get 404 not found page
			$output = $this->format_output('notfound', '', '404 - Not found', Content::template('not-found', false), $post_data['has_password'], 'notfound', Get::navbar(false));
		}
		// wrap sections
		if(isset($output['content']['html'])) {
			$output['content']['html'] = '<div class="transition-wrap"><div class="sections">' . $output['content']['html'] . '</div></div>';
		}
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// masonry lazy load
	// -----------------------------------------

	public function masonry_lazy_load($request) {
		// output
		$output = array(
			'items'  => '',
			'css'	 => '',
			'fin' 	 => false, 
		);
		// get options
		$options = json_decode($request['options'], true);
		// extract options
		extract( shortcode_atts(
			array(
				'categories'				=> '',
				'title_visibility'			=> 'both',
				'title_position'			=> 'below',
				'title_font'				=> 'regular',
				'title_color'				=> '#000000',
				'category_font'				=> 'regular',
				'category_color'			=> '#999999'
			), $options)
		);
		// get portfolio order
		$portfolio_order = json_decode(get_option('semplice_portfolio_order'));
		// categories
		$categories = explode(',', $categories);
		// get projects count
		$count_posts = wp_count_posts('project');
		$count = ($count_posts) ? $count_posts->publish : 0;
		// get count from frontend
		$frontend_num = (intval($request['offset']) + intval($request['load']));
		// set status
		if($count <= $frontend_num) {
			$output['fin'] = true;
		}
		// get projects
		$projects = PostQueries::get_projects($portfolio_order, $categories, $request['load'], $request['offset'], false, 'publish');
		// get thumb hover options
		$global_hover_options = Get::customize('thumbhover');
		// masonry items
		$masonry_items = '';
		// are there any published projects
		if(!empty($projects)) {
			// change title position to below if visibility is hidden
			if($title_visibility == 'hidden') {
				$title_position = 'below';
			}
			// get content
			$atts = array(
				'global_hover_options'  => $global_hover_options,
				'title_visibility' 		=> $title_visibility,
				'title_position' 		=> $title_position,
				'title_font' 			=> $title_font,
				'title_color' 			=> $title_color,
				'category_font' 		=> $category_font,
				'category_color'		=> $category_color
			);
			foreach ($projects as $key => $project) {
				// get masonry items
				$output['items'] .= Editor::$modules['portfoliogrid']->masonry_items($request['content_id'], $project, $atts, false, ' pg-lazy-load');
				// thumb hover css if custom thumb hover is set
				if(isset($project['thumb_hover'])) {
					$output['css'] .= Customize::$setting['thumbhover']->css('project-' . $project['post_id'], $project['thumb_hover'], false, '#content-holder', false);
				}
			}
		}
		// output
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// get post data
	// -----------------------------------------

	public function post_data($request, $archives) {
		// defaults
		$post_data = array(
			'id'     => false,
			'filter' => false,
			'author' => false,
			'post'   => false,
		);
		// is archives?
		if(!empty($request['taxonomy']) && in_array($request['taxonomy'], $archives)) {
			$taxonomy = $request['taxonomy'];
			$term = $request['term'];
			if($taxonomy == 'posts') {
				$post_data['filter'] = array('type' => 'overview', 'meta' => false);
			} else if($taxonomy == 'category') {
				$post_data['filter'] = array('type' => 'category', 'meta' => get_term_by('slug', $term, 'category'));
			} else if($taxonomy == 'post_tag') {
				$post_data['filter'] = array('type' => 'tag', 'meta' => get_term_by('slug', $term, 'post_tag'));
			} else if($taxonomy == 'author') {
				$post_data['author'] = get_user_by('slug', $term);
				if(null !== $post_data['author'] && is_object($post_data['author'])) {
					$post_data['filter'] = array('type' => 'author', 'meta' => $post_data['author']->ID);
				} else {
					$post_data['filter'] = array('type' => 'author', 'meta' => 1);
				}
			} else if($taxonomy == 'search') {
				// reverse url encode
				$term = urldecode($term);
				// replace spaces with +
				$term = str_replace(' ', '+', $term);
				// add to filter
				$post_data['filter'] = array('type' => 'searchresults', 'meta' => $term);
			}
			$post_data['id'] = $taxonomy;
		} else {
			// get post
			$post_data['post'] = get_post($request['id']);
			// format id
			$post_data['id'] = Basic::format_post_id($request['id'], false);
			// is single post?
			if(null !== $post_data['post'] && is_object($post_data['post']) && $post_data['post']->post_type == 'post') {
				$post_data['filter'] = array('type' => 'singlepost', 'meta' => $post_data['post']->ID);
			}
		}
		// has password?
		$post_data['has_password'] = (post_password_required($post_data['id'])) ? true : false;
		// return post data
		return $post_data;
	}

	// -----------------------------------------
	// get post title
	// -----------------------------------------

	public function post_title($post_data) {
		if($post_data['id'] == 'posts') {
			$title = get_bloginfo('name') . ' - ' . get_bloginfo('description');
		} else if($post_data['id'] == 'search') {
			$title = __('Results for', 'semplice') . ' ' . $post_data['filter']['meta'] . ' - ' . get_bloginfo('name');
		} else if($post_data['id'] != 'author') {
			$title = $post_data['filter']['meta']->name . ' - ' . get_bloginfo('name');
		} else {
			$title = $post_data['author']->display_name . ' - ' . get_bloginfo('name');
		}
		// return
		return $title;
	}

	// -----------------------------------------
	// format output
	// -----------------------------------------

	public function format_output($id, $name, $title, $content, $has_password, $post_type, $navbar) {
		return array(
			'id'   			=> $id,
			'name' 			=> $name,
			'title' 		=> $title,
			'content'		=> $content,
			'hasPassword'  => $has_password,
			'postType'		=> $post_type,
			'navbar'		=> $navbar,
		);
	}
}

// init
new RestApiFrontend;

?>