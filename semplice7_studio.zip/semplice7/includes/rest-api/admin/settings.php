<?php

// namespace
namespace Semplice\RestApi\Admin;

// use
use Semplice\Helper\Basic;
use Semplice\Helper\RestApi;
use Semplice\Helper\License;
use Semplice\Helper\PostQueries;
use WP_REST_Response;

// -----------------------------------------
// settings api
// -----------------------------------------

class RestApiSettings {

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// call register routes on rest api init
		add_action('rest_api_init', array(&$this, 'register_routes'));
	}

	// -----------------------------------------
	// rest routes
	// -----------------------------------------

	public function register_routes() {
		// version
		$ver = '1';
		$namespace = 'semplice/v' . $ver . '/admin';
		// routes
		$routes = array(
			'/settings/init' 	=> array('readable', 'init'),
			'/settings/save' 	=> array('creatable', 'save'),
			'/license/save'		=> array('creatable', 'save_license'),
			'/license/release'	=> array('creatable', 'release_license')				
		);
		// register routes
		RestApi::register_route($namespace, $routes, $this, new RestApi);
	}

	// -----------------------------------------
	// init settings
	// -----------------------------------------

	public function init($request) {
		// return
		return new WP_REST_Response(PostQueries::post_dropdown('page'), 200);
	}

	// -----------------------------------------
	// save
	// -----------------------------------------

	public function save($request) {
		// get settings and add or remove slashes
		$settings = Basic::check_slashes($request['settings']);
		// get setting type
		$setting = $request['setting'];
		// save settings in the DB
		update_option('semplice_settings_' . $setting, $settings);
		update_option('semplice_admin_images', $request['images']);
		update_option('semplice_custom_colors', $request['custom_colors']);
		// change project slug
		$output = array(
			'slug'	  	   => 'project',
			'slug_changed' => 'no'
		);
		// save frontpages
		if($setting == 'general') {
			// decode settings
			$settings = json_decode($settings, true);
			// defaults
			$homepage = array(
				'show_on_front'  	=> 'posts',
				'page_for_posts' 	=> 0,
				'page_on_front' 	=> 0,
			);
			if($settings['show_on_front'] != 'posts') {
				// set homepage type
				$homepage['show_on_front'] = 'page';
				// blog homepage
				if(isset($settings['page_for_posts'])) {
					$homepage['page_for_posts'] = $settings['page_for_posts'];
				}
				// pages homepage
				if(isset($settings['page_on_front'])) {
					$homepage['page_on_front'] = $settings['page_on_front'];
				}
			}
			// project slug
			if(isset($settings['project_slug']) && !empty($settings['project_slug'])) {
				$settings['project_slug'] = sanitize_title($settings['project_slug']);
				// is new slug?
				if(!get_option('semplice_project_slug') && $settings['project_slug'] != 'project' || get_option('semplice_project_slug') && get_option('semplice_project_slug') != $settings['project_slug'] && $settings['project_slug'] != 'project') {
					update_option('semplice_flush_rewrite', true);
					$output = array(
						'slug'	  	   => $settings['project_slug'],
						'slug_changed' => 'yes'
					);
				} else if($settings['project_slug'] != 'project') {
					$output = array(
						'slug'	  	   => $settings['project_slug'],
						'slug_changed' => 'no'
					);
				}
				// update slug
				update_option('semplice_project_slug', $settings['project_slug']);
			}
			// update homepage
			update_option('show_on_front', $homepage['show_on_front']);
			update_option('page_for_posts', $homepage['page_for_posts']);
			update_option('page_on_front', $homepage['page_on_front']);
			// site title
			if(isset($settings['site_title'])) {
				update_option('blogname ', $settings['site_title']);
			}
			// site tagline
			if(isset($settings['site_tagline'])) {
				update_option('blogdescription', $settings['site_tagline']);
			}
		}
		return new WP_REST_Response('', 200);
	}

	// -----------------------------------------
	// save license
	// -----------------------------------------

	public function save_license($request) {
		// check license
		$output = License::save($request['key'], $request['product']);
		// return
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// release license
	// -----------------------------------------

	public function release_license($request) {
		// set license to false
		update_option('semplice_license', false);
		// return
		return new WP_REST_Response('success', 200);
	}
}

// init
new RestApiSettings;

?>