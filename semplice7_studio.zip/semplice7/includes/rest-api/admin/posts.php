<?php

// namespace
namespace Semplice\RestApi\Admin;

// use
use Semplice\Helper\Basic;
use Semplice\Helper\RestApi;
use Semplice\Helper\PostQueries;
use Semplice\Helper\Get;
use Semplice\Helper\Ram;
use Semplice\Helper\Thumbnails;
use WP_REST_Response;

// -----------------------------------------
// posts api
// -----------------------------------------

class RestApiPosts {

	// public vars
	public $db;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// database
		global $wpdb;
		$this->db = $wpdb;
		// call register routes on rest api init
		add_action('rest_api_init', array(&$this, 'register_routes'));
	}

	// -----------------------------------------
	// rest routes
	// -----------------------------------------

	public function register_routes() {
		// version
		$ver = '1';
		$namespace = 'semplice/v' . $ver . '/admin';
		// routes
		$routes = array(
			'/posts/(?P<id>\d+)' 	=> array('readable', 'posts'),
			'/post/add'		 	 	=> array('creatable', 'add'),
			'/post/delete'		 	=> array('creatable', 'delete'),
			'/post/duplicate'		=> array('creatable', 'duplicate'),
			'/post/pin'				=> array('creatable', 'pin'),
			'/post/portfolio-order' => array('creatable', 'portfolio_order'),
			'/post/convert'			=> array('creatable', 'convert'),
			'/post/update-status'   => array('creatable', 'update_status'),
		);
		// register routes
		RestApi::register_route($namespace, $routes, $this, new RestApi);
	}

	// -----------------------------------------
	// get posts
	// -----------------------------------------

	public function posts($request) {
		// save projects view setting
		if(isset($request['projects_view']) && !empty($request['projects_view'])) {
			update_option('semplice_projects_view', $request['projects_view']);
		}
		// return
		return new WP_REST_Response(PostQueries::get_posts($request), 200);
	}

	// -----------------------------------------
	// add post
	// -----------------------------------------

	public function add($request) {
		// get post meta and check slashes
		$meta = Basic::check_slashes($request['meta']);
		// make meta an array
		$meta = json_decode($meta, true);
		// save new post
		$create_post = array(
		  'post_title'    => $meta['post-title'],
		  'post_status'   => 'draft',
		  'post_type'	  => $request['post_type'],
		  'post_name'	  => wp_unique_post_slug(sanitize_title($meta['post-title']), '', 'publish', $request['post_type'], 0),
		);
		// Insert the post into the database
		$post_id = wp_insert_post($create_post);
		// project post settings
		if($request['post_type'] == 'project') {
			// post settings
			$post_settings = array(
				'thumbnail' => array(
					'image' => (is_numeric($meta['project-thumbnail'])) ? $meta['project-thumbnail'] : '',
					'width'	=> '',
					'hover_visibility' => 'disabled',
				),
				'meta' => array(
					'post_title' 	=> $meta['post-title'],
					'permalink' 	=> sanitize_title($meta['post-title']),
					'project_type' 	=> $meta['project-type'],
				),
			);
			// save json
			$post_settings = json_encode($post_settings);
			// add to post meta
			update_post_meta($post_id, '_semplice_post_settings', wp_slash($post_settings), '');
		}
		// created with s4 admin so per default set is semplice to true
		update_post_meta($post_id, '_is_semplice', true, '');
		$output = array(
			'post_id' => $post_id
		);
		// portfolio order
		PostQueries::save_portfolio_order($post_id);
		// check if cover slider
		if(isset($meta['content_type']) && $meta['content_type'] == 'coverslider') {
			// set cover slider to true in page meta
			update_post_meta($post_id, '_is_coverslider', true, '');
		}
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// delete post
	// -----------------------------------------

	public function delete($request) {
		// post id
		$post_id = $request['post_id'];
		// delete post
		if($post_id) {
			wp_trash_post($post_id, false);
		}
		return new WP_REST_Response('Deleted', 200);
	}

	// -----------------------------------------
	// duplicate post
	// -----------------------------------------

	public function duplicate($request) {
		// post id
		$post_id = $request['post_id'];
		// get post data
		$post = get_post($post_id);
		// output
		$output = array('html' => '');	 
		// if post data, duplicate
		if(isset($post) && $post !== null) {
	 		// dont add another duplicate if there
			if (strpos($post->post_title, ' - Duplicate') === false) {
				$post->post_title = $post->post_title . ' - Duplicate';
			}
			// create new post data array
			$args = array(
				'ping_status'    => $post->ping_status,
				'post_author'    => $post->post_author,
				'post_content'   => $post->post_content,
				'post_excerpt'   => $post->post_excerpt,
				'post_name'      => wp_unique_post_slug(sanitize_title($post->post_title), '', 'publish', $post->post_type, 0),
				'post_parent'    => $post->post_parent,
				'post_password'  => $post->post_password,
				'post_status'    => 'draft',
				'post_title'     => $post->post_title,
				'post_type'      => $post->post_type,
				'to_ping'        => $post->to_ping,
				'menu_order'     => $post->menu_order
			);
			// insert post
			$new_post_id = wp_insert_post($args);
			// set new post id for output
			$output['id'] = $new_post_id;
			//get all current post terms ad set them to the new post draft
			$taxonomies = get_object_taxonomies($post->post_type);
			foreach ($taxonomies as $taxonomy) {
				$post_terms = wp_get_object_terms($post_id, $taxonomy, array('fields' => 'slugs'));
				wp_set_object_terms($new_post_id, $post_terms, $taxonomy, false);
			}
			// get revisions
			$revisions = $this->db->get_results( 
				"
				SELECT * 
				FROM " . SEMPLICE_REV_TABLE . "
				WHERE post_id = $post_id
				ORDER BY ID ASC
				"
			);
			// post revision
			$post_revision = Get::revision($post_id);
			// add post revision
			update_post_meta($new_post_id, '_semplice_revisions', $post_revision);
			// published revision for the post meta
			$published_revision = '';
			if(!empty($revisions) && count($revisions) > 0) {
				foreach ($revisions as $revision) {
					// get latest version from the semplice revisions and save this to the new post meta field
					$revision_id = $revision->revision_id;
					$row = $this->db->get_row("SELECT * FROM " . SEMPLICE_REV_TABLE . " WHERE post_id = '$post_id' AND revision_id = '$revision_id'");
					// only add content to latest version if available. since its a draft no need to copy the meta field also
					if(null !== $row && !empty($row->content)) {
						// assign content
						$encoded_ram = json_encode(Ram::change_ids($row->content, true, false, 'section'), JSON_FORCE_OBJECT);
						// published revision
						if($revision_id == $post_revision['published']) {
							$published_revision = $encoded_ram;
						}
					} else {
						// set encoded ram to false if there is no ram available
						$encoded_ram = '';
					}
					// save revision in the database
					$this->db->insert(
						SEMPLICE_REV_TABLE, 
						array(
							"post_id"		 => $new_post_id,
							"revision_id"  	 => $revision_id,
							"revision_title" => $revision->revision_title,
							"content"		 => $encoded_ram,
							"settings"		 => $row->settings,
							"wp_changes"	 => 0
						)
					);
				}
			}
			//duplicate all post meta just in two SQL queries
			$post_meta_infos = $this->db->get_results("SELECT meta_key, meta_value FROM {$this->db->postmeta} WHERE post_id=$post_id");
			// meta counter
			$meta_count = 0;
			// are there post metas?
			if(count($post_meta_infos) != 0) {
				// iterate post metas
				foreach ($post_meta_infos as $meta_info) {
					$meta_key = $meta_info->meta_key;
					// if semplice content, update post meta seperately for the json string
					if ($meta_key == '_semplice_content') {
						update_post_meta($new_post_id, '_semplice_content', wp_slash($published_revision));
					} else if($meta_key != '_is_semplice' && $meta_key != '_semplice_revisions') {
						$meta_count++;
						$meta_value = addslashes($meta_info->meta_value);
						$sql_query_sel[]= "SELECT $new_post_id, '$meta_key', '$meta_value'";
					}
				}
				// meta count > 0?
				if($meta_count > 0) {
					$sql_query = "INSERT INTO {$this->db->postmeta} (post_id, meta_key, meta_value)";
					$sql_query.= implode(" UNION ALL ", $sql_query_sel);
					$this->db->query($sql_query);
				}
			}
			// activate semplice
			update_post_meta($new_post_id, '_is_semplice', true, '');
			// get thumbnail
			if($request['post_type'] == 'project') {
				// get thumbnail
				$thumbnail = Thumbnails::get($post_id, false, 'medium_large');
			} else {
				$thumbnail = false;
			}
			// if dashboard, set projects view to thumb
			$projects_view = Get::projects_view();
			if($request['page'] == 'dashboard') {
				$projects_view = 'thumb';
				$request['post_type'] = 'project';
			}
			// format post
			$post_array = array(
				'ID' 			=> $new_post_id,
				'post_title' 	=> $post->post_title,
				'post_name' 	=> $args['post_name'],
				'post_status'	=> 'draft'
			);
			$output['html'] .= PostQueries::post_row($post_array, $request['post_type'], true, $thumbnail, true, $projects_view, false);
		} else {
			$output['html'] = 'Post creation failed, could not find original post: ' . $post_id;
		}
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// pin post
	// -----------------------------------------

	public function pin($request) {
		// vars
		$mode = $request['mode'];
		$id = $request['id'];
		// get pinned posts
		$pinned = PostQueries::get_pinned();
		if($pinned && !empty($pinned)) {
			if($mode == 'favorite') {
				$pinned[] = $id;
			} else {
				$pos = array_search($id, $pinned);
				unset($pinned[$pos]);
				// reconstruct array so it starts with 0, otherwise it would turn into object
				$pinned = array_values($pinned);
			}
		} else if(!$pinned && $mode == 'favorite') {
			$pinned = array($id);
		}
		// update option
		update_option('semplice_pinned', json_encode($pinned));
		// return
		return new WP_REST_Response($pinned, 200);
	}

	// -----------------------------------------
	// save portfolio order
	// -----------------------------------------

	public function portfolio_order($request) {
		// get settings and add or remove slashes
		$order = $request['order'];
		// save settings in the DB
		update_option('semplice_portfolio_order', $order);
		return new WP_REST_Response('saved', 200);
	}

	// -----------------------------------------
	// convert to semplice
	// -----------------------------------------
	
	public function convert($request) {
		// created with s4 admin so per default set is semplice to true
		update_post_meta($request['post_id'], '_is_semplice', true, '');
		// return
		return new WP_REST_Response('Activated Semplice', 200);
	}

	// -----------------------------------------
	// update status
	// -----------------------------------------
	
	public function update_status($request) {
		// update
		if(get_post_status($request['id'])) {
			// change post status
			wp_update_post(array(
				'ID' => $request['id'],
				'post_status' => $request['status'],
			));
		}
		// return
		return new WP_REST_Response('Status Update', 200);
	}
}

// init
new RestApiPosts;

?>