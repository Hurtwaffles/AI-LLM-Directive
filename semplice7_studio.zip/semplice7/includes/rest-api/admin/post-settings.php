<?php

// namespace
namespace Semplice\RestApi\Admin;

// use
use Semplice\Admin\PostSettings;
use Semplice\Admin\Dashboard;
use Semplice\Helper\Basic;
use Semplice\Helper\RestApi;
use Semplice\Helper\PostQueries;
use Semplice\Helper\Generate;
use Semplice\Helper\Image;
use WP_REST_Response;

// -----------------------------------------
// post settings api
// -----------------------------------------

class RestApiPostSettings {

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// call register routes on rest api init
		add_action('rest_api_init', array(&$this, 'register_routes'));
	}

	// -----------------------------------------
	// rest routes
	// -----------------------------------------

	public function register_routes() {
		// version
		$ver = '1';
		$namespace = 'semplice/v' . $ver . '/admin';
		// routes
		$routes = array(
			'/post-settings/init' => array('readable', 'init'),
			'/post-settings/save' => array('creatable', 'save'),
			'/post-settings/add-category' => array('creatable', 'add_category'),
			'/post-settings/remove-category' => array('creatable', 'remove_category'),
		);
		// register routes
		RestApi::register_route($namespace, $routes, $this, new RestApi);
	}

	// -----------------------------------------
	// init
	// -----------------------------------------

	public function init($request) {
		// vars
		$id = $request['id'];
		$output = array(
			'settings'    => '',
			'type' 		  => get_post_type($id),
			'thumbnail'	  => array(),
			'postSelect' => array(
				'footer'  => PostQueries::post_dropdown('footer'),
				'project' => PostQueries::post_dropdown('project')
			),
		);
		// get post
		$post = get_post($id);
		// get post settings from the meta options
		if($request['type'] == 'wpTemplate') {
			$settings = json_decode(get_option('semplice_template_' . $id . '_settings'), true);
		} else {
			$settings = json_decode(get_post_meta($id, '_semplice_post_settings', true), true);
		}
		// thumbnail
		if(isset($settings['thumbnail']) && isset($settings['thumbnail']['image'])) {
			$output['thumbnail'][$settings['thumbnail']['image']] = Image::get($settings['thumbnail']['image'], 'full');
		}
		// check if array
		$settings = (!is_array($settings)) ? false : $settings;
		// get post settings
		$output['settings'] = ($request['type'] == 'wpTemplate') ? Generate::template_settings($settings) : Generate::post_settings($settings, $post);
		// return settings
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// save
	// -----------------------------------------

	public function save($request) {
		// output
		$output = '';
		// save
		$args = PostSettings::save($request,  $request['post_id'], $request['post_type']);
		// update post args
		$args['ID'] = $request['post_id'];
		// update post
		if(!Basic::boolval($request['wp_template'])) {
			wp_update_post($args);
		}
		// is dashboard?
		if($request['active_page'] == 'dashboard') {
			// set post settings
			$request['is_post_settings'] = true;
			$output = Dashboard::output();
		} else if($request['origin'] == 'admin') {
			$output = PostQueries::get_posts($request);
		}
		// output
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// add category
	// -----------------------------------------

	public function add_category($request) {
		// define output
		$output = array();
		// return id of new category
		$output['id'] = wp_insert_term($request['name'], 'category', $args = array('parent' => $request['parent']));
		// get updated list of category dropdown
		$output['dropdown'] = wp_dropdown_categories('hide_empty=0&echo=0&depth=5&hierarchical=1');
		// return
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// remove category
	// -----------------------------------------

	public function remove_category($request) {
		// define output
		$output = '';
		// remove category
		wp_delete_term($request['term_id'], 'category', '');
		// get updated list of category dropdown
		$output = wp_dropdown_categories('hide_empty=0&echo=0&depth=5&hierarchical=1');
		// return
		return new WP_REST_Response($output, 200);	
	}
}

// init
new RestApiPostSettings;

?>