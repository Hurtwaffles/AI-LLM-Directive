<?php

// namespace
namespace Semplice\RestApi\Admin;

// use
use Semplice\Admin\Dashboard;
use Semplice\Admin\Onboarding;
use Semplice\Helper\Basic;
use Semplice\Helper\RestApi;
use WP_REST_Response;

// -----------------------------------------
// core api
// -----------------------------------------

class RestApiCore {

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// add action
		add_action('init', array(&$this, 'register_semplice_folder'));
		// call register routes on rest api init
		add_action('rest_api_init', array(&$this, 'register_routes'));
	}

	// -----------------------------------------
	// rest routes
	// -----------------------------------------

	public function register_routes() {
		// version
		$ver = '1';
		$namespace = 'semplice/v' . $ver . '/admin';
		// routes
		$routes = array(
			'/dashboard' => array('readable', 'dashboard'),
			'/onboarding' => array('creatable', 'onboarding'),
			'/whats-new' => array('creatable', 'whats_new'),
			'/ep-size' => array('creatable', 'ep_size'),
			'/hide-welcome-banner' => array('creatable', 'hide_welcome')
		);
		// register routes
		RestApi::register_route($namespace, $routes, $this, new RestApi);
	}

	// -----------------------------------------
	// register semplice folder taxonomy
	// -----------------------------------------

	public function register_semplice_folder() {
		// registe taxonomy
		register_taxonomy(
			'semplice_folder',
			'attachment',
			array(
				'label' => 'Semplice Folder',
				'hierarchical' => false,
				'query_var' => true,
			)
		);
	}

	// -----------------------------------------
	// dashboard
	// -----------------------------------------

	public function dashboard() {
		return new WP_REST_Response(Dashboard::output(), 200);
	}

	// -----------------------------------------
	// save onboarding
	// -----------------------------------------

	public function onboarding($request) {
		// save
		Onboarding::save($request);
		// return
		return new WP_REST_Response('Onboarding completed.', 200);
	}

	// -----------------------------------------
	// whats new
	// -----------------------------------------

	public function whats_new() {
		update_option('semplice_whats_new', SEMPLICE_VER);
		return new WP_REST_Response('', 200);
	}

	// -----------------------------------------
	// edit popup size
	// -----------------------------------------

	public function ep_size($request) {
		// hid welcome banner
		update_option('semplice_ep_size', $request['size']);
		// return
		return new WP_REST_Response('', 200);
	}

	// -----------------------------------------
	// close welcome banner
	// -----------------------------------------

	public function hide_welcome() {
		// hid welcome banner
		update_option('semplice_welcome', true);
		// return
		return new WP_REST_Response('', 200);
	}
}

// init
new RestApiCore;

?>