<?php

// namespace
namespace Semplice\RestApi\Admin;

// use
use Semplice\Helper\Basic;
use Semplice\Helper\Image;
use Semplice\Helper\RestApi;
use WP_REST_Response;

// -----------------------------------------
// media api
// -----------------------------------------

class RestApiMedia {

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// call register routes on rest api init
		add_action('rest_api_init', array(&$this, 'register_routes'));
	}

	// -----------------------------------------
	// rest routes
	// -----------------------------------------

	public function register_routes() {
		// version
		$ver = '1';
		$namespace = 'semplice/v' . $ver . '/admin';
		// routes
		$routes = array(
			'/media/get'			=> array('readable', 'get_media'),
			'/media/search'			=> array('readable', 'search_media'),
			'/media/delete'			=> array('creatable', 'delete_media'),
			'/media/folder/add'		=> array('creatable', 'add_folder'),
			'/media/folder/rename'	=> array('creatable', 'rename_folder'),
			'/media/folder/delete'	=> array('creatable', 'delete_folder'),
			'/media/add-to-folder'	=> array('creatable', 'add_to_folder'),
			'/media/meta/get'		=> array('readable', 'get_meta'),
			'/media/meta/save'		=> array('creatable', 'save_meta'),
		);
		// register routes
		RestApi::register_route($namespace, $routes, $this, new RestApi);
	}

	// -----------------------------------------
	// get
	// -----------------------------------------

	public function get_media($request) {
		// type and id
		$type = $request['type'];
		$id = $request['id'];
		// is end
		$is_end = false;
		// get folders
		$output = $this->get_sidebar($id);
		// attachments & details header
		$output .= '
			<div class="sml-details-header">
				<div class="thumbnail">#</div>
				<div class="sml-details-inner">
					<div class="filename">Filename</div>
					<div class="type">Type</div>
					<div class="dimension">Dimension</div>
					<div class="size">Filesize</div>
				</div>
			</div>
			<div class="sml-attachments" data-offset="' . $request['offset'] . '">
				<div class="sml-empty-state"><p>Drop your files here</p></div>
				<div class="sml-attachments-inner">
		';
		// tax query args
		$tax_query_args = array(
			'taxonomy' => 'semplice_folder',
			'operator' => 'NOT EXISTS'
		);
		if($type == 'folder' && is_numeric($id)) {
			$tax_query_args = array(
				'taxonomy' => 'semplice_folder',
				'field' => 'term_id',
				'terms' => $id
			);
		}
		// get posts
		$args = array(
			'post_type' => 'attachment',
			'post_status' => null,
			'numberposts' => 80,
			'offset' => $request['offset'],
			'orderby' => 'ID', 
			'tax_query' => array($tax_query_args),
		);
		// asset link?
		if($type == 'asset') {
			if($id != 'all') {
				$args['post_mime_type'] = $id;
			}
			unset($args['tax_query']);
		}
		// get posts
		$attachments = get_posts($args);
		// attachments html
		$attachments_html = '';
		// has posts?
		if(is_array($attachments) && !empty($attachments)){
			foreach($attachments as $attachment){
				// add to output
				$attachments_html .= $this->get_attachment($attachment);
			}
		}
		// is lazy load?
		if($request['offset'] > 0) {
			// is already smaller 120?
			if(count($attachments) < 80) {
				$is_end = true;
			}
			// is no new attachment?
			if(count($attachments) > 0) {
				$output = $attachments_html;
			} else {
				$output = '';
			}
		} else {
			$output .= $attachments_html . '</div></div>';
		}
		// return
		return new WP_REST_Response(array('html' => $output, 'is_end' => $is_end), 200);
	}

	// -----------------------------------------
	// search media
	// -----------------------------------------

	public function search_media($request) {
		// output
		$output = '';
		// keyword
		$keyword = $request['keyword'];
		// wpdb (this->db not working here)
		global $wpdb;
		// search posts
		$attachments = $wpdb->get_results(
			$wpdb->prepare (
				"
				SELECT *
				FROM $wpdb->posts
				WHERE post_type = 'attachment' AND post_title LIKE '%s'
				OR post_type = 'attachment' AND post_excerpt LIKE '%s'
				OR post_type = 'attachment' AND post_content LIKE '%s'
				ORDER BY ID DESC
				",
				'%' . $wpdb->esc_like($keyword) . '%',
				'%' . $wpdb->esc_like($keyword) . '%',
				'%' . $wpdb->esc_like($keyword) . '%'
			),
			OBJECT
		);
		// has posts?
		if(is_array($attachments) && !empty($attachments)){
			foreach($attachments as $attachment){
				// add to output
				$output .= $this->get_attachment($attachment);
			}
		} else {
			$output .= '<div class="sml-empty-search"><p>No attachments found for "' . $keyword . '"</p></div>';
		}
		// return
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// delete media
	// -----------------------------------------

	public function delete_media($request) {
		// attachments
		$attachments = $request['attachments'];
		// make sure its an array
		if(is_array($attachments)) {
			// set object term for each image
			foreach ($attachments as $attachment => $id) {
				// delete attachment
				wp_delete_attachment($id, true);
				// delete object term relationships
				wp_delete_object_term_relationships($id,'semplice_folder');
			}
		}
		// return
		return new WP_REST_Response($attachments, 200);
	}

	// -----------------------------------------
	// add folder
	// -----------------------------------------

	public function add_folder($request) {
		// output
		$output = array(
			'term' => wp_insert_term($request['title'], 'semplice_folder'),
			'sidebar' => $this->get_sidebar($request['active']),
		);
		// return
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// rename folder
	// -----------------------------------------

	public function rename_folder($request) {
		// output
		$output = array(
			'term' => wp_update_term($request['id'], 'semplice_folder', array('name' => $request['title'])),
			'sidebar' => $this->get_sidebar($request['active']),
		);
		// return
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// delete folder
	// -----------------------------------------

	public function delete_folder($request) {
		// delete term first
		$term = wp_delete_term($request['id'], 'semplice_folder');
		// attachments html
		$attachments_html = '';
		// is active folder the same as folder id?
		if($request['active_folder'] == $request['id'] || $request['active_folder'] == 'uncategorized') {
			// get uncategorized attachments
			$args = array(
				'post_type' => 'attachment',
				'post_status' => null,
				'numberposts' => 120,
				'offset' => 0,
				'tax_query' => array(
					array(
						'taxonomy' => 'semplice_folder',
						'operator' => 'NOT EXISTS',
					),
				),
			);
			// get posts
			$attachments = get_posts($args);
			// attachments html
			$attachments_html = '';
			// has posts?
			if(is_array($attachments) && !empty($attachments)){
				foreach($attachments as $attachment){
					// add to output
					$attachments_html .= $this->get_attachment($attachment);
				}
			} else {
				$attachments_html .= '<div class="sml-empty-state"><p>Drop your files here</p></div>';
			}
		}
		// output
		$output = array(
			'term' => $term,
			'sidebar' => $this->get_sidebar($request['active']),
			'attachments' => $attachments_html,
		);
		// return
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// add to folder
	// -----------------------------------------

	public function add_to_folder($request) {
		// attachments
		$attachments = $request['attachments'];
		// make sure its an array
		if(is_array($attachments)) {
			// set object term for each attachment
			foreach ($attachments as $attachment => $id) {
				wp_set_object_terms($id, intval($request['folder']), 'semplice_folder');
			}
		}
		// return
		return new WP_REST_Response('Add to folder', 200);
	}

	// -----------------------------------------
	// get meta
	// -----------------------------------------

	public function get_meta($request) {
		$output = '';
		// attachments
		$attachment = get_post($request['id']);
		// make sure its an array
		if(is_object($attachment)) {
			// get alt text
			$alt_text = Image::alt($attachment->ID);
			// get sizes
			$sizes = wp_get_attachment_image_src($attachment->ID, 'full', false);
			if(false === $sizes) {
				$sizes = array(0,0,0);
			}
			// file size
			$file = get_attached_file($request['id']);
			$filesize = filesize($file); // bytes
			$filesize = round($filesize / 1024, 2);
			// get attachment url
			$attachment_url = wp_get_attachment_url($attachment->ID);
			// add metas
			$output = array(
				'url' => $attachment_url,
				'width' => $sizes[1],
				'height' => $sizes[2],
				'size' => $filesize,
				'date' => $attachment->post_date,
				'title' => $attachment->post_title,
				'caption' => $attachment->post_excerpt,
				'alt' => $alt_text,
				'description' => $attachment->post_content,
				'mime' => $attachment->post_mime_type,
			);
		}
		// return
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// get meta
	// -----------------------------------------

	public function save_meta($request) {
		// attachments
		$meta = json_decode($request['meta'], true);
		// make sure its an array
		if(null !== $meta && is_array($meta) && !empty($meta)) {
			// args
			$post_args = array(
				'ID' => $request['id'],
				'post_title' => $meta['title'],
				'post_excerpt' => $meta['caption'],
				'post_content' => $meta['description']
			);
			// update post
			wp_update_post($post_args);
			// save alt
			if(!empty($meta['alt'])) {
				update_post_meta($request['id'], '_wp_attachment_image_alt', $meta['alt']);
			}
		}
		// return
		return new WP_REST_Response('Save meta', 200);
	}	

	// ----------------------------------------
	// get attachment
	// ----------------------------------------

	function get_attachment($attachment) {
		// defaults
		$ratio = 'landscape';
		$title = '';
		$thumbnail = '';
		$classes = '';
		$sizes = array(0 => 0, 1 => 0, 2 => 0);
		// image attachment
		if(strpos($attachment->post_mime_type, 'image') !== false) {
			// get image urls
			$image_urls = array(
				'full' 			=> wp_get_attachment_image_url($attachment->ID, 'full'),
				'medium'		=> wp_get_attachment_image_url($attachment->ID, 'medium'),
				'medium_large'	=> wp_get_attachment_image_url($attachment->ID, 'medium_large')
			);
			// attachment urls
			$attachment_urls = 'data-attachment-url="' . $image_urls['full'] . '" data-attachment-sizes=\'{"medium": "' . $image_urls['medium'] . '", "medium_large": "' . $image_urls['medium_large'] . '"}\'';
			// ratio
			
			$sizes = wp_get_attachment_image_src($attachment->ID, 'full', false);
			$ratio = ($sizes[2] > $sizes[1]) ? 'portrait' : 'landscape';
			// thumbnail
			$thumbnail = '<img src="' . $image_urls['medium_large'] . '" onerror="this.onerror=null; this.src=\'' . SEMPLICE_URI . '/assets/images/admin/missing_image.png\'">';
			// add class
			$classes = 'sml-image';
		} else {
			// url
			$url = wp_get_attachment_url($attachment->ID);
			// get attachment url
			$attachment_urls = 'data-attachment-url="' . $url . '"';
			// add class
			$classes = 'sml-non-image';
		}
		// add to output
		return '
			<div id="attachment-' . $attachment->ID . '" class="sml-attachment" data-attachment-mime="' . $attachment->post_mime_type . '" data-attachment-id="' . $attachment->ID. '" ' . $attachment_urls . ' data-attachment-width="' . $sizes[1] . '" data-attachment-height="' . $sizes[2] . '">
				<div class="sml-attachment-inner">
					<div class="sml-thumbnail ' . $classes . ' ' . $ratio . '" data-mime-type="' . $attachment->post_mime_type . '">
						<div class="centered">
							' . $thumbnail . '
						</div>
						<div class="sml-meta"><a class="sml-show-meta click-handler" data-handler="run" data-action-type="mlMeta" data-action="get" data-attachment-id="' . $attachment->ID . '"></a></div>
					</div>
				</div>
				<div class="sml-filename">' . Basic::ellipsis(basename($attachment->guid), 'left', 18) . '</div>
				<div class="sml-details">
					<div class="filename">' . Basic::ellipsis(basename($attachment->guid), 'left', 30) . '</div>
					<div class="type">' . $attachment->post_mime_type . '</div>
					<div class="dimension"><span>' . $sizes[1] . '</span> × <span>' . $sizes[2] . '</span></div>
					<div class="size">' . round((wp_filesize(get_attached_file($attachment->ID)) / 1024), 2) . ' kb</div>
				</div>
			</div>
		';
	}

	// ----------------------------------------
	// get sidebar
	// ----------------------------------------

	function get_sidebar($id) {
		// define custom folders
		$custom_folders = '';
		// get folders
		$folders = get_terms(array('taxonomy' => 'semplice_folder', 'hide_empty' => 0));
		if(is_array($folders) && !empty($folders)) {
			foreach ($folders as $folder) {
				// active folder
				$active = ($id == $folder->term_id) ? ' active' : '';
				// title
				$edited_name = $folder->name;
				// folders html
				$custom_folders .= '
					<li class="sml-folder' . $active . '" data-type="folder" data-id="' . $folder->term_id . '"><span>' . $edited_name . '</span>
						<div class="folder-options">
							<a class="rename-folder click-handler" data-handler="run" data-action-type="dialog" data-action="renameFolder" data-setting-type="mediaLibrary" data-id="' . $folder->term_id . '" data-folder-name="' . $folder->name . '"></a>
							<a class="remove-folder click-handler" data-handler="run" data-action-type="dialog" data-action="deleteFolder" data-setting-type="mediaLibrary" data-id="' . $folder->term_id . '"></a>
						</div>
					</li>
				';
			}
		}
		// assets
		$asset_types = array(
			'image' 			=> 'Images',
			'video' 			=> 'Videos',
			'image/svg+xml' 	=> 'SVGs',
			'font' 				=> 'Fonts',
			'application/json' 	=> 'Lottie'
		);
		$assets = '';
		foreach($asset_types as $asset_type => $asset_name) {
			// active folder
			$active = ($asset_type == $id) ? ' active' : '';
			// add to assets
			$assets .= '<li class="sml-asset' . $active . '" data-type="asset" data-id="' . $asset_type . '">' . $asset_name . '</li>';
		}
		// folders
		return '
			<div class="sml-sidebar">
				<div class="sml-sidebar-inner">
					<div class="sml-assets">
						<div class="sml-assets-header">
							<h4>Assets</h4>
						</div>
						<ul>
							<li class="sml-asset' . (($id == 'all') ? ' active' : '') . '" data-type="asset" data-id="all">All</li>
							' . $assets . '
						</ul>
					</div>
					<div class="sml-folders">
						<div class="sml-folders-header">
							<h4>My Folders</h4>
						</div>
						<ul>
							<li class="sml-folder' . (($id == 'uncategorized') ? ' active' : '') . '" data-type="folder" data-id="uncategorized">Unsorted</li>
							' . $custom_folders . '
						</ul>
						<div class="add-sml-folder click-handler" data-handler="run" data-action-type="dialog" data-action="addFolder" data-setting-type="mediaLibrary"></div>
					</div>
				</div>
			</div>
		';
	}
}

// init
new RestApiMedia;
?>