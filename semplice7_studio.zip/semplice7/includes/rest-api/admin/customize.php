<?php

// namespace
namespace Semplice\RestApi\Admin;

// use
use Semplice\Admin\Customize;
use Semplice\Helper\Basic;
use Semplice\Helper\RestApi;
use Semplice\Helper\Menu;
use Semplice\Helper\PostQueries;
use WP_REST_Response;

// -----------------------------------------
// customize api
// -----------------------------------------

class RestApiCustomize {
	
	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// call register routes on rest api init
		add_action('rest_api_init', array(&$this, 'register_routes'));
	}

	// -----------------------------------------
	// rest routes
	// -----------------------------------------

	public function register_routes() {
		// version
		$ver = '1';
		$namespace = 'semplice/v' . $ver . '/admin';
		// routes
		$routes = array(
			'/customize/init' 					=> array('readable', 'init'),
			'/customize/save' 					=> array('creatable', 'save'),
			'/customize/navigation/edit' 		=> array('creatable', 'edit_nav'),
			'/customize/navigation/add-menu' 	=> array('creatable', 'add_menu'),
			'/customize/navigation/save-menu' 	=> array('creatable', 'save_menu'),
			'/customize/navigation/remove-menu' => array('creatable', 'remove_menu'),
			'/reset-template'					=> array('creatable', 'reset_template')
		);
		// register routes
		RestApi::register_route($namespace, $routes, $this, new RestApi);
	}

	// -----------------------------------------
	// customize
	// -----------------------------------------

	public function init($request) {
		// init setting
		$output = array(
			'content' => Customize::$setting[$request['setting']]->init(),
			'actions' => Customize::actions($request['setting']),
			'css'		=> array(
				'grid'			=> Customize::$setting['grid']->css(false),
				'typography'	=> Customize::$setting['typography']->get(true, true),
				'webfonts'		=> Customize::$setting['webfonts']->generate_css(false),
				'advanced'		=> Customize::$setting['advanced']->css(false)
			),
			'postSelect' => array(
				'page'	  => PostQueries::post_dropdown('page'),
				'project' => PostQueries::post_dropdown('project'),
				'footer'  => PostQueries::post_dropdown('footer')
			),
		);
		// return
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// save
	// -----------------------------------------

	public function save($request) {
		// get settings and add or remove slashes
		$settings = Basic::check_slashes($request['settings']);
		// get setting type
		$setting = $request['setting'];
		// save settings in the DB
		update_option('semplice_customize_' . $setting, $settings);
		update_option('semplice_admin_images', $request['images']);
		update_option('semplice_custom_colors', $request['custom_colors']);
		// return
		return new WP_REST_Response('', 200);
	}

	// -----------------------------------------
	// edit navigation
	// -----------------------------------------

	public function edit_nav($request) {
		// nav ram
		$content = Basic::check_slashes($request['ram']);
		// output
		return new WP_REST_Response(Customize::$setting['navigations']->get(json_decode($content, true), false, true), 200);
	}

	// -----------------------------------------
	// add menu
	// -----------------------------------------

	public function add_menu($request) {
		// output
		return new WP_REST_Response(Menu::add(), 200);
	}

	// -----------------------------------------
	// save menu
	// -----------------------------------------

	public function save_menu($request) {
		// nav ram
		$menu = Basic::check_slashes($request['menu']);
		// output
		return new WP_REST_Response(Menu::save($request['id'], $menu), 200);
	}

	// -----------------------------------------
	// remove menu
	// -----------------------------------------

	public function remove_menu($request) {
		// output
		return new WP_REST_Response(Menu::remove($request), 200);
	}

	// -----------------------------------------
	// reset template
	// -----------------------------------------

	public function reset_template($request) {
		// remove options
		delete_option('semplice_template_' . $request['template']);
		delete_option('semplice_template_' . $request['template'] . '_settings');
		// get template
		$content_json = file_get_contents(get_template_directory() . '/assets/json/wp-templates/' . $request['template'] . '.json');
		// save default to template
		update_option('semplice_template_' . $request['template'], $content_json);
		return new WP_REST_Response('reset template successful.', 200);
	}
}

// init
new RestApiCustomize;

?>