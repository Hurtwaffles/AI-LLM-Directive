<?php

// namespace
namespace Semplice\RestApi\Editor;

// use
use Semplice\Editor;
use Semplice\Editor\Revisions;
use Semplice\Editor\Components;
use Semplice\Editor\Sidebar;
use Semplice\Helper\Basic;
use Semplice\Helper\Get;
use Semplice\Helper\Covers;
use Semplice\Helper\Image;
use Semplice\Helper\Generate;
use Semplice\Helper\Ram;
use Semplice\Helper\Thumbnails;
use Semplice\Helper\PostQueries;
use Semplice\Helper\RestApi;
use Semplice\Admin\Customize;
use WP_REST_Response;

// -----------------------------------------
// core api
// -----------------------------------------

class RestApiCore {

	// -----------------------------------------
	// public vars
	// -----------------------------------------

	public $db;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// database
		global $wpdb;
		$this->db = $wpdb;
		// call register routes on rest api init
		add_action('rest_api_init', array(&$this, 'register_routes'));
	}

	// -----------------------------------------
	// rest routes
	// -----------------------------------------

	public function register_routes() {
		// version
		$ver = '1';
		$namespace = 'semplice/v' . $ver . '/editor';
		// routes
		$routes = array(
			'/init' 	 			=> array('readable', 'init'),
			'/duplicate' 			=> array('creatable', 'duplicate'),
			'/masonry' 	 			=> array('creatable', 'masonry'),
			'/single-project'		=> array('creatable', 'single_project'),
			'/flickity'  			=> array('creatable', 'flickity'),
			'/edit-apg'  			=> array('creatable', 'apg'),
			'/import-cover' 		=> array('creatable', 'import_cover'),
			'/coverslider'  		=> array('creatable', 'coverslider'),
			'/save-animate-presets' => array('creatable', 'save_animate_presets'),
			'/mark-notice' 			=> array('creatable', 'mark_notice')
		);
		// register routes
		RestApi::register_route($namespace, $routes, $this, new RestApi);
	}

	// -----------------------------------------
	// init editor
	// -----------------------------------------

	public function init($request) {
		// get output
		$output = ($request['mode'] == 'wpTemplate') ? $this->edit_template($request) : $this->edit_post($request);
		// output
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// edit post
	// -----------------------------------------

	public function edit_post($request) {
		// get post object
		$post_obj = get_post($request['id']);
		// define local post
		$post = array(
			'id'	   		=> $post_obj->ID,
			'type'	   		=> get_post_type($request['post_type_id']),
			'revision' 		=> Revisions::post($post_obj->ID),
			'status'   		=> get_post_status($post_obj->ID),
			'title'			=> $post_obj->post_title,
			'password'		=> (!empty($post_obj->post_password)) ? $post_obj->post_password : '',
			'permalink'		=> get_permalink($post_obj->ID),
		);
		// revision id
		$revision_id = $post['revision']['active'];
		// get revision
		$revision = Revisions::get($revision_id, $post['id']);
		// components and import
		if($revision !== null && isset($revision->content)) {
			// has content already?
			if(!empty($revision->content)) {
				$revision->content = Components::get($revision->content);
				// change the ids on import
				if(Basic::boolval($request['is_import'])) {
					$revision->content = json_encode(Ram::change_ids($revision->content, true, false, 'section'), JSON_FORCE_OBJECT);
				}
			} else {
				$revision->content = 'empty';
			}
			// get ram
			$ram = json_decode($revision->content, true);
		} else {
			$ram = false;
			// dont add latest version to the original template post
			if(!Basic::boolval($request['is_import'])) {
				// save revision in the database
				$this->db->insert(
					SEMPLICE_REV_TABLE,
					array(
						"post_id"		 => $post['id'],
						"revision_id"  	 => 'latest_version',
						"revision_title" => 'Latest Version',
						"content"		 => '',
						"settings"		 => '',
						"wp_changes"	 => 0
					)
				);
			}
		}
		// get post settings from post meta
		$post_settings = json_decode(get_post_meta($post['id'], '_semplice_post_settings', true), true);
		// generate post settings
		if($post['type'] != 'footer') {
			$post_settings = Generate::post_settings($post_settings, $post_obj);
		} else {
			// make sure to empty 'branding' for the footer so it will not overwrite things
			if(is_array($ram) && isset($ram['branding'])) {
				$ram['branding'] = array();
			}
			$post_settings = false;
		}
		// add settings to post
		$post['settings'] = $post_settings;
		// get thumbnail
		$thumbnail = Thumbnails::get_id($post['id']);
		// define images
		$images = (!empty($thumbnail)) ? array($thumbnail => Image::get($thumbnail, 'full')) : array();
		// get cover slider
		$is_coverslider = Basic::boolval(get_post_meta($post['id'], '_is_coverslider', true));
		// slider ram
		$slider_ram = array();
		// customize css
		$css = array(
			'post'			=> '',
			'module'		=> '',
			'grid'			=> Customize::$setting['grid']->css(false),
			'typography'	=> Customize::$setting['typography']->get(true, false),
			'webfonts'		=> Customize::$setting['webfonts']->generate_css(false),
			'thumbhover'	=> Customize::$setting['thumbhover']->css(false, false, true, '#content-holder [data-module="singleproject"]', false),
			'advanced'		=> Customize::$setting['advanced']->css(false)
		);
		// is ram not completely empty?
		if(!empty($ram)) {
			// add empty post filter
			$ram['posts_filter'] = false;
			// get content
			if($is_coverslider) {
				$content = Covers::coverslider($post['id'], (isset($ram['coverslider'])) ? $ram['coverslider'] : array(), 'editor');
				// add slider ram
				$slider_ram = (!empty($content['slider_ram'])) ? $content['slider_ram'] : $slider_ram;
			} else {
				$content = Editor::output($ram, true, false, false);
			}
			// add background images from styles
			if(isset($content['images'])) {
				$ram['images'] = $ram['images'] + $content['images'];
			}
			// images
			if(is_array($ram['images'])) {
				foreach ($ram['images'] as $image_id => $src) {
					// add image
					$images[$image_id] = Image::get($image_id, 'full');
				}
			}
			// add post css
			$css['post'] = $content['css'];
			// module css
			if(isset($content['module_css'])) {
				$css['module'] = $content['module_css'];
			}
			// set output ram to revision content
			$output_ram = $revision->content;
			// set output html
			$output_html = $content['html'];
		} else {
			// is coverslider?
			if($is_coverslider) {
				// generate covers
				$content = Covers::coverslider($post['id'], array(), 'editor');
				// add html
				$output_html = $content['html'];
				// css
				$css['post'] = $content['css'];
			} else {
				// since completely empty ram only get default hidden cover
				$output_html = Covers::default('hidden') . '</smp-container></smp-section>';
			}
			// set output ram to empty
			$output_ram = false;
		}
		// output
		$output = array(
			'ram' 		 		=> $output_ram,
			'html'  	 		=> $output_html,
			'css'		 		=> $css,
			'images'  	 		=> $images,
			'post'				=> $post,
			'navigator'			=> Sidebar::navigator(),
			'postQueries'		=> PostQueries::init_editor(),
			'isCoverslider'		=> $is_coverslider,
			'sliderRam'			=> json_encode($slider_ram, JSON_FORCE_OBJECT),
			'postSelect' 		=> array(
				'page'			=> PostQueries::post_dropdown('page'),
				'project' 		=> PostQueries::post_dropdown('project'),
				'footer'  		=> PostQueries::post_dropdown('footer')
			),
			'revisions'			=> Revisions::list($post['id']),
		);
		return $output;
	}

	// -----------------------------------------
	// edit template
	// -----------------------------------------

	public function edit_template($request) {
		// get post object
		$template = array(
			'id'	   => $request['id'],
			'settings' => json_decode(get_option('semplice_template_' . $request['id'] . '_settings'), true)
		);
		// get content
		$content_json = get_option('semplice_template_' . $template['id']);
		// init masterblocks or get default template
		$content_json = Components::get($content_json);
		// generate post settings
		$template['settings'] = Generate::template_settings($template['settings']);
		// make ram
		$ram = json_decode($content_json, true);
		// images array
		$images = array();
		// customize css
		$css = array(
			'post'			=> '',
			'module'		=> '',
			'grid'			=> Customize::$setting['grid']->css(false),
			'typography'	=> Customize::$setting['typography']->get(true, false),
			'webfonts'		=> Customize::$setting['webfonts']->generate_css(false),
			'thumbhover'	=> Customize::$setting['thumbhover']->css(false, false, true, '#content-holder [data-module="singleproject"]', false),
			'advanced'		=> Customize::$setting['advanced']->css(false)
		);
		// check if ram is empty
		if(!empty($ram)) {
			// posts filter
			$ram['posts_filter'] = array(
				'type' => $template['id'],
				'meta' => false
			);
			// get content
			$content = Editor::output($ram, true, false, false);
			// add background images from styles
			if(isset($content['images'])) {
				$ram['images'] = $ram['images'] + $content['images'];
			}
			// images
			if(is_array($ram['images'])) {
				foreach ($ram['images'] as $image_id => $src) {
					// add image
					$images[$image_id] = Image::get($image_id, 'full');
				}
			}
			// add post css
			$css['post'] = $content['css'];
			// module css
			if(isset($content['module_css'])) {
				$css['module'] = $content['module_css'];
			}
			// set output ram to revision content
			$output_ram = $content_json;
			// set output html
			$output_html = $content['html'];
		}
		// output
		$output = array(
			'ram' 		 		=> $output_ram,
			'html'  	 		=> $output_html,
			'css'		 		=> $css,
			'images'  	 		=> $images,
			'post'				=> array(
				'id'			=> $template['id'],
				'type'			=> 'wp-template',
				'settings'		=> $template['settings']
			),
			'navigator'			=> Sidebar::navigator(),
			'postQueries'		=> PostQueries::init_editor(),
			'postSelect' 		=> array(
				'footer'  		=> PostQueries::post_dropdown('footer'),
				'project' 		=> PostQueries::post_dropdown('project')
			)
		);
		return $output;
	}

	// -----------------------------------------
	// duplicate
	// -----------------------------------------
	
	public function duplicate($request) {
		// vars
		$output = array();
		$content = Basic::check_slashes($request['content']);
		$id = $request['id'];
		$mode = $request['mode'];
		// switch mode
		switch($request['mode']) {
			case 'section':
			case 'column':
			case 'subrow':
				// change ids
				$content = Ram::change_ids($content, true, false, $mode);
				// add ram to output
				$output['ram'] = json_encode($content, JSON_FORCE_OBJECT);
				// get new id
				$output['newId'] = array_keys($content['order'])[0];
				// flat order if needed
				$flat_order = ($mode == 'column' || $mode == 'subrow') ? Ram::{$mode . '_order'}($content, false) : false;
				// get duplicate
				$duplicate = Editor::output($content, true, $flat_order, false);
			break;
			case 'content':
				$duplicate = Editor::output(json_decode($content, true), true, array($id), false);
			break;
		}
		// add duplicate to output
		$output['html'] = $duplicate['html'];
		// add css output
		$output['css'] = $duplicate['css'];
		// add module css
		$output['module_css'] = $duplicate['module_css'];
		// output
		return $output;
	}

	// -----------------------------------------
	// masonry
	// -----------------------------------------

	public function masonry($request) {
		// get content and check slashes
		$content = Basic::check_slashes($request['content']);
		// decode
		$content = json_decode($content, true);
		// add script execution
		$content['script_execution'] = 'normal';
		// output
		$output = Editor::$modules[$request['module']]->editor($request['id'], $content);
		// return
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// masonry
	// -----------------------------------------

	public function single_project($request) {
		// get content and check slashes
		$content = Basic::check_slashes($request['content']);
		// decode
		$content = json_decode($content, true);
		// output
		$output = Editor::$modules['singleproject']->editor($request['id'], $content);
		// return
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// flickity
	// -----------------------------------------

	public function flickity($request) {
		// get content and check slashes
		$content = Basic::check_slashes($request['content']);
		// decode
		$content = json_decode($content, true);
		// add script execution
		$content['script_execution'] = 'normal';
		// output
		$output = Editor::$modules[$request['module']]->editor($request['id'], $content);
		// return
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// edit apg
	// -----------------------------------------

	public function apg($request) {
		// get content and check slashes
		$content = Basic::check_slashes($request['content']);
		// decode
		$content = json_decode($content, true);
		// add section element
		$content['section_element'] = $request['section_element'];
		// output
		$output = Editor::$modules['advancedportfoliogrid']->editor($request['id'], $content);
		// return
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// import cover
	// -----------------------------------------

	public function import_cover($request) {
		return new WP_REST_Response(Covers::import($request['id']), 200);
	}

	// -----------------------------------------
	// refresh coverslider
	// -----------------------------------------

	public function coverslider($request) {
		return new WP_REST_Response(Covers::coverslider(false, json_decode($request['coverslider'], true), 'editor'), 200);
	}

	// -----------------------------------------
	// save animate presets
	// -----------------------------------------

	public function save_animate_presets($request) {
		// vars
		$presets = Basic::check_slashes($request['presets']);
		// save presets
		update_option('semplice_animate_presets', $presets);
		// output newest list
		return new WP_REST_Response('Saved.', 200);
	}

	// -----------------------------------------
	// mark notice
	// -----------------------------------------

	public function mark_notice($request) {
		// save presets
		update_option('semplice_editor_notices', $request['notices']);
		// output newest list
		return new WP_REST_Response('', 200);
	}
}

// init
new RestApiCore;
?>