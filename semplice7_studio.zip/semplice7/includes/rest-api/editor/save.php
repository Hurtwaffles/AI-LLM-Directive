<?php

// namespace
namespace Semplice\RestApi\Editor;

// use
use Semplice\Admin\PostSettings;
use Semplice\Editor\Revisions;
use Semplice\Helper\Basic;
use Semplice\Helper\RestApi;
use Semplice\Editor\Components;
use WP_REST_Response;

// -----------------------------------------
// save api
// -----------------------------------------

class RestAPISave {

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// call register routes on rest api init
		add_action('rest_api_init', array(&$this, 'register_routes'));
	}

	// -----------------------------------------
	// rest routes
	// -----------------------------------------

	public function register_routes() {
		// version
		$ver = '1';
		$namespace = 'semplice/v' . $ver . '/editor';
		// routes
		$routes = array(
			'/save/post' => array('creatable', 'post'),
			'/save/template' => array('creatable', 'template'),
		);
		// register routes
		RestApi::register_route($namespace, $routes, $this, new RestApi);
	}

	// -----------------------------------------
	// save post
	// -----------------------------------------

	public function post($request) {
		// post
		$post = json_decode($request['post'], true);
		// save mode
		$save_mode = $request['save_mode'];
		// change status
		$change_status = $request['change_status'];
		// get content and check slashes
		$content = Basic::check_slashes($request['content']);
		// as long as the user saves via the editor, set semplice as activated
		update_post_meta($post['id'], '_is_semplice', true, '');
		// save post settings
		if($post['type'] != 'footer') {
			$args = PostSettings::save($request, $post['id'], $post['type']);
		} else {
			$args = array();
			// save title
			$args['post_title'] = $post['title'];
		}
		// only save to post if save mode is publish or post status is draft, otherwise just save to revision. add post meta. since wordpress strips slashes on post meta, add them before as a workaround
		if($save_mode == 'publish' || $save_mode == 'private' || get_post_status($post['id']) == 'draft') {
			if($save_mode == 'publish') {
				$args['post_status'] = 'publish';
			} else if($save_mode == 'private') {
				$args['post_status'] = 'private';
			}
			// update post meta
			update_post_meta($post['id'], '_semplice_content', wp_slash($content), '');
		} else if($change_status == 'yes') {
			$args['post_status'] = 'draft';
		}
		// post password
		$args['post_password'] = (!empty($post['password'])) ? $post['password'] : '';
		// add id to args
		$args['ID'] = $post['id'];
		// before publish, make sure this is saved to the latest version in the revisions
		Revisions::save($request);
		// update post
		wp_update_post($args);
		// update options
		$options = array('animate_presets' => true, 'blocks_order' => true, 'custom_colors' => false);
		// iterate options
		foreach($options as $option => $check_slashes) {
			if(isset($request[$option])) {
				$val = ($check_slashes) ? Basic::check_slashes($request[$option]) : $request[$option];
				update_option('semplice_' . $option, $val);
			}
		}
		// return
		return new WP_REST_Response(Revisions::list($post['id']), 200);
	}

	// -----------------------------------------
	// save template
	// -----------------------------------------

	// save and publish
	public function template($request) {
		// post
		$post = json_decode($request['post'], true);
		// get content and check slashes
		$content = Basic::check_slashes($request['content']);
		// save template
		update_option('semplice_template_' . $post['id'], $content);
		// save template settings
		update_option('semplice_template_' . $post['id']. '_settings', $request['settings']);
		// update options
		$options = array('animate_presets' => true, 'blocks_order' => true, 'notices' => false, 'custom_colors' => false);
		// iterate options
		foreach($options as $option => $check_slashes) {
			if(isset($request[$option])) {
				$val = ($check_slashes) ? Basic::check_slashes($request[$option]) : $request[$option];
				update_option('semplice_' . $option, $val);
			}
		}
		return new WP_REST_Response('Template saved.', 200);
	}
}

// init
new RestAPISave;

?>