<?php

// namespace
namespace Semplice\RestApi\Editor;

// use
use Semplice\Editor;
use Semplice\Editor\Blocks;
use Semplice\Editor\Components;
use Semplice\Helper\Basic;
use Semplice\Helper\Ram;
use Semplice\Helper\RestApi;
use WP_REST_Response;

// -----------------------------------------
// blocks api
// -----------------------------------------

class RestApiBlocks {


	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// call register routes on rest api init
		add_action('rest_api_init', array(&$this, 'register_routes'));
	}

	// -----------------------------------------
	// rest routes
	// -----------------------------------------

	public function register_routes() {
		// version
		$ver = '1';
		$namespace = 'semplice/v' . $ver . '/editor';
		// routes
		$routes = array(
			'/blocks/add'  => array('readable', 'add'),
			'/blocks/save'  => array('creatable', 'save'),
			'/blocks/synch'  => array('creatable', 'synch'),
			'/blocks/delete'=> array('creatable', 'delete'),
			'/blocks/order'=> array('creatable', 'order')
		);
		// register routes
		RestApi::register_route($namespace, $routes, $this, new RestApi);
	}

	// -----------------------------------------
	// add block
	// -----------------------------------------

	public function add($request) {
		// vars
		$block = Blocks::get($request['id'], $request['type']);
		$ram = $block['ram'];
		$mode = $request['contentType'];
		// switch mode
		switch($mode) {
			case 'section':
			case 'column':
			case 'subrow':
				// change ids
				$ram = Ram::change_ids($ram, true, true, $mode);
				// get new id
				$block['id'] = array_keys($ram['order'])[0];
				// flat order if needed
				$flat_order = ($mode == 'column' || $mode == 'subrow') ? Ram::{$mode . '_order'}($ram, false) : false;
				// get output
				$block_output = Editor::output($ram, true, $flat_order, false);
			break;
			case 'content':
				// generate new id
				$block['id'] = 'content_' . substr(md5(rand()), 0, 9);
				// decode ram
				$ram = json_decode($ram, true);
				// swap ids and unset old id
				$db_id = $ram['order'][0];
				// add new id to order
				$ram['order'] = array($block['id']);
				$ram[$block['id']] = $ram[$db_id];
				unset($ram[$db_id]);
				// get output
				$block_output = Editor::output($ram, true, array($block['id']), false);
				// get images for content block
				$ram['images'] = Blocks::content_images($ram[$block['id']]);
			break;
		}
		// add duplicate to output
		$block['html'] = $block_output['html'];
		// css
		$block['css'] = $block_output['css'];
		// module css
		$block['moduleCss'] = $block_output['module_css'];
		// add images to output and then unset from ram
		$block['images'] = $ram['images'];
		// remove order and images from ram
		$unset = array('order', 'images');
		foreach($unset as $type) {
			if(isset($ram[$type])) {
				unset($ram[$type]);
			}
		}
		// add ram ro output
		$block['ram'] = json_encode($ram, JSON_FORCE_OBJECT);
		// return
		return new WP_REST_Response($block, 200);
	}

	// -----------------------------------------
	// save block
	// -----------------------------------------

	public function save($request) {
		// get ram and order
		$content = Basic::check_slashes($request['content']);
		// save blocks order
		if(isset($request['order'])) {
			update_option('semplice_blocks_order', Basic::check_slashes($request['order']));
		}
		// save block
		$output = Blocks::save($content, $request['name'], 'save', $request['masterblock'], $request['contentType'], $request['is_first']);
		// return
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// synch components
	// -----------------------------------------

	public function synch($request) {
		// sync components
		Components::sync($request['components']);
		return new WP_REST_Response('Synched Components.', 200);
	}

	// -----------------------------------------
	// delete block
	// -----------------------------------------

	public function delete($request) {
		Blocks::delete($request['id']);
		return new WP_REST_Response('Block deleted.', 200);
	}

	// -----------------------------------------
	// save structure
	// -----------------------------------------

	public function order($request) {
		// get order
		$order = Basic::check_slashes($request['order']);
		// save order
		update_option('semplice_blocks_order', $order);
		// return
		return new WP_REST_Response('Order changed.', 200);
	}
}

// init
new RestApiBlocks;

?>