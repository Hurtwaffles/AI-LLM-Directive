<?php

// namespace
namespace Semplice\RestApi\Editor;

// use
use Semplice\Editor\Revisions;
use Semplice\Helper\Basic;
use Semplice\Helper\RestApi;
use WP_REST_Response;

// -----------------------------------------
// revisions api
// -----------------------------------------

class RestApiRevisions {

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// call register routes on rest api init
		add_action('rest_api_init', array(&$this, 'register_routes'));
	}

	// -----------------------------------------
	// rest routes
	// -----------------------------------------

	public function register_routes() {
		// version
		$ver = '1';
		$namespace = 'semplice/v' . $ver . '/editor';
		// routes
		$routes = array(
			'/revisions/save'  => array('creatable', 'save'),
			'/revisions/load'  => array('readable', 'load'),
			'/revisions/rename'=> array('creatable', 'rename'),
			'/revisions/delete'=> array('creatable', 'delete')
		);
		// register routes
		RestApi::register_route($namespace, $routes, $this, new RestApi);
	}

	// -----------------------------------------
	// save revision
	// -----------------------------------------

	public function save($request) {
		Revisions::save($request);
		return new WP_REST_Response('Saved Revision', 200);
	}

	// -----------------------------------------
	// load revision
	// -----------------------------------------

	public function load($request) {
		return new WP_REST_Response(Revisions::load($request), 200);
	}

	// -----------------------------------------
	// rename revision
	// -----------------------------------------

	public function rename($request) {
		return new WP_REST_Response(Revisions::rename($request), 200);
	}

	// -----------------------------------------
	// delete revision
	// -----------------------------------------

	public function delete($request) {
		return new WP_REST_Response(Revisions::delete($request), 200);
	}
}

// init
new RestApiRevisions;

?>