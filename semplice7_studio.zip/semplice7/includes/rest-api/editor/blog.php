<?php

// namespace
namespace Semplice\RestApi\Editor;

// use
use Semplice\Editor;
use Semplice\Helper\Basic;
use Semplice\Helper\RestApi;
use WP_REST_Response;

// -----------------------------------------
// blog api
// -----------------------------------------

class RestApiBlog {

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// call register routes on rest api init
		add_action('rest_api_init', array(&$this, 'register_routes'));
	}

	// -----------------------------------------
	// rest routes
	// -----------------------------------------

	public function register_routes() {
		// version
		$ver = '1';
		$namespace = 'semplice/v' . $ver . '/editor';
		// routes
		$routes = array(
			'/blog/posts'  	  => array('creatable', 'posts'),
			'/blog/archives'  => array('creatable', 'archives'),
		);
		// register routes
		RestApi::register_route($namespace, $routes, $this, new RestApi);
	}

	// -----------------------------------------
	// posts
	// -----------------------------------------

	public function posts($request) {
		// get content and check slashes
		$content = Basic::check_slashes($request['content']);
		// decode
		$content = json_decode($content, true);
		// posts filter
		if(!empty($request['wp_template'])) {
			$content['post_filter'] = array(
				'type' => $request['wp_template'],
				'meta' => false
			);
		} else {
			$content['post_filter'] = false;
		}
		// output
		$output = Editor::$modules['blogposts']->editor($request['id'], $content);
		// return
		return new WP_REST_Response($output, 200);
	}

	// -----------------------------------------
	// archives
	// -----------------------------------------

	public function archives($request) {
		// get content and check slashes
		$content = Basic::check_slashes($request['content']);
		// decode
		$content = json_decode($content, true);
		// output
		$output = Editor::$modules['blogarchives']->editor($request['id'], $content);
		// return
		return new WP_REST_Response($output, 200);
	}
}

// init
new RestApiBlog;
?>