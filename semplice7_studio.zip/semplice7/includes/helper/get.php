<?php

// namespace
namespace Semplice\Helper;

// use
use Semplice\Admin\Customize;
use Semplice\Helper\Basic;
use Semplice\Helper\Image;
use Semplice\Editor;
use WP_Query;
use WPSEO_Meta;
use WPSEO_Options;

// -----------------------------------------
// semplice get helper
// -----------------------------------------

class Get {

	// -----------------------------------------
	// public vars
	// -----------------------------------------

	public static $db;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// database
		global $wpdb;
		self::$db = $wpdb;
	}

	// -----------------------------------------
	// get svg
	// -----------------------------------------

	public static function svg($mode, $file) {
		$svg = file_get_contents(SEMPLICE_DIR . '/assets/images/' . $mode . '/' . $file . '.svg', true);
		return $svg;
	}

	// -----------------------------------------
	// get post id
	// -----------------------------------------

	public static function post_id() {
		// get post id
		$post_id = get_the_ID();
		// format id
		$post_id = Basic::format_post_id($post_id, false);
		// return id
		return $post_id;
	}

	// ----------------------------------------
	// template
	// ----------------------------------------

	public static function template($template, $atts) {
		// template dir
		$template = array(
			'parent' => SEMPLICE_DIR . '/partials/' . $template . '.php',
			'child'  => SEMPLICE_STYLE_DIR . '/partials/' . $template . '.php',
		);
		// make sure the file exists
		if(!file_exists($template['child']) && !file_exists($template['parent'])) {
			return '';
		}
		// use template from child theme if avilable
		$type = 'parent';
		if(file_exists($template['child'])) {
			$type = 'child';
		}
		// extract atts
		if(is_array($atts)) {
			extract($atts);
		}
		// buffer output
		ob_start();
		include $template[$type];
		return ob_get_clean();
	}

	// ----------------------------------------
	// template
	// ----------------------------------------

	public static function revision($post_id) {
		// get revision
		$revision = get_post_meta($post_id, '_semplice_revisions', true);
		// is available?
		if(empty($revision) || !is_array($revision)) {
			return array(
				'active' => 'latest_version',
				'published' => 'latest_version',
			);
		} else {
			return $revision;
		}
	}

	// -----------------------------------------
	// get breakpoints
	// -----------------------------------------

	public static function breakpoints($has_xl = false) {
		$breakpoints = array(
			'xl' => array(
				'min' => ' and (min-width: 1170px)',
				'max' => ''
			),
			'lg' => array(
				'min' => ' and (min-width: 992px)',
				'max' => ' and (max-width: 1169.98px)'
			),
			'md' => array(
				'min' => ' and (min-width: 768px)',
				'max' => ' and (max-width: 991.98px)',
			),
			'sm' => array(
				'min' => ' and (min-width: 544px)',
				'max' => ' and (max-width: 767.98px)',
			),
			'xs' => array(
				'min' => '',
				'max' => ' and (max-width: 543.98px)',
			),
		);
		// has xl
		if(!$has_xl) {
			unset($breakpoints['xl']);
		}
		// ret
		return $breakpoints;
	}

	// -----------------------------------------
	// breakpoint select
	// -----------------------------------------

	public static function bp_select($mode) {
		// output
		$theme = '';
		if($mode == 'editor') {
			$output = '<div class="semplice-dropdown dropdown-breakpoints" data-dropdown="breakpoints"><ul>';
		} else {
			$output = '<div class="customize-breakpoints"><ul>';
			$theme = ' data-tooltip-theme="bright"';
		}
		// iterate breakpoints
		$breakpoints = array(
			'xl' => 'Desktop Wide',
			'lg' => 'Desktop',
			'md' => 'Tablet Wide',
			'sm' => 'Tablet Portrait',
			'xs' => 'Mobile'
		);
		foreach($breakpoints as $bp => $tooltip) {
			$output .= '<li class="has-tooltip" data-tooltip="' . $tooltip . '" data-tooltip-settings="left,center,auto"' . $theme . '><button class="click-handler" data-handler="changeBreakpoint" data-breakpoint="' . $bp . '" data-mode="' . $mode . '">' . self::svg('editor', 'dropdowns/breakpoints/' . $bp) . '</button></li>';
		}
		// return
		return $output . '</ul></div>';
	}

	// -----------------------------------------
	// customize nav
	// -----------------------------------------

	public static function customize_nav($type, $where, $exclude) {
		// vars
		$nav = '<ul>';
		$dropdown = '';
		$count = 0;
		// settings
		$settings = array(
			'customize' => array(
				'grid'			=> 'Grid',
				'webfonts'		=> 'Webfonts',
				'typography'	=> 'Typography',
				'navigations'	=> 'Navigations',
				'thumbhover'	=> 'Thumb Hover',
				'transitions'	=> 'Transitions',
				'intro'			=> 'Site Intro',
				'projectnav'	=> 'Project Nav',
				'advanced'		=> 'Advanced',
				'cursor'		=> 'Custom Cursor',
				'footer' 		=> 'Footer',
				'blog'			=> 'Blog',
			),
			'settings' => array(
				'general'		=> 'General',
				'license'		=> 'License',
			),
		);
		// iterate
		foreach ($settings[$type] as $setting => $name) {
			if(!in_array($setting, $exclude)) {
				// atts
				$atts = array(
					'type'		=> $type,
					'setting' 	=> $setting,
					'name'		=> $name,
					'where'		=> $where,
					'active'	=> '',
					'classes'	=> '',
				);

				// active
				if($count <= 0) {
					$atts['active'] = ' class="active-setting"';
				}
				// get item
				$nav .= self::customize_nav_item($atts);
				// inc count
				$count++;
			}
		}
		// return
		return $nav . '</ul>';
	}

	// -----------------------------------------
	// customize nav item
	// -----------------------------------------

	public static function customize_nav_item($atts) {
		// link
		if($atts['where'] == 'admin') {
			$link = '<a href="#' . $atts['type'] . '/' . $atts['setting'] . '">';
		} else {
			$link = '<a data-new-url="#' . $atts['type'] . '/' . $atts['setting'] . '" data-exit-mode="close" class="click-handler" data-handler="run" data-action-type="dialog" data-setting-type="core" data-action="exitEditor">';
		}
		// return
		return '
			<li data-setting="' . $atts['setting'] . '"' . $atts['active'] . '>
				' . $link . '
					<span class="icon' . $atts['classes'] . '">' . self::svg('admin', $atts['type'] . '/' . $atts['setting']) . '</span>
					<span class="setting-name">' . $atts['name'] . '</span>
				</a>
			</li>
		';
	}

	// -----------------------------------------
	// get customize
	// -----------------------------------------

	public static function customize($type) {
		return json_decode(get_option('semplice_customize_' . $type), true);
	}

	// -----------------------------------------
	// get settings
	// -----------------------------------------

	public static function settings($type) {
		return json_decode(get_option('semplice_settings_' . $type), true);
	}

	// ----------------------------------------
	// get general settings
	// ----------------------------------------

	public static function general_settings() {
		// get general settings and add homepage settings
		$settings = self::settings('general');
		// add homepage settings from WP
		$settings['show_on_front'] = get_option('show_on_front');
		$settings['page_on_front']  = get_option('page_on_front');
		$settings['page_for_posts'] = get_option('page_for_posts ');
		// site meta
		$settings['site_title'] = get_option('blogname');
		$settings['site_tagline'] = get_option('blogdescription');
		// project slug
		if(get_option('semplice_project_slug')) {
			$settings['project_slug'] = get_option('semplice_project_slug');
		}
		// return
		return $settings;
	}

	// ----------------------------------------
	// get header settings
	// ----------------------------------------

	public static function header() {
		// get settings
		$settings = self::settings('general');
		// define output
		$output = '';
		// settings?
		if(is_array($settings)) {
			// google analytics
			if(isset($settings['google_analytics']) && !empty($settings['google_analytics'])) {
				// is script?
				if (strpos($settings['google_analytics'], '<script') !== false) {
					$output .= $settings['google_analytics'];
				}
			}
			// favicon
			if(isset($settings['favicon']) && !empty($settings['favicon'])) {
				// get image url
				$favicon = wp_get_attachment_image_src($settings['favicon'], 'full', false);
				if($favicon) {
					$output .= '<link rel="shortcut icon" type="image/png" href="' . $favicon[0] . '" sizes="32x32">';
				}
			}
			// head
			if(isset($settings['head_code']) && !empty($settings['head_code'])) {
				$output .= $settings['head_code'];
			}
		}
		// output
		echo $output;
	}

	// -----------------------------------------
	// get transitions
	// -----------------------------------------

	public static function transitions() {
		// vars
		$transitions = Get::customize('transitions');
		// is defined yet?
		if($transitions) {
			$preset = (isset($transitions['preset'])) ? $transitions['preset'] : 'fade';
			$image_atts = array('rt_image', 'st_image');
			// iterate image atts
			foreach($image_atts as $attribute) {
				if(isset($transitions[$attribute])) {
					// get image
					$img = Image::get($transitions[$attribute], 'full');
					// replace id with src
					$transitions[$attribute] = $img['src'];
				}
			}
			// add custom reveal values
			if($preset == 'reveal') {
				// create custom rt array
				$transitions['customReveal'] = array();
				// get custom reveal transition image / bg
				global $wpdb;
				// search posts
				$posts = $wpdb->get_results(
					$wpdb->prepare (
						"
						SELECT *
						FROM $wpdb->postmeta
						WHERE meta_key = '%s'
						",
						'_semplice_post_settings'
					),
					ARRAY_A
				);
				// are there posts yes with post settings?
				if(is_array($posts) && !empty($posts)) {
					foreach ($posts as $post) {
						$post_settings = json_decode($post['meta_value'], true);
						// has settings?
						if(is_array($post_settings)) {
							// vars
							$post_id = $post['post_id'];
							$custom_rt = array();
							$rt_options = array('rt_image', 'rt_color', 'rt_image_size', 'rt_image_align');
							// iterate
							foreach ($rt_options as $option) {
								if(!empty($post_settings['meta'][$option])) {
									// is image?
									if($option == 'rt_image') {
										$img = Image::get($post_settings['meta'][$option], 'full');
										$post_settings['meta'][$option] = $img['src'];
									}
									$custom_rt[$option] = $post_settings['meta'][$option];
								}
							}
							// is custom rt empty? if not add to array
							if(!empty($custom_rt)) {
								$transitions['customReveal'][$post_id] = $custom_rt;
							}
						}
					}
				}
			}
		} else {
			$transitions = array('status' => 'disabled');
		}
		// return transitions
		return $transitions;
	}

	// ----------------------------------------
	// get the ep switch icons
	// ----------------------------------------

	public static function admin_icons() {
		// dir
		$dir = SEMPLICE_DIR  . '/assets/images';
		// define icons
		$icons = array(
			'core' => array(
				'upload' => file_get_contents($dir . '/admin/media-library/upload.svg', true),
				'delete' => file_get_contents($dir . '/admin/delete.svg', true),
				'addBlock' => file_get_contents($dir . '/editor/blocks/add.svg', true),
				'addMenuItem' => file_get_contents($dir . '/admin/edit-popup/expand/add_menu_item.svg', true),
				'arrowDown' => file_get_contents($dir . '/frontend/arrows/arrow_down.svg', true),
				'video' => file_get_contents($dir . '/admin/media-library/video.svg', true),
				'closeHelp' => file_get_contents($dir . '/admin/edit-popup/close_help.svg', true),
				'logo' => file_get_contents($dir . '/admin/onboarding/logo.svg', true),
				'subMenuArrow' => file_get_contents($dir . '/frontend/arrows/sub_menu.svg', true),
			),
			'modules' => array(),
			'epSwitch' => array(),
			'epActions' => array(),
			'iconToggle' => array(),
			'toggleButton' => array(),
			'navModules' => array(),
		);
		// get icons
		$paths = array(
			'modules'      => '/editor/modules/',
			'epSwitch'     => '/admin/edit-popup/switch/',
			'epActions'    => '/admin/edit-popup/actions/',
			'iconToggle'   => '/admin/input/icon-toggle/',
			'toggleButton' => '/admin/input/toggle-button/',
			'navModules'   => '/admin/customize/navigations/modules/' 
		);
		foreach($paths as $iconType => $path) {
			foreach (glob($dir  . $path . '*.svg') as $filename) {
				$type = explode('/', $filename);
				$type = end($type);
				$icons[$iconType][str_replace('.svg', '', $type)] = file_get_contents($filename, true);
			}
		}
		return $icons;
	}

	// ----------------------------------------
	// allowed mime types
	// ----------------------------------------

	public static function mime_types() {
		// output
		$output = array();
		// get allowed mime types
		$mimes = get_allowed_mime_types();
		// iterate
		foreach ($mimes as $ext => $type) {
			if (strpos($ext, '|') !== false) {
				$multi = explode("|", $ext);
				foreach ($multi as $multi_ext) {
					$output[] = $multi_ext; 
				}
			} else {
				$output[] = $ext;
			}
		}
		// ret
		return $output;
	}

	// ----------------------------------------
	// max upload size
	// ----------------------------------------

	public static function max_upload_size() {
		$val = trim(ini_get('upload_max_filesize'));
		if (is_numeric($val))
			return $val;
		$last = strtolower($val[strlen($val)-1]);
		$val  = substr($val, 0, -1);
		switch($last) {
			case 'g':
			$val *= 1024;
			case 'm':
			$val *= 1024;
			case 'k':
			$val *= 1024;
		}
		return $val;
	}

	// ----------------------------------------
	// video type
	// ----------------------------------------

	public static function video_type($src) {
		// parse url for the file extension and make sure there are not url parameters
		$get_ext = parse_url($src);
		// get video type
		$type = substr($get_ext['path'], -3);
		if($type == 'ogv') {
			$type = 'ogg';
		} else if ($type == 'ebm') {
			$type = 'webm';
		}
		// ret
		return $type;
	}

	// ----------------------------------------
	// get bp val
	// ----------------------------------------

	public static function bp_val($options, $name, $bp, $default) {
		$output = $default;
		if(isset($options[$name . $bp])) {
			$output = $options[$name . $bp];
		} else if(isset($options[$name])) {
			$output = $options[$name];
		}
		return $output;
	}

	// ----------------------------------------
	// social profiles
	// ----------------------------------------

	public static function social_profiles() {
		return array(
			'artstation' => array(
				'name' => 'Artstation',
				'url'  => 'https://www.artstation.com/',
				'svg'  => Get::svg('frontend', 'networks/artstation')	
			),
			'behance' => array(
				'name' => 'Behance',
				'url'  => 'https://www.behance.net/',
				'svg'  => Get::svg('frontend', 'networks/behance')			
			),
			'deviantart' => array(
				'name' => 'DeviantArt',
				'url'  => 'https://www.deviantart.com/',
				'svg'  => Get::svg('frontend', 'networks/deviantart')
			),
			'dribbble' => array(
				'name' => 'Dribbble',
				'url'  => 'https://dribbble.com/',
				'svg'  => Get::svg('frontend', 'networks/dribbble')
			),
			'etsy' => array(
				'name' => 'Etsy',
				'url'  => 'https://www.etsy.com/people/',
				'svg'  => Get::svg('frontend', 'networks/etsy')
			),
			'facebook' => array(
				'name' => 'Facebook',
				'url'  => 'https://www.facebook.com/',
				'svg'  => Get::svg('frontend', 'networks/facebook')
			),
			'github' => array(
				'name' => 'Github',
				'url'  => 'https://github.com/',
				'svg'  => Get::svg('frontend', 'networks/github')
			),
			'instagram' => array(
				'name' => 'Instagram',
				'url'  => 'https://www.instagram.com/',
				'svg'  => Get::svg('frontend', 'networks/instagram')
			),
			'linkedin' => array(
				'name' => 'LinkedIn',
				'url'  => '',
				'svg'  => Get::svg('frontend', 'networks/linkedin')
			),
			'medium' => array(
				'name' => 'Medium',
				'url'  => 'https://medium.com/@',
				'svg'  => Get::svg('frontend', 'networks/medium')
			),
			'unsplash' => array(
				'name' => 'Unsplash',
				'url'  => 'https://unsplash.com/',
				'svg'  => Get::svg('frontend', 'networks/unsplash')
			),
			'pinterest' => array(
				'name' => 'Pinterest',
				'url'  => 'https://www.pinterest.com/',
				'svg'  => Get::svg('frontend', 'networks/pinterest')
			),
			'tiktok' => array(
				'name' => 'TikTok',
				'url'  => 'https://www.tiktok.com/@',
				'svg'  => Get::svg('frontend', 'networks/tiktok')
			),
			'tumblr' => array(
				'name' => 'Tumblr',
				'url'  => '',
				'svg'  => Get::svg('frontend', 'networks/tumblr')
			),
			'twitch' => array(
				'name' => 'Twitch',
				'url'  => 'https://www.twitch.tv/',
				'svg'  => Get::svg('frontend', 'networks/twitch')
			),
			'twitter' => array(
				'name' => 'X',
				'url'  => 'https://x.com/',
				'svg'  => Get::svg('frontend', 'networks/x')
			),
			'vimeo' => array(
				'name' => 'Vimeo',
				'url'  => 'https://vimeo.com/',
				'svg'  => Get::svg('frontend', 'networks/vimeo')
			),
			'youtube' => array(
				'name' => 'YouTube',
				'url'  => 'https://www.youtube.com/user/',
				'svg'  => Get::svg('frontend', 'networks/youtube')
			),
			'reddit' => array(
				'name' => 'Reddit',
				'url'  => 'https://www.reddit.com/user/',
				'svg'  => Get::svg('frontend', 'networks/reddit')
			),
			'bluesky' => array(
				'name' => 'Bluesky',
				'url'  => 'https://bsky.app/profile/',
				'svg'  => Get::svg('frontend', 'networks/bluesky')
			),
			'spotify' => array(
				'name' => 'Spotify',
				'url'  => 'https://open.spotify.com/user/',
				'svg'  => Get::svg('frontend', 'networks/spotify')
			)
		);
	}

	// ----------------------------------------
	// get project slug
	// ----------------------------------------

	public static function project_slug() {
		if(get_option('semplice_project_slug')) {
			return get_option('semplice_project_slug');
		} else {
			return 'project';
		}
	}

	// ----------------------------------------
	// projects view
	// ----------------------------------------

	public static function projects_view() {
		// get sortby
		$projects_view = get_option('semplice_projects_view');
		// has value?
		if(false !== $projects_view) {
			return $projects_view;
		} else {
			return 'thumb';
		}
	}

	// ----------------------------------------
	// background grid
	// ----------------------------------------

	public static function background_grid($id) {
		$columns = '';
		for ($i=0; $i < 12; $i++) { 
			$columns .= '<div class="grid-column" data-xl-width="1"><div class="grid-content"></div></div>';
		}
		return '
			<div id="' . $id . '" data-breakpoint="xl">
				<section class="content-block-grid">
					<smp-container class="grid-container">
						<div class="grid-row">
							' . $columns . '
						</div>
					</smp-container>
				</section>
			</div>
		';
	}

	// ----------------------------------------
	// get grid columns
	// ----------------------------------------

	public static function grid_columns($start) {
		$columns = '';
		$end = $start + 3;
		for($i=$start; $i <= $end; $i++) {
			$columns .= '<div class="grid-sizes-value"><p><span class="title">' . $i . ' Col</span><span class="val">{{gridSize' . $i . '}}</span></p></div>';
		}
		return $columns;
	}

	// ----------------------------------------
	// back to top arrow
	// ----------------------------------------

	public static function back_to_top() {
		// defaults
		$arrow = self::svg('frontend', '/arrows/arrow_up');
		$align = 'right';
		// get options
		$advanced = self::customize('advanced');
		// arrow
		if(is_array($advanced) && isset($advanced['top_arrow'])) {
			// get image
			$image = Image::get($advanced['top_arrow'], 'full');
			$arrow = '<img src="' . $image['src'] . '" alt="Back to top Arrow">';
		}
		// align
		if(isset($advanced['top_arrow_align'])) {
			$align = $advanced['top_arrow_align'];
		}
		// return
		echo '
			<div class="back-to-top" data-arrow-align="' . $align . '">
				<a class="click-handler" data-handler="run" data-action-type="helper" data-setting-type="animate" data-action="scrollToTop">' . $arrow . '</a>
			</div>
		';
	}

	// -----------------------------------------
	// semplice get post ids
	// -----------------------------------------

	public static function post_ids() {
		// define post ids array
		$post_ids = array();
		// get posts
		$posts = self::$db->get_results("SELECT ID, post_name FROM " . self::$db->posts . " WHERE post_status = 'publish' AND post_type = 'post' OR post_type = 'page' OR post_type = 'project'");
		// iterate posts
		foreach ($posts as $post) {
			$post_ids[$post->post_name] = $post->ID;
		}
		// return
		return $post_ids;
	}

	// -----------------------------------------
	// get rest api url
	// -----------------------------------------

	public static function rest_url() {
		return (function_exists('rest_url')) ? rest_url() : 'no-rest-api';
	}

	// -----------------------------------------
	// get frontend mode
	// -----------------------------------------

	public static function frontend_mode() {
		// frontend settings
		$settings = self::settings('general');
		// check if mode option in the admin is already set
		if(self::rest_url() == 'no-rest-api') {
			return 'static';
		} if(isset($settings) && isset($settings['frontend_mode'])) {
			return $settings['frontend_mode'];
		} else {
			return 'static';
		}
	}

	// -----------------------------------------
	// get single page app title
	// -----------------------------------------

	public static function spa_title($title, $id, $post) {
		if(function_exists('wpseo_replace_vars')) {
			// first of all get yoast seo title if there
			$seo_title = get_post_meta($id, '_yoast_wpseo_title', true);
			if(false !== $seo_title && strlen($seo_title) > 0) {
				$title = $seo_title;
			}
			$title = wpseo_replace_vars(self::yoast_title($id, $post), $post);
			$title = apply_filters('wpseo_title', $title);
		} else if(strpos($title, get_bloginfo('name')) === false) {
			$title = $title . ' - ' . get_bloginfo('name');
		}
		// return
		return $title;
	}

	// -----------------------------------------
	// get yoast page title
	// -----------------------------------------

	public static function yoast_title($post_id, $post) {
		$fixed_title = WPSEO_Meta::get_value('title', $post_id);
		if ($fixed_title !== '') {
			return $fixed_title;
		}
		if (is_object($post) && WPSEO_Options::get('title-' . $post->post_type, '') !== '') {
			$title_template = WPSEO_Options::get( 'title-' . $post->post_type);
			$title_template = str_replace(' %%page%% ', ' ', $title_template);
			return wpseo_replace_vars($title_template, $post);
		}
		return wpseo_replace_vars('%%title%%', $post);
	}

	// -----------------------------------------
	// get category base
	// ----------------------------------------

	public static function category_base() {
		// category base
		global $wp_rewrite;
		$category_base = str_replace('%category%', '', $wp_rewrite->get_category_permastruct());
		// return
		return $category_base;
	}

	// ----------------------------------------
	// get tag base
	// ----------------------------------------

	public static function tag_base() {
		// category base
		global $wp_rewrite;
		$tag_base = str_replace('%post_tag%', '', $wp_rewrite->get_tag_permastruct());
		// return
		return $tag_base;
	}

	// ----------------------------------------
	// get navbar
	// ----------------------------------------

	public static function navbar($id) {
		// get navigation json
		$navigations = self::customize('navigations');
		// output
		if($id && isset($navigations[$id])) {
			$nav = Customize::$setting['navigations']->get($id, true, true);
		} else if(isset($navigations['default'])) {
			$nav = Customize::$setting['navigations']->get('default', true, true);
		} else {
			$nav = Customize::$setting['navigations']->get(false, true, true);
		}
		// return
		return $nav;
	}

	// ----------------------------------------
	// body bg color
	// ----------------------------------------

	public static function body_bg() {
		$transitions = self::customize('transitions');
		// is array?
		if(is_array($transitions) && isset($transitions['background-color'])) {
			echo 'bgcolor="' . $transitions['background-color'] . '"';
		}
	}

	// -----------------------------------------
	// editor notices
	// -----------------------------------------

	public static function editor_notices() {
		// get notices
		if(get_option('semplice_editor_notices')) {
			return json_decode(get_option('semplice_editor_notices'), true);
		} else {
			// return default
			return array(
				'getting_started' => 'unread',
				'section_module'  => 'unread',
				'text_module'	  => 'unread',
				'motions'		  => 'unread',
				'grid_view'		  => 'unread'
			);
		}
	}

	// ----------------------------------------
	// get animate presets
	// ----------------------------------------

	public static function animate_presets() {
		// get json for preview presets
		$preview = file_get_contents(get_template_directory() . '/assets/json/animate/preview.json');
		// get json for premade presets
		$premade = file_get_contents(get_template_directory() . '/assets/json/animate/presets.json');
		// add to presets
		$presets = array(
			'preview' => json_decode($preview, true),
			'premade' => json_decode($premade, true),
			'custom' => false,
		);
		// get custom presets
		$custom = json_decode(get_option('semplice_animate_presets'), true);
		// are there custom presets?
		if($custom && is_array($custom) && !empty($custom)) {
			$presets['custom'] = $custom;
		}
		return $presets;
	}

	// ----------------------------------------
	// nav dropdown
	// ----------------------------------------

	public static function nav_dropdown() {
		// customize
		$navigations = self::customize('navigations');
		// nav array
		$nav_dropdown = array(0 => '— Select Navbar');
		// iterate
		if(!empty($navigations) && is_array($navigations)) {
			foreach($navigations as $id => $navigation) {
				if(false !== strpos($id, 'nav_')) {
					// is new format?
					if(isset($navigation['settings'])) {
						$nav_dropdown[$id] = $navigation['settings']['name'];
					} else {
						$nav_dropdown[$id] = $navigation['name'];
					}
				}
			}
		}
		// return
		return $nav_dropdown;
	}

	// ----------------------------------------
	// site intro
	// ----------------------------------------

	public static function intro() {
		// vars
		$intro = false;
		$options = self::customize('intro');
		$state = (isset($options['state']) && $options['state'] == 'active') ? 'enabled' : 'disabled';
		$template = get_option('semplice_template_intro');
		$mobile_detect = Basic::mobile_detect();
		// is enabled?
		if(Get::frontend_mode() != 'static' && $state == 'enabled' && $template) {
			$status = (isset($options['publish']) && $options['publish'] == 'live') ? 'live' : 'draft';
			$hide_on_preview = (isset($options['hide_on_preview']) && $options['hide_on_preview'] == 'yes') ? true : false;
			$show_mobile = (isset($options['mobile']) && $options['mobile'] == 'hidden') ? false : true;
			$visibility = (isset($options['visibility'])) ? $options['visibility'] : 'all';
			$visibility = ($visibility == 'home' && !is_front_page()) ? false : true;
			// mobile visibility
			if($mobile_detect->isMobile() && $show_mobile || !$mobile_detect->isMobile()) {
				// preview and live visibility
				if(is_preview() && $status == 'draft' && !$hide_on_preview || is_preview() && $status == 'live' && !$hide_on_preview || $visibility && $status == 'live' && !is_preview()) {
					// get ram
					$intro = $template;
					// load content from post meta if not a preview
					$intro = json_decode($intro, true);
					// add intro as post id
					$intro['post_id'] = 'intro';
					// get content
					$intro = Editor::output($intro, false, false, false);
				}			
			}
		}
		// return
		return $intro;
	}

	// ----------------------------------------
	// image modules
	// ----------------------------------------

	public static function image_modules() {
		return array('image', 'gallerygrid', 'video', 'gallery', 'marquee', 'beforeafter', 'button');
	}

	// ----------------------------------------
	// nav preset ids
	// ----------------------------------------

	public static function nav_preset_ids() {
		return json_decode(file_get_contents(SEMPLICE_DIR . '/assets/json/nav-presets.json'), true);
	}

	// ----------------------------------------
	// nav presets
	// ----------------------------------------

	public static function nav_presets() {
		// define presets
		$presets = array();
		// preset list
		$preset_ids = self::nav_preset_ids();
		foreach($preset_ids as $preset_id => $num) {
			if($preset_id != 'scratch') {
				$presets[$preset_id] = json_decode(file_get_contents(SEMPLICE_DIR . '/assets/json/nav-presets/' . $num . '.json'));
			}	
		}
		return $presets;
	}

	// ----------------------------------------
	// get url for links in modules
	// ----------------------------------------

	public static function url($options, $default) {
		// vars
		$prefix = '';
		$type = (isset($options['link_type'])) ? $options['link_type'] : $default;
		$url = home_url();
		// get url
		if($type == 'home') {
			$url = home_url();
		} else if($type != 'url' && isset($options['link_' . $type])) {
			$url = get_permalink($options['link_' . $type]);
		} else if($type == 'url' && isset($options['link'])) {
			// add mailto for emails
			if(filter_var($options['link'], FILTER_VALIDATE_EMAIL)) {
				$prefix = 'mailto:';
			}
			$url = $prefix . $options['link'];
		}
		return $url;
	}

	// ----------------------------------------
	// get studio popup
	// ----------------------------------------

	public static function studio($feature, $title, $desc) {
		// links
		$links = array(
			'blocks' 				=> 'https://www.semplice.com/blocks',
			'gallerygrid'			=> 'https://www.semplice.com/project/gallery-module',
			'advancedportfoliogrid' => 'https://www.semplice.com/advanced-portfolio-grid',
			'instagram' 			=> 'https://www.semplice.com/project/instagram-module',
			'mailchimp'				=> 'https://www.semplice.com/mailchimp-module',
			'beforeafter'			=> 'https://www.semplice.com/before-after',
		);
		$see_it_live = '<a href="' . $links[$feature] . '" target="_blank">See it live</a>';
		// output
		echo '
			<div class="studio-gallery">' . self::studio_gallery($feature) . '</div>
			<div class="content">
				<button class="click-handler dialog-close" data-handler="run" data-action-type="dialog" data-action="close">' . self::svg('admin', 'close') . '</button>
				<div class="studio-edition">Studio Edition</div>
				<h2>' . $title . '</h2>
				<p>' . $desc . '</p>
			</div>
			<div class="footer">
				' . $see_it_live . '
				<a href="https://transactions.sendowl.com/products/79214297/5843771B/add_to_cart" class="feature-purchase" target="_blank">Upgrade to Studio for $49</a>
			</div>
		';
	}

	// ----------------------------------------
	// get gallery for studio popup
	// ----------------------------------------

	public static function studio_gallery($feature) {
		// features
		$features = array(
			'gallerygrid' 			=> 3,
			'advancedportfoliogrid' => 2,
			'instagram'				=> 3,
			'mailchimp'				=> 1,
			'blocks'				=> 2,
			'navigations'			=> 2,
			'beforeafter'			=> 2,
		);
		// open output
		$output = '<div id="feature-gallery-' . $feature . '" class="is-content semplice-gallery-slider sgs-slide pagination-above sgs-pagination-true">';
		// create items
		for ($i=1; $i <= $features[$feature]; $i++) {
			$output .= '
				<div class="sgs-slide">
					<img src="https://assets.semplice.com/studio/' . $feature . '_' . $i . '.jpg" alt="' . $feature . '-feature-' . $i . '" />
				</div>
			';
		}
		// close html output
		$output .= '</div>';
		// return
		return $output;
	}
}
new Get;
?>