<?php

// namespace
namespace Semplice\Helper;

// use
use Semplice\Helper\Basic;
use Semplice\Helper\Image;

// -----------------------------------------
// semplice background helper
// -----------------------------------------

class Background {

	// -----------------------------------------
	// backgrounc css
	// -----------------------------------------

	public static function css($styles, $is_video) {
		$css = '';
		// css for the background image
		if(!empty($styles['background-image']) && !$is_video) {
			// background image
			$css .= self::image_css($styles);
			// define and iterate defaults
			$defaults = array('repeat', 'size', 'position', 'attachment');
			foreach($defaults as $attribute) {
				if(!empty($styles['background-' . $attribute])) {
					$css .= 'background-' . $attribute . ': ' . $styles['background-' . $attribute] . ';';
				}
			}
		}
		// css for the background color
		$is_gradient = (isset($styles['background-color']) && strpos($styles['background-color'], 'gradient') !== false) ? true : false;
		if(!empty($styles['background-color'])) {
			if(preg_match('/^#[a-f0-9]{6}$/i', $styles['background-color']) || preg_match('/^#[a-f0-9]{8}$/i', $styles['background-color'])) {
				$css .= 'background-color: ' . $styles['background-color'] . ';';
			} else if(empty($styles['background-image']) && $is_gradient || $is_video && $is_gradient) {
				$css .= 'background-image: ' . $styles['background-color'] . ';';
				// add bg color if mesh
				if(isset($styles['mesh']) && strpos($styles['background-color'], 'radial-gradient(at') !== false) {
					$css .= 'background-color: ' . $styles['mesh']['backgroundColor'] . ';';
				}
			} else {
				$css .= 'background-color: transparent;';
			}
		}
		// return
		return $css;
	}

	// -----------------------------------------
	// bg image css
	// -----------------------------------------

	public static function image_css($styles) {
		$css = '';
		$gradient = '';
		// get background image
		if(!empty($styles['background-image'])) {
			if(!isset($styles['background_type']) || $styles['background_type'] != 'vid') {
				if(!is_numeric($styles['background-image'])) {
					$bg_image = Image::external($styles['background-image']);
					$bg_image[0] = $bg_image['src'];
				} else {
					$bg_image = wp_get_attachment_image_src($styles['background-image'], 'full');
				}
				// check for gradient
				if(!empty($styles['background-color']) && strpos($styles['background-color'], 'gradient') !== false) {
					$gradient = $styles['background-color'] . ', ';
				}
				if($bg_image) {
					$css = 'background-image: ' . $gradient . 'url(' . $bg_image[0] . ');';
				}
			}
		}
		// ret
		return $css;
	}

	// -----------------------------------------
	// get background image id for ram / components images array
	// -----------------------------------------

	public static function image_id($styles) {
		$images = '';
		$breakpoints = ['xl', 'lg', 'md', 'sm', 'xs'];
		$type = 'img';
		if(isset($styles['xl']) && isset($styles['xl']['background_type']) && $styles['xl']['background_type'] == 'vid') {
			$type = 'vid';
		}
		foreach($breakpoints as $bp) {
			if(isset($styles[$bp])) {
				// background type
				if($type == 'vid' && isset($styles[$bp]['bg_video_fallback']) && is_numeric($styles[$bp]['bg_video_fallback'])) {
					$images .= $styles[$bp]['bg_video_fallback'] . ',';
				} else if(isset($styles[$bp]['background-image']) && is_numeric($styles[$bp]['background-image'])) {
					$images .= $styles[$bp]['background-image'] . ',';
				}
			}
		}
		return $images;
	}

	// -----------------------------------------
	// get background video
	// -----------------------------------------

	public static function video($styles, $is_editor, $autoplay) {
		// vars
		$no_fallback = '';
		$fallback_src = self::video_fallback_src($styles);
		$mobile_detect = Basic::mobile_detect();
		if(!$fallback_src) {
			$no_fallback = ' no-fallback';
		}
		$video = '<div class="background-video' . $no_fallback . '"></div>';
		$force_autoplay = isset($styles['bg_force_autoplay']) ? $styles['bg_force_autoplay'] : 'disabled';
		// fallback image
		$fallback_image = '';
		if($mobile_detect->isMobile()) {
			$fallback_image = ' poster="' . $fallback_src . '"';	
		}
		// has bg video?
		if(!empty($styles['bg_video'])) {
			// get video url
			$bg_video = wp_get_attachment_url($styles['bg_video']);
		} else if(isset($styles['bg_video_url'])) {
			$bg_video = $styles['bg_video_url'];
		}
		// autoplay
		if($autoplay) {
			$autoplay = 'data-autoplay autoplay ';
		}
		// is url?
		if(!empty($bg_video) && !$is_editor) {
			if(!$mobile_detect->isMobile() || $mobile_detect->isMobile() && $force_autoplay == 'enabled') {
				$video = '
					<video ' . $autoplay . 'webkit-playsinline playsinline loop muted data-object-fit="cover"' . $fallback_image . '>
						<source src="' . $bg_video . '" type="video/mp4">
					</video>
				';
			}
		}
		// return
		return $video;
	}

	// -----------------------------------------
	// get background video fallback css
	// -----------------------------------------

	public static function video_fallback_css($styles, $id, $is_editor, $is_cs) {
		// mobile detect
		$mobile_detect = Basic::mobile_detect();
		// is cover?
		if(strpos($id, 'cover') !== false && $is_cs) {
			$id = $id . ' smp-cover-media-wrapper';
		}
		// is container styles?
		if($is_cs) {
			$id = $id . ' smp-container';
		}
		// css
		if(strpos($id, 'cover') !== false) {
			$css = '#content-holder #' . $id . ' smp-cover-media-wrapper smp-bg-video {';
		} else {
			$css = '#content-holder #' . $id . ' > smp-bg-video {';
		}
		// force autoplay
		$force_autoplay = isset($styles['bg_force_autoplay']) ? $styles['bg_force_autoplay'] : 'disabled';
		// bg color on frontend
		$gradient = (isset($styles['background-color']) && strpos($styles['background-color'], 'gradient') !== false) ? $styles['background-color'] . ', ' : false;
		if(!$is_editor) {
			$css .= self::css($styles, true);
		}
		// get fallback image
		$fallback_image = self::video_fallback_src($styles);
		// is fallback image there?
		if($fallback_image) {
			// only show in editor or mobile frontend
			if($is_editor || $mobile_detect->isMobile() && $force_autoplay == 'disabled') {
				// css code
				$css .= 'background-image: ' . $gradient . ' url(' . $fallback_image . '); background-size: cover;';
			}
		}
		// close css
		$css .= '}';
		// bg video opacity
		if(isset($styles['bg_video_opacity'])) {
			if(strpos($id, 'cover') !== false) {
				$css .= '#content-holder #' . $id . ' smp-cover-media-wrapper smp-bg-video video { opacity: ' . $styles['bg_video_opacity'] . '; }';
			} else {
				$css .= '#content-holder #' . $id . ' > smp-bg-video video { opacity: ' . $styles['bg_video_opacity'] . '; }';
			}
		}
		// return css
		return $css;
	}

	// -----------------------------------------
	// get video fallback image src
	// -----------------------------------------

	public static function video_fallback_src($styles) {
		// vars
		$image = false;
		// check if fallback image is set
		if(isset($styles['bg_video_fallback'])) {
			// get img
			$image = Image::get($styles['bg_video_fallback'], 'full', false);
			// return src
			return $image['src'];
		}
		// return
		return $image;
	}
}
new Background;
?>