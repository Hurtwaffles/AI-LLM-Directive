<?php

// namespace
namespace Semplice\Helper;

// use
use Semplice\Helper\Get;
use Semplice\Helper\Image;

// -----------------------------------------
// semplice masonry helper
// -----------------------------------------

class Masonry {

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {}

	// -----------------------------------------
	// html
	// -----------------------------------------

	public static function html($module, $id, $options, $items, $is_editor, $script_execution) {
		// load more
		$load_more = '';
		if(isset($options['lazy_load']) && is_array($options['lazy_load'])) {
			// short
			$lazy_load = $options['lazy_load'];
			// get button image
			if(is_numeric($lazy_load['button'])) {
				$button = Image::get($lazy_load['button'], 'full');
				$lazy_load['button'] = $button['src'];
			}
			// only show button if count of projects is > starting offset
			if($options['count'] >= $lazy_load['start_offset']) {
				// get grid options
				extract( shortcode_atts(
					array(
						'categories'				=> '',
						'title_visibility'			=> 'both',
						'title_position'			=> 'below',
						'title_font'				=> 'regular',
						'category_font'				=> 'regular',
					), $options)
				);
				// categories
				if(is_array($categories)) {
					$categories = implode(',', $categories);
				}
				// grid optioons
				$grid_options = '{"categories": "' . $categories . '", "title_visibility": "' . $title_visibility . '", "title_position": "' . $title_position . '", "title_font": "' . $title_font . '", "category_font": "' . $category_font . '"}';
				// load more button
				$load_more = '<div class="load-more-wrapper"><a class="semplice-load-more click-handler" data-handler="run" data-action-type="masonry" data-action="lazyLoad" data-type="portfolio-grid" data-load="' . $lazy_load['per_load'] . '" data-offset="' . $lazy_load['start_offset'] . '" data-content-id="' . $id . '" data-grid-options=\'' . $grid_options . '\'><img src="' . $lazy_load['button'] . '" alt="load-more-button"></a></div>';
			}
		}
		// open masonry
		return '
			<div id="masonry-' . $id . '" class="masonry" data-masonry-init="' . $script_execution . '">
				<div class="masonry-item-width"></div>
				' . $items . '
			</div>
			' . $load_more . '
		';
	}

	// -----------------------------------------
	// css
	// -----------------------------------------

	public static function css($id, $options, $img_per_row, $is_editor, $hor_gutter, $ver_gutter, $is_portfoliogrid) {
		// output
		$mobile_css = '';
		// defaults images per row
		$col_width = array(
			'xl' => $img_per_row,
			'lg' => $img_per_row,
			'md' => $img_per_row,
			'sm' => 6,
			'xs' => 12
		);
		// get breakpoints
		$breakpoints = Get::breakpoints($is_editor);
		// iterate breakpoints
		foreach ($breakpoints as $bp => $width) {
			// open css
			$css = array(
				'margin'  => '',
				'padding' => '',
				'width'	  => '',
			);
			if(isset($options['hor_gutter_' . $bp]) || isset($options['ver_gutter_' . $bp])) {
				// open padding
				$css['padding'] = '.masonry-'. $id .'-item {';
				// hor gutter
				if(isset($options['hor_gutter_' . $bp])) {
					$css['margin'] .= '#masonry-'. $id .'{ margin: auto -' . ($options['hor_gutter_' . $bp] / 2) . 'px !important; }';
					$css['padding'] .= 'padding-left: ' . ($options['hor_gutter_' . $bp] / 2) . 'px; padding-right: ' . ($options['hor_gutter_' . $bp] / 2) . 'px;';
				}
				// ver gutter
				if(isset($options['ver_gutter_' . $bp])) {
					$css['padding'] .= 'padding-bottom:  ' . $options['ver_gutter_' . $bp] . 'px;';
				}
				// close css
				$css['padding'] .= '}';
			}
			// colum width (images per row)
			if(!$is_portfoliogrid) {
				if(!isset($options['random']) || $options['random'] == 'disabled') {
					if(isset($options['col_' . $bp])) {
						$css['width'] .= '.masonry-'. $id .'-item { width: calc(100% / 12 * ' . $options['col_' . $bp] . ') !important; max-width: calc(100% / 12 * ' . $options['col_' . $bp] . ') !important; }';
					}
				}
			}
			// add to mobile css
			if($is_editor) {
				// iterate atts and add to mobile css
				$atts = array('margin', 'padding', 'width');
				foreach ($atts as $attribute) {
					if(!empty($css[$attribute])) {
						$mobile_css .= '[data-breakpoint="' . $bp . '"] ' . $css[$attribute];
					}
				}			
			} else {
				$mobile_css .= '@media screen' . $width['min'] . $width['max'] . ' {' . $css['margin'] . $css['padding'] . $css['width'] . '}';
			}
		}
		// masonry css
		$masonry_css = '
				#masonry-'. $id .'{ margin: auto -' . ($hor_gutter / 2) . 'px !important; } 
				.masonry-'. $id .'-item { margin: 0px; padding-left: ' . ($hor_gutter / 2) . 'px; padding-right: ' . ($hor_gutter / 2) . 'px; padding-bottom: ' . $ver_gutter . 'px; }
				' . $mobile_css . '
		';
		// return css
		return str_replace(array("\r","\n", "\t"),"",$masonry_css);
	}
}
new Masonry;
?>