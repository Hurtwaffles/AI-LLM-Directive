<?php

// namespace
namespace Semplice\Helper;

// use
use Semplice\Helper\Get;
use Semplice\Editor\Components;
use Semplice\Helper\Image;
use Semplice\Helper\Background;

// -----------------------------------------
// semplice ram helper
// -----------------------------------------

class Ram {

	// -----------------------------------------
	// public vars
	// -----------------------------------------

	public static $db;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// database
		global $wpdb;
		self::$db = $wpdb;
	}

	// -----------------------------------------
	// get ram
	// -----------------------------------------

	public static function get($id, $is_preview) {
		// define ram
		$ram = false;
		// get revision
		$revision = Get::revision($id);
		// make sure this is not a post
		if(get_post_type($id) != 'post') {
			if($is_preview) {
				// for the preview take the active revision id from the editor instead of the published one
				$revision_id = $revision['active'];
				// get ram
				$values = array($id, $revision_id);
				$ram = self::$db->get_var(
					self::$db->prepare("SELECT content FROM " . SEMPLICE_REV_TABLE . " WHERE post_id = %d AND revision_id = %s", $values)
				);
				// is not null?
				if($ram) {
					// get components
					$ram = Components::get($ram);
					// json decode
					$ram = json_decode($ram, true);
				} else {
					$ram = false;
				}
			} else {
				// get ram
				$ram = get_post_meta($id, '_semplice_content', true);
				// init components if not empty
				if(!empty($ram)) {
					$ram = Components::get($ram);
				}
				// load content from post meta if not a preview
				$ram = json_decode($ram, true);
			}
		}
		// return
		return $ram;
	}

	// -----------------------------------------
	// change ids
	// -----------------------------------------

	public static function change_ids($ram, $is_encoded, $is_block, $order_type) {
		// decode ram
		if($is_encoded) {
			$ram = json_decode($ram, true);
		}
		// vars
		$copy = $ram;
		$order_encoded = json_encode($ram['order']);
		$order_flat = ($order_type != 'content') ? Ram::{$order_type . '_order'}($ram, false) : $ram['order'];
		$images = '';
		$styles = array('styles', 'containerStyles', 'wrapperStyles');
		$image_modules = Get::image_modules();
		$masterblock = false;
		// iterate flat order
		foreach($order_flat as $key => $id) {
			// get type
			$type = strtok($id, '_');
			// new id
			$new_id = $type . '_' . substr(md5(rand()), 0, 9);
			// ignore cover
			if(strpos($id, '_') !== false) {
				// copy to new ram excpet for rows
				if(isset($ram[$id])) {
					// get images from styles
					foreach($styles as $style) {
						if(isset($ram[$id][$style])) {
							$images .= Background::image_id($ram[$id][$style]) . ',';
						}
					}
					// get images from modules
					if(isset($ram[$id]['module']) && in_array($ram[$id]['module'], $image_modules)) {
						$images .= Image::used_in_module($ram[$id]);
					}
					// add to copy
					$copy[$new_id] = $ram[$id];
					// copy links
					if(isset($ram['links']) && isset($ram['links'][$id])) {
						$copy['links'][$new_id] = $ram['links'][$id];
					}
					// remove old id from copy
					unset($copy[$id]);
				}
				// replace in encoded order
				$order_encoded = str_replace($id, $new_id, $order_encoded);
			}
		}
		// add new order to copy
		$copy['order'] = json_decode($order_encoded, true);
		// add images to output if block
		if($is_block) {
			$copy['images'] = Image::blocks_array(explode(',', preg_replace('/,+/', ',', trim($images, ','))));
		}
		// return
		return $copy;
	}

	// -----------------------------------------
	// section order
	// -----------------------------------------

	public static function section_order($ram, $is_editor) {
		// remove cover on frontend if not visible
		$cover = isset($ram['cover_visibility']) ? $ram['cover_visibility'] : 'hidden';
		if(!$is_editor && !self::has_cover('cover', $cover, $is_editor)) {
			unset($ram['order']['cover']);
		}
		// iterate
		$order = array();
		foreach($ram['order'] as $section_id => $section) {
			$order[] = $section_id;
			$type = (strpos($section_id, 'section') !== false) ? 'section' : 'cover';
			// is old single format?
			if(isset($section['columns'])) {
				$section = array(
					$section['row_id'] => array(
						'columns' => $section['columns']
					)
				);
			}
			foreach($section as $row_id => $row) {
				$order[] = $row_id;
				if(isset($row['columns'])) {
					foreach($row['columns'] as $column_id => $column_content) {
						$order[] = $column_id;
						foreach($column_content as $content) {
							$order = self::content_ids($ram, $content, $order);
						}
						$order[] = 'close-' . $column_id;
					}
				}
				$order[] = 'close-' . $row_id;
			}
			$order[] = ($section_id == 'cover') ? 'close-section_cover' : 'close-' . $section_id;
		}
		return $order;
	}

	// -----------------------------------------
	// column order
	// -----------------------------------------

	public static function column_order($ram, $is_editor) {
		// order
		$order = array();
		// iterate column
		foreach($ram['order'] as $column_id => $column_content) {
			// add column id
			$order[] = $column_id;
			// iterate column content
			foreach($column_content as $content) {
				$order = self::content_ids($ram, $content, $order);
			}
			$order[] = 'close-column';
		}
		return $order;
	}

	// -----------------------------------------
	// subrow order
	// -----------------------------------------

	public static function subrow_order($ram, $is_editor) {
		// order
		$order = array();
		// iterate column
		foreach($ram['order'] as $subrow_id => $column_content) {
			// add column id
			$order[] = $subrow_id;
			// iterate column content
			foreach($column_content as $content) {
				$order = self::content_ids($ram, $content, $order);
			}
			$order[] = 'close-subrow';
		}
		return $order;
	}

	// -----------------------------------------
	// content ids
	// -----------------------------------------

	public static function content_ids($ram, $content, $order) {
		// is nested row?
		if(is_array($content)) {
			foreach($content as $nested_id => $nested_content) {
				$order[] = $nested_id;
				foreach($nested_content as $content_id) {
					if(isset($ram[$content_id])) { $order[] = $content_id; };
				}
				$order[] = 'close-' . $nested_id;
			}
		} else {
			if(isset($ram[$content])) { $order[] = $content; };
		}
		return $order;
	}

	// -----------------------------------------
	// replace in order
	// -----------------------------------------

	public static function replace_in_order(&$order, $targetKey, $replacementOrder) {
		foreach ($order as $key => &$value) {
			if ($key === $targetKey) {
				// Find position to preserve order
				$keys = array_keys($order);
				$position = array_search($key, $keys);
				// Split array
				$before = array_slice($order, 0, $position, true);
				$after = array_slice($order, $position + 1, null, true);
				// Merge arrays
				$order = $before + $replacementOrder + $after;
				// Exit after replacement
				return;
			} else if (is_array($value)) {
				// Recursive call
				self::replace_in_order($value, $targetKey, $replacementOrder);
			}
		}
	}

	// -----------------------------------------
	// replace only content in order
	// -----------------------------------------

	public static function replace_content(&$order, $content_id, $new_id) {
		foreach ($order as $key => &$value) {
			if (is_array($value)) {
				// Recursively traverse the order
				self::replace_content($value, $content_id, $new_id);
			} else {
				// Check if the current value matches the target content ID
				if ($value === $content_id) {
					// Replace the value with the new value
					$value = $new_id;
				}
			}
		}
	}

	// -----------------------------------------
	// extract ids
	// -----------------------------------------

	public static function extract_ids($order, &$ids) {
		foreach ($order as $key => $value) {
			if (!is_int($key)) {
				$ids[] = $key;
			}
			if (is_array($value)) {
				self::extract_ids($value, $ids);
			} else if (is_string($value)) {
				$ids[] = $value;
			}
		}
	}

	// -----------------------------------------
	// find sub array
	// -----------------------------------------

	public static function find_sub_array($order, $start) {
		foreach ($order as $key => $value) {
			if ($key === $start) {
				return $value;
			} else if (is_array($value)) {
				$result = self::find_sub_array($value, $start);
				if ($result !== null) {
					return $result;
				}
			}
		}
		return null;
	}

	// -----------------------------------------
	// has cover?
	// -----------------------------------------

	public static function has_cover($id, $visibility, $is_editor) {
		// get hidden covers from coverslider
		$hide_cover = false;
		if(isset($_POST['hide_cover']) || isset($_GET['hide_cover'])) {
			$hide_cover = true;
		}
		// is id cover and cover is created?
		if($id == 'cover' && !$hide_cover) {
			// is editor, always show it
			if($is_editor) {
				$has_cover = true;
			} else if(!$is_editor && $visibility == 'visible') {
				$has_cover = true;
			} else {
				$has_cover = false;
			}
		} else {
			$has_cover = false;
		}
		return $has_cover;
	}	
}
new Ram;
?>