<?php

// namespace
namespace Semplice\Helper;

// use
use Semplice\Admin\ThemeAdmin;
use Semplice\Helper\Get;
use Semplice\Helper\PostQueries;
use Detection\Exception\MobileDetectException;
use Detection\MobileDetectStandalone;

// -----------------------------------------
// core helper class
// -----------------------------------------

class Basic {

	// -----------------------------------------
	// format post id
	// -----------------------------------------

	public static function format_post_id($post_id, $is_crawler) {
		// get blog homepage id
		$blog_home = get_option('page_for_posts');
		// check if blog homepage is not set
		if($blog_home == 0) {
			$blog_home = 'posts';
		}
		// is blog home or not found?
		if(is_home() && !$is_crawler || $post_id == 'posts' || $post_id == $blog_home) {
			$post_id = 'posts';
		} else if(empty($post_id) || is_404()) {
			$post_id = 'notfound';
		}
		// return id
		return $post_id;
	}

	// -----------------------------------------
	// check if value is boolean
	// -----------------------------------------

	public static function boolval($val) {
		return filter_var($val, FILTER_VALIDATE_BOOLEAN);
	}

	// -----------------------------------------
	// get customize settings
	// -----------------------------------------

	public static function customize($type) {
		// get settings
		return json_decode(get_option('semplice_customize_' . $type), true);
	}

	// ----------------------------------------
	// has animate gradient
	// ----------------------------------------

	public static function has_animate_gradient($motions) {
		$clip_text = '';
		if(isset($motions['initial']) && isset($motions['initial']['gradient_applyto']) && $motions['initial']['gradient_applyto'] == 'text') {
			$clip_text = ' clip-text';
		}
		return $clip_text;
	}

	// ----------------------------------------
	// check slashes
	// ----------------------------------------

	public static function check_slashes($content) {
		// get first 3 chars of content json string
		$quote_status = mb_substr($content, 0, 2);
		if($quote_status !== '{"') {
			$content = stripcslashes($content);
		}
		// return content
		return $content;
	}

	// ----------------------------------------
	// ellipsis
	// ----------------------------------------

	public static function ellipsis($string, $dir, $max_length) {
		if($dir == 'left') {
			return (strlen($string) > $max_length) ? '…' . substr($string,-$max_length) : $string;
		} else {
			return (strlen($string) > $max_length) ? substr($string,0,$max_length) . '…' : $string;
		}
	}

	// ----------------------------------------
	// rem to px
	// ----------------------------------------

	public static function rem_to_px($val) {
		$rem_val = str_replace('rem', '', $val);
		$rem_val = $rem_val * 18;
		return $rem_val;
	}

	// ----------------------------------------
	// search replace in an multi dimension array
	// ----------------------------------------

	public static function search_replace(&$array, $search, $replace) {
		foreach ($array as &$value) {
			if(is_array($value)) {
				self::search_replace($value, $search, $replace);
			} else {
				if ($value === $search) {
					$value = $replace;
				}
			}
		}
		return $array;
	}

	// ----------------------------------------
	// is exlusive nav?
	// ----------------------------------------

	public static function is_exclusive_nav() {
		// get customize advanced
		$advanced = Get::customize('advanced');
		// return
		return (isset($advanced['exclusive_navbar']) && $advanced['exclusive_navbar'] != 'default' && !PostQueries::is_removed($advanced['exclusive_navbar'])) ? $advanced['exclusive_navbar'] : false;
	}

	// -----------------------------------------
	// is onboarding
	// -----------------------------------------

	public static function is_onboarding() {
		// get onboarding status
		$completed_onboarding = get_option('semplice_completed_onboarding');
		// return status
		if($completed_onboarding) {
			return false;
		} else {
			return true;
		}
	}

	// -----------------------------------------
	// whats new
	// -----------------------------------------

	public static function whats_new() {
		// version
		$version = SEMPLICE_VER;
		// whats new version
		$wn_version = get_option('semplice_whats_new');
		// dont do anything on onboarding
		if(self::is_onboarding()) {
			// set it to read
			update_option('semplice_whats_new', $version);
			return array('unread' => false);
		} else if($version != $wn_version) {
			return array(
				'unread' => true,
				'html'	 => self::whats_new_html($version),
			);
		} else {
			return array('unread' => false);
		}
	}

	// -----------------------------------------
	// whats new
	// -----------------------------------------

	public static function whats_new_html($version) {
		// get json for changelog
		$json = file_get_contents(get_template_directory() . '/assets/json/changelog.json');
		// decode
		$json = json_decode($json, true);
		// changelog output and head
		$changelog_output = '';
		$changelog_head = '<p class="changelog-head">Changelog</p>';
		// get features html
		$features = '';
		if(isset($json['featured']) && false !== $json['featured']) {
			foreach ($json['featured'] as $feature => $values) {
				$link = '';
				if(isset($values['link'])) {
					$link = '<p class="feature-desc">&rarr; <a target="_blank" href="' . $values['link'] . '">' . $values['link_desc'] . '</a></p>';
				}
				$asset = '';
				if(isset($values['asset'])) {
					switch ($values['asset']['type']) {
						case 'image':
							$asset = '<img src="' . $values['asset']['link'] . '" alt="' . $values['title'] . '">';
						break;
					}
				}
				$features .= '
					<div class="feature">
						<p class="new-feature-heading"><span class="new-feature">New</span>' . $values['title'] . '</p>
						<p class="feature-desc">' . $values['description'] . '</p>
						' . $link . '
						' . $asset . '
					</div>
				';
			}
		} else {
			$changelog_head = '';
		}
		// iterate
		if(isset($json['changelog']) && is_array($json['changelog'])) {
			foreach ($json['changelog'] as $entry) {
				// add to output
				$changelog_output .= '<div class="changelog-item"><span class="' . $entry['label'] . '">' . strtoupper($entry['label']) . '</span><p>' . $entry['text'] . '</p></div>';
			}
		}
		// output
		$output = '
			<div class="content whats-new-content">
			<button class="click-handler dialog-close" data-handler="run" data-action-type="dialog" data-action="close">' . Get::svg('admin', 'close') . '</button>
				<p class="head">What’s new in<br />Semplice ' . $version . '</p>
				' . $features . '
				<div class="changelog">
					' . $changelog_head . '
					' . $changelog_output . '
					<div class="changelog-link"><a href="https://www.semplice.com/changelog" target="_blank">View complete changelog on semplice.com</a></div>
				</div>
			</div>				
		';
		// return output
		return $output;
	}

	// -----------------------------------------
	// mobile detect
	// -----------------------------------------

	public static function mobile_detect() {
		global $mobile_detect;
		if(!$mobile_detect) {
			// only add mobile detect for php >= 8
			if (version_compare(PHP_VERSION, '8.0.0') >= 0) {
				$mobile_detect = new MobileDetectStandalone();
			} else {
				$mobile_detect = new class {
					public function __call(string $name, array $args) {
						return false;
					}
				};
			}
		}
		return $mobile_detect;
	}
}
new Basic;
?>