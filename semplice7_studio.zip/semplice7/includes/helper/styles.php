<?php

// namespace
namespace Semplice\Helper;

// use
use Semplice\Helper\Get;

// -----------------------------------------
// semplice styles helper
// -----------------------------------------

class Styles {

	// ----------------------------------------
	// get css
	// ----------------------------------------

	public static function css($selector, $attribute, $css_attributes, $values, $filters, $negative, $output) {
		// prefix
		$prefix = '';
		if($negative) {
			$prefix = '-';
		}
		// transform
		$transform = array('translateY', 'translateX', 'scale', 'move', 'rotate');
		// css for xl breakpoint
		if(isset($values[$attribute]) && !empty($values[$attribute])) {
			foreach ($css_attributes as $css_attribute) {
				$output['css'] .= $selector . ' { ' . $css_attribute . ': ' . $prefix . self::value($values[$attribute], $filters) . '; }';
			}
		}
		// get breakpoints
		$breakpoints = Get::breakpoints(false);
		// iterate breakpoints
		foreach ($breakpoints as $breakpoint => $width) {
			if(isset($values[$attribute . '_' . $breakpoint]) && !empty($values[$attribute . '_' . $breakpoint])) {
				foreach ($css_attributes as $css_attribute) {
					$output['mobile_css'][$breakpoint] .= $selector . ' { ' . $css_attribute . ': ' . $prefix . self::value($values[$attribute . '_' . $breakpoint], $filters) . '; }';
				}
				
			}
		}
		// return
		return $output;
	}

	// ----------------------------------------
	// get val
	// ----------------------------------------

	public static function value($value, $filters) {
		// apply filters
		if($filters) {
			foreach ($filters as $filter) {
				switch($filter) {
					case 'rem-split':
						$value = floatval(str_replace('rem', '', $value));
						$value = ($value / 2) . 'rem';
					break;
					case 'add-px':
						$value = $value . 'px';
					break;
					case 'divide-half':
						$value = $value / 2;
					break;
				}
			}
		}
		// return
		return $value;
	}

	// ----------------------------------------
	// frontend css
	// ----------------------------------------

	public static function frontend($css, $post_id) {
		// define search and replace
		$search  = array('#content-holder', 'body ');
		$replace = array('#content-' . $post_id, '#content-' . $post_id . ' ');
		// str replace and output css
		return str_replace($search, $replace, $css);
	}
}
new Styles;
?>