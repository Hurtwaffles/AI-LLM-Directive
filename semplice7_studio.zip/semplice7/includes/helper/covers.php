<?php

// namespace
namespace Semplice\Helper;

// use
use Semplice\Editor;
use Semplice\Content;
use Semplice\Helper\Get;
use Semplice\Helper\Ram;
use Semplice\Editor\Placeholder;


// -----------------------------------------
// semplice generate helper
// -----------------------------------------

class Covers {

	// -----------------------------------------
	// get cover
	// -----------------------------------------

	public static function get($id, $coverslider) {
		// get ram
		$ram = json_decode(get_post_meta($id, '_semplice_content', true), true);
		// check ram
		if(null !== $ram && isset($ram['cover'])) {
			// order
			$ram['order'] = array('cover' => $ram['order']['cover']);
			// remove everything from ram that is not in the cover
			$ram = Covers::coverOnly($ram, $id);
			// change ids
			$ram = Ram::change_ids($ram, false, false, 'section');
			// set coverslider
			$ram['is_coverslider'] = true;
			// add coverslider options to ram
			$ram['coverslider'] = $coverslider;
			// get styles
			$styles = $ram['cover']['styles']['xl'];
			// get output
			$output = Editor::output($ram, false, false, true);
			// add vp button if visible
			$output = self::vp_button('both', $id, $output, $styles, $coverslider);
			// return output
			return $output;
		} else {
			return false;
		}
	}

	// -----------------------------------------
	// generate post settings
	// -----------------------------------------

	public static function default($visibility) {
		return '
			<smp-section id="cover" class="semplice-cover default-cover" data-cover="' . $visibility . '" data-column-mode-xs="single" data-column-mode-sm="single" data-height="fullscreen" data-valign="center">
				<a class="show-more show-more-hidden click-handler" data-handler="run" data-action-type="helper" data-setting-type="animate" data-action="scrollToContent">' . Get::svg('frontend', 'arrows/arrow_down') . '</a>
				<smp-container>
					<div class="empty-cover">' . Placeholder::get('cover', 'cover', false, true, false) . '</div>
		';
	}

	// ----------------------------------------
	// setup coverslider
	// ----------------------------------------

	public static function coverslider($post_id, $coverslider, $visibility) {
		// extract options
		extract(shortcode_atts(
			array(
				'navigation'			=> 'dots',
				'orientation'			=> 'vertical',
				'color'					=> '#000000',
				'hide_post_cover'		=> 'disabled',
				'content_after_slider' 	=> false,
			), $coverslider)
		);
		// get valid covers
		$output = self::generate_slides($coverslider);
		// add vp button css for global button
		$output['css'] .= self::vp_button('css-only', 'global', $output, false, false);
		// wrap with slider if not empty covers
		if(!$output['empty']) {
			$output['html'] = '
				<div id="slider_' . substr(md5(rand()), 0, 9) . '" class="swiper coverslider" data-nav="' . $navigation . '">
					<div class="swiper-wrapper">
						' . $output['html'] . '
					</div>
					<div class="swiper-pagination"></div>
					<div class="swiper-button-prev">' . Get::svg('frontend', 'arrows/arrow_left') . '</div>
					<div class="swiper-button-next">' . Get::svg('frontend', 'arrows/arrow_right') . '</div>
					<div class="swiper-scrollbar"></div>
				</div>
			';
			// hide post cover
			if($hide_post_cover == 'enabled') {
				$output['html'] .= '<form id="coverslider-form" action="" method="post"><input type="hidden" name="hide_cover" value="true"></form>';
			}
		}
		// arrow color
		$output['css'] .= '
			:root {
				--swiper-theme-color: ' . $color . ';
				--swiper-pagination-bullet-inactive-color: ' . $color . ';
			}
		';
		// content after slider
		if($orientation == 'horizontal' && $visibility == 'frontend') {
			$output = self::content_after_slider($output, $coverslider, $content_after_slider);
			// add footer
			$output = Content::footer($output, $post_id);
		}
		// return output
		return $output;
	}

	// -----------------------------------------
	// content after slider
	// -----------------------------------------

	public static function content_after_slider($output, $coverslider, $content_after_slider) {
		// content after slider
		if($content_after_slider && is_numeric($content_after_slider)) {
			// get ram
			$ram = Ram::get($content_after_slider, false);
			// add to slider ram
			$output['slider_ram'] = array_merge($output['slider_ram'], $ram);
			// make sure ram has content
			if(null !== $ram && isset($ram['order']) && !isset($ram['coverslider'])) {
				// add posts filter
				$ram['posts_filter'] = false;
				// delete cover if there
				if(isset($ram['order']['cover'])) {
					unset($ram['order']['cover']);
				}
				// get content
				$content = Editor::output($ram, false, false, false);
				// add content to output
				foreach ($output as $content_type => $output_content) {
					if(isset($content[$content_type]) && $content_type != 'slider_ram') {
						$output[$content_type] .= $content[$content_type];
					}
				}
			}
		}
		return $output;
	}

	// -----------------------------------------
	// get covers
	// -----------------------------------------
	
 	public static function generate_slides($coverslider) {
 		// output
		$output = array(
			'html' 			 => '',
			'css'  			 => '',
			'motion_css'	 => '',
			'js'			 => '',
			'slider_ram' 	 => array()
		);
 		// get covers
		$posts_with_covers = PostQueries::posts_with_covers();
		// selectec covers
		if(!isset($coverslider['covers'])) {
			$covers = array();
			foreach ($posts_with_covers as $post_id => $post_title) {
				array_push($covers, $post_id);
			}
		} else {
			$covers = (isset($coverslider['covers'])) ? $coverslider['covers'] : $empty_covers;
		}
		// vaslid covers
		$valid_covers = array();
		// are there any covers?
		if(!empty($posts_with_covers)) {
			// check if added covers are in the valid coverlist or maybe deleted or change to draft
			foreach ($covers as $post_id) {
				// add covers to valid covers
				if(isset($posts_with_covers[$post_id])) {
					$valid_covers[] = $post_id;
					// get cover
					$cover = self::get($post_id, $coverslider);
					// is set?
					if($cover) {
						// add html to output
						$output['html'] .= '<div class="swiper-slide">' . $cover['html'] . '</div>';
						// add css to output
						$output['css'] .= $cover['css'];
						// add to slider ram
						if(!empty($cover['slider_ram'])) {
							$output['slider_ram'] = array_merge($output['slider_ram'], $cover['slider_ram']);
						}
					}
				}
			}
		}
		// has covers?
		if(!empty($valid_covers)) {
			$output['empty'] = false;
			return $output;
		} else {
			return self::empty_coverslider();
		}
 	}

 	// ----------------------------------------
	// view project button
	// ----------------------------------------

 	public static function vp_button($mode, $post_id, $output, $styles, $coverslider) {
 		// extract coverslider options
		extract(shortcode_atts(
			array(
				'navigation'			=> 'dots',
				'orientation'			=> 'vertical',
				'hide_post_cover'		=> 'disabled',
			), $coverslider)
		);
		// extract vp button styles
		$extract = ($styles && isset($styles['vp_button_type']) && $styles['vp_button_type'] == 'custom') ? $styles : $coverslider;
		extract( shortcode_atts(
			self::vp_button_defaults(), $extract)
		);
 		// visibility and custom
 		$is_custom = ($vp_button_type != 'default') ? true : false;
		$visible = (!$is_custom || $vp_button_visibility == 'visible') ? true : false;
		// get vp options if visible
		if($visible) {
			// get permalink
			$permalink = get_the_permalink($post_id);
			// set post id
			$post_id = ($is_custom && $post_id != 'global') ? $post_id : 'global';
			// label, post cover and dots
			$vp_button_label = (!empty($vp_button_label) && $is_custom) ? $vp_button_label : 'View Project';
			$hide_post_cover = ($hide_post_cover == 'enabled') ? 'class="cs-hide-covers"' : '';
			$has_dots = ($navigation == 'dots' && $orientation == 'horizontal') ? ' has-dots ' : ' ';
			// add to html
			$html = '<div class="view-project vp-' . $post_id . $has_dots . $vp_button_font_family . '"><a href="' . $permalink . '"' . $hide_post_cover . '>' . $vp_button_label . '</a></div>';
			// add styles if custom
			if($is_custom || $mode == 'css-only') {
				$css = '
					.coverslider .vp-' . $post_id . ' a {
						font-size: ' . $vp_button_font_size . ';
						text-transform: '.$vp_button_text_transform . ';
						letter-spacing: ' . $vp_button_letter_spacing . ';
						color: ' . $vp_button_font_color . ';
						background-color: ' . $vp_button_bg_color . ';
						border-color: ' . $vp_button_border_color . ';
						padding: ' . $vp_button_padding_ver . ' ' . $vp_button_padding_hor . ';
						border-radius: ' . $vp_button_border_radius . ';
						border-width: ' . $vp_button_border_width . ';
					}
					.coverslider .vp-' . $post_id . ' a:hover {
						color: ' . $vp_button_font_mouseover_color . ';
						background-color: ' . $vp_button_bg_mouseover_color . ';
						border-color: ' . $vp_button_border_mouseover_color . ';
					}
				';
			}
		}
		// mode
		if($mode == 'css-only') {
			return (isset($css)) ? $css : '';
		} else {
			$output['html'] .= (isset($html)) ? $html : '';
			$output['css'] .= (isset($css)) ? $css : '';
			return $output;
		}
 	}

 	// ----------------------------------------
	// vp button defaults
	// ----------------------------------------

 	public static function vp_button_defaults() {
 		return array(
 			'vp_button_visibility'				=> 'visible',
			'vp_button_type'					=> 'default',
			'vp_button_label'					=> 'View Project',
			'vp_button_font_family'				=> 'regular',
			'vp_button_font_size'				=> '0.7222222222222222rem',
			'vp_button_text_transform'			=> 'uppercase',
			'vp_button_letter_spacing'			=> 0,
			'vp_button_padding_ver'				=> '0.4444444444444444rem',
			'vp_button_padding_hor'				=> '1.666666666666667rem',
			'vp_button_border_width'			=> '0.0555555555555556rem',
			'vp_button_border_radius'			=> '0.1111111111111111rem',
			'vp_button_font_color'				=> '#ffffff',
			'vp_button_bg_color'				=> 'transparent',
			'vp_button_border_color'			=> '#ffffff',
			'vp_button_font_mouseover_color'	=> '#000000',
			'vp_button_bg_mouseover_color'		=> '#ffffff',
			'vp_button_border_mouseover_color'	=> '#ffffff',
 		);
 	}

 	// ----------------------------------------
	// empty cover slider
	// ----------------------------------------

	public static function empty_coverslider() {
		return array(
			'html' => '
				<div class="coverslider">
					<section id="cs" class="semplice-cover default-cover" data-column-mode-xs="single" data-column-mode-sm="single" data-height="fullscreen">
						<smp-container>
							<smp-row id="row_cover">
								<div class="empty-cover empty-coverslider">
									<img src="' . SEMPLICE_URI . '/assets/images/editor/coverslider/empty-title.svg" alt="missing-cover-title">
									<p class="missing-covers-desc">In order to select your covers for the cover slider you need to have a fullscreen cover enabled on your project or page. Also make sure your project or page is published and not set to draft.</p>
									<div class="help-videos">
										<a href="https://www.semplice.com/videos#cover-slider" target="_blank">Create a Coverslider</a>
									</div>
								</div>
							</smp-row>
						</smp-container>
					</section>
				</div>
			',
			'css' => '',
			'empty' => true,
			'slider_ram' => array()
		);
	}
		
	// -----------------------------------------
	// cover presets
	// -----------------------------------------

	public static function presets() {
		// presets output
		$presets_html = '';
		// define presets
		$presets = array('one', 'two', 'three', 'four');
		// iterate presets
		foreach ($presets as $preset) {
			$presets_html .= '
				<a class="cover-preset click-handler" data-handler="run" data-action-type="mediaLibrary" data-action="init" data-upload="coverPreset" data-upload-type="cover" data-cover-preset="' . $preset . '">
					' . Get::svg('editor', 'cover-presets/preset_' . $preset) . '
				</a>
			';
		}
		// return
		return '<div class="cover-presets">' . $presets_html . '</div>';
	}

	// -----------------------------------------
	// import cover
	// -----------------------------------------

	public static function import($id) {
		// output
		$output = array(
			'ram'  		 => '',
			'html' 		 => '',
			'css'  		 => '',
			'moduleCss' => '',
			'images' 	 => array(),
		);
		// get ram
		$ram = json_decode(get_post_meta($id, '_semplice_content', true), true);
		// check ram
		if(null !== $ram && isset($ram['cover'])) {
			// order
			$ram['order'] = array('cover' => $ram['order']['cover']);
			// remove everything from ram that is not in the cover
			$ram = self::coverOnly($ram, $id);
			// change ids
			$ram = Ram::change_ids($ram, false, false, 'section');
			// get output
			$cover_output = Editor::output($ram, true, false, false);
			// add duplicate to output
			$output['html'] = $cover_output['html'];
			// add css
			$output['css'] = $cover_output['css'];
			// add images to output and then unset from ram
			$output['images'] = $cover_output['images'];
			// module css
			$output['moduleCss'] = $cover_output['module_css'];
		} else {
			$output['ram'] = 'nocover';
		}
		// remove order and images from ram
		$unset = array('order', 'images');
		foreach($unset as $type) {
			if(isset($ram[$type])) {
				unset($ram[$type]);
			}
		}
		// add ram ro output
		$output['ram'] = json_encode($ram, JSON_FORCE_OBJECT);
		// return
		return $output;
	}

	// -----------------------------------------
	// cover only
	// -----------------------------------------

	public static function coverOnly($ram, $post_id) {
		// cover ram
		$cover_ram = array();
		// flat order
		$order = Ram::section_order($ram, false);
		// iterate
		foreach($order as $key => $id) {
			if(isset($ram[$id])) {
				$cover_ram[$id] = $ram[$id];
			}
		}
		// add order to cover ram
		$cover_ram['order'] = $ram['order'];
		// add post id
		$cover_ram['post_id'] = $post_id;
		// cover visibility
		$cover_ram['cover_visibility'] = 'visible';
		// return cover ram
		return $cover_ram;
	}
}
new Covers;
?>