<?php

// namespace
namespace Semplice\Helper;

// use
use StdClass;

// -----------------------------------------
// color helper class
// -----------------------------------------

class Color {

	// -----------------------------------------
	// get color
	// -----------------------------------------

	public static function has_gradient($color, $type) {
		if(strpos($color, 'gradient')) {
			return ' data-has-' . $type . 'gradient="true"';
		} else {
			return ' data-has-' . $type . 'gradient="false"';
		}
	}

	// -----------------------------------------
	// get color css
	// -----------------------------------------

	public static function css($color, $is_editor) {
		if(strpos($color, 'gradient')) {
			return 'background-image: ' . $color . ';';
		} else {
			$reset = '';
			if($is_editor) {
				$reset = 'background-image: none;';
			}
			return 'color: ' . $color . ';' . $reset;
		}
	}

	// -----------------------------------------
	// get bg color css
	// -----------------------------------------

	public static function bg_css($color, $is_editor, $non_image) {
		if(strpos($color, 'gradient')) {
			if($non_image) {
				return 'background: ' . $color . ';';
			} else {
				return 'background-image: ' . $color . ';';
			}
		} else {
			$reset = '';
			if($is_editor) {
				$reset = 'background-image: none;';
			}
			return 'background-color: ' . $color . ';' . $reset;
		}
	}

	// -----------------------------------------
	// get gradient data
	// -----------------------------------------

	public static function gradient_data($val) {
		// default
		$gradient = 'linear-gradient(90deg,#000000 0%,#ffffff 100%)';
		// gradient
		if(false !== strpos($val, 'gradient')) {
			$gradient = $val;
		}
		// gradient data
		preg_match('/.+?(?=[(])/', $gradient, $type_match);
		preg_match('/(?<=[(])(.*?)(?=,)/', $gradient, $angle_match);
		// is linear?
		if($type_match[0] != 'linear-gradient') {
			$angle_match[0] = str_replace('deg', '', $angle_match[0]);
		}
		// fill data
		$gradient_data = array(
			'type'   => $type_match[0],
			'angle'  => $angle_match[0],
			'colors' => array()
		);
		// split gradient
		$gradient_split = explode(',', $gradient);
		// count
		$count = 0;
		// iterate gradient
		foreach($gradient_split as $index => $color) {
			if(false !== strpos($color, '#')) {
				preg_match('/(?<=[ ])(.*)(?=[%])/', $color, $pos_match);
				preg_match('/(?<=[#])(.*)(?= )/', $color, $color_match);
				// add to data
				$gradient_data['colors'][$index] = array(
					'pos' => $pos_match[0],
					'color' => '#' . $color_match[0]
				);
			}
		}
		// ret
		return $gradient_data;
	}

	// -----------------------------------------
	// get gradient mouseover transition
	// -----------------------------------------

	public static function gradient_mouseover($sel, $normal, $hover, $is_input) {
		$css = '';
		// is there a gradient?
		if(strpos($normal, 'gradient') || strpos($hover, 'gradient')) {
			$colors = array('normal' => $normal, 'hover' => $hover);
			// iterate colors
			foreach($colors as $state => $color) {
				// is gradient? if not make a flat gradient
				$affix = ($state == 'hover') ? ':hover' : '';
				$flat = false;
				// get gradient
				if(strpos($color, 'gradient')) {
					$gradient = self::gradient_data($color);
				} else {
					// get state
					$color_from_state = ($state == 'normal') ? 'hover' : 'normal';
					// get gradient
					$gradient = self::gradient_data($colors[$color_from_state]);
					// is flat
					$flat = $color;
				}
				// rebuild from gradient data
				$state_css = self::gradient_from_data($gradient, $flat, $state);
				// wrap with sel and affix
				$css .= $sel . $affix . ' {' . $state_css . '}';
				// add input focus
				if($state == 'hover' && $is_input) {
					$css .= $sel . ':focus {' . $state_css . '}';
				}
			}
		}
		return $css;
	}

	// -----------------------------------------
	// rebuild gradient css from gradient data
	// -----------------------------------------

	public static function gradient_from_data($gradient, $flat, $state) {
		// css
		$css = array(
			'gradient' 		=> '',
			'vars'			=> ''
		);
		// open gradient
		$css['gradient'] = $gradient['type'] . '(' . $gradient['angle'];
		foreach($gradient['colors'] as $index => $data) {
			// get color or replace if flat gradient for mouseover
			$data['color'] = ($flat) ? $flat : $data['color'];
			// add to vars
			$css['vars'] .= '--smp-gradient-' . $index . ': ' . $data['color'] . ';';
			// add to gradient
			$css['gradient'] .= ',var(--smp-gradient-' . $index . ') ' . $data['pos'] . '%';
		}
		$css['gradient'] .= ')';
		// return
		if($state == 'normal') {
			return $css['vars'] . ' background: ' . $css['gradient'] . ';';
		} else {
			return $css['vars'];
		}
	}

	// -----------------------------------------
	// get gradient vars for the transition
	// -----------------------------------------

	public static function gradient_vars($duration, $easing) {
		$vars = '';
		for($i=1; $i<=4; $i++) {
			$vars .= '--smp-gradient-' . $i . ' ' . $duration . 's var(' . $easing . '),';
		}
		return substr($vars, 0, -1);
	}

	// ----------------------------------------
	// convert hex to rgb
	// ----------------------------------------

	public static function hex_to_rgb($hex) {
		$hex = str_replace("#", "", $hex);
		$color = array();
		if(strlen($hex) == 3) {
			$color['r'] = hexdec(substr($hex, 0, 1) . $r);
			$color['g'] = hexdec(substr($hex, 1, 1) . $g);
			$color['b'] = hexdec(substr($hex, 2, 1) . $b);
		}
		else if(strlen($hex) == 6) {
			$color['r'] = hexdec(substr($hex, 0, 2));
			$color['g'] = hexdec(substr($hex, 2, 2));
			$color['b'] = hexdec(substr($hex, 4, 2));
		}
		return $color;	
	}

	// ----------------------------------------
	// get custom colors
	// ----------------------------------------

	public static function get_custom() {
		// get
		$colors = json_decode(get_option('semplice_custom_colors'));
		// is set?
		if($colors && !empty($colors)) {
			// has transparent?
			if($colors[0] != '#00000000') {
				array_unshift($colors, '#00000000');
			}
			return $colors;
		} else {
			return array('#00000000');
		}
	}

	// ----------------------------------------
	// check if color is transparent
	// ----------------------------------------

	public static function is_transparent($color) {
		if ($color == 'transparent') {
			return true;
		}
		if (strpos($color, 'gradient') !== false) {
			return false;
		}
		// Remove '#' if present
		if (strpos($color, '#') === 0) {
			$color = substr($color, 1);
		}
		if (strlen($color) === 6) {
			return false;
		}
		$alpha = substr($color, 6, 2);
		$alpha_val = hexdec($alpha);
		return $alpha_val === 0;
	}
}
new Color;
?>