<?php

// namespace
namespace Semplice\Helper;

use WP_REST_Server;

// -----------------------------------------
// semplice rest api helper
// -----------------------------------------

class RestApi {

	// -----------------------------------------
	// get rest api url
	// -----------------------------------------

	public static function rest_url() {
		// get rest url
		if(function_exists('rest_url')) {
			return rest_url();
		} else {
			return 'no-rest-api';
		}
	}

	// ----------------------------------------
	// semplice register route
	// ----------------------------------------

	public static function register_route($namespace, $routes, $_this, $self) {
		// rest method
		$rest_method = array(
			'readable'  => WP_REST_Server::READABLE,
			'creatable' => WP_REST_Server::CREATABLE
		);
		$permission_cb = array(
			'admin' => array($self, 'auth_user'),
			'frontend' => '__return_true'
		);
		// type
		$type = (strpos($namespace, 'frontend')) ? 'frontend' : 'admin';
		// register endpoints
		foreach ($routes as $route => $options) {
			register_rest_route($namespace, $route, array(
				'methods' => $rest_method[$options[0]],
				'permission_callback' => $permission_cb[$type],
				'callback' => array($_this, $options[1]),
			));
		}
	}

	// -----------------------------------------
	// check nonce and admin rights
	// -----------------------------------------

	public static function auth_user() {
		// get nonce
		$nonce = isset($_SERVER['HTTP_X_WP_NONCE']) ? $_SERVER['HTTP_X_WP_NONCE'] : '';
		// verfiy nonce
		$nonce = wp_verify_nonce($nonce, 'wp_rest');
		// check nonce and if current user has admin rights
		if($nonce && current_user_can('manage_options')) {
			return true;
		} else {
			return false;
		}
	}
}
new RestApi;
?>