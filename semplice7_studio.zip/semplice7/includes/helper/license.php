<?php

// namespace
namespace Semplice\Helper;

// -----------------------------------------
// semplice rest api helper
// -----------------------------------------

class License {

	// -----------------------------------------
	// save license
	// -----------------------------------------

	public static function save($key, $product) {
		// output
		$output = array(
			'license' => '',
			'update' => '',
		);
		// get current license
		$current_license = json_decode(get_option('semplice_license'), true);
		// defaults
		$defaults = array('key', 'product', 'is_valid');
		// get current license
		foreach ($defaults as $attribute) {
			if(!isset($current_license[$attribute])) {
				$current_license[$attribute] = '';
			}
		}
		// check license
		if($product == 's7-single' && SEMPLICE_EDITION == 'studio') {
			$output['license'] = array( 'is_valid' => false, 'product' => $product);
		} else {
			$check_license = wp_remote_get('https://update.semplice.com/update.php?key=' . $key . '&product=' . $product . '&action=check_key');
			if(!is_wp_error($check_license) && empty($check_license->errors)) {
				// get array
				$license = json_decode($check_license['body'], true);
				// check if license is valid
				if($license['license'] == 'valid') {
					// define output
					$output['license'] = array(
						'is_valid'  	=> true,
						'key'			=> $key,
						'name'			=> $license['name'],
						'product'		=> $product,
						'email'			=> $license['email'],
						'error'			=> false,
						'valid_until'   => 'no_subscription'
					);
				} else {
					$output['license'] = array( 'is_valid' => false, 'product' => $product);
				}
			} else {
				$output['license'] = array('error' => $check_license->get_error_message());
			}
		}
		// save to admin
		update_option('semplice_license', json_encode($output['license']));
		// check for updates
		self::update_check();
		// add update to array
		$output['update'] = self::has_update();
		// return
		return $output;
	}

	// -----------------------------------------
	// get license
	// -----------------------------------------

	public static function get() {
		// get current license
		$current_license = json_decode(get_option('semplice_license'), true);
		// check license
		if(is_array($current_license) && isset($current_license['is_valid']) && false !== $current_license['is_valid']) {
			$output = $current_license;
		} else {
			$output = false;
		}
		// return
		return $output;
	}

	// -----------------------------------------
	// semplice update check
	// -----------------------------------------

	public static function update_check() {
		// get license
		$license = self::get();
		// meta data url
		$meta_data_url = false;
		// decide which edition / product to update
		if(SEMPLICE_EDITION == 'single' && isset($license['product']) && $license['product'] != 's7-single') {
			$meta_data_url = 'https://update.semplice.com/update_s7_studio.json';
		} else {
			$meta_data_url = 'https://update.semplice.com/update_s7_' . SEMPLICE_EDITION . '.json';
		}
		// has meta data url?
		if($meta_data_url) {
			// get theme folder (without trailing slash)
			$theme_folder = get_template();
			// check if theme folder is correct and license is valid
			if($theme_folder == 'semplice7' && is_array($license) && $license['is_valid']) {
				// make sure its s7
				if(strpos($license['product'], 's7') !== false) {
					// if everything is ok turn on auto update
					require SEMPLICE_DIR . '/includes/third-party/update.php';
					// new instance of themeupdatechecker
					$check_update = new \ThemeUpdateChecker(
						'semplice7',
						$meta_data_url
					);
					// check for updates
					$check_update->checkForUpdates();
				}
			}
		}	
	}

	// -----------------------------------------
	// check if there is an update
	// -----------------------------------------

	public static function has_update() {
		// output array
		$output = array(
			'has_update' => false,
		);
		// get license
		$license = self::get();
		// get theme folder (without trailing slash)
		$theme_folder = get_template();
		// include update.php
		require_once ABSPATH . '/wp-admin/includes/update.php';
		// get theme updates
		$theme_updates = get_theme_updates();
		// loop through updates
		if(is_array($theme_updates)) {
			foreach ($theme_updates as $theme => $meta) {
				// make sure its semplice 4
				if($meta->Name == 'Semplice v7') {
					$output = array(
						'has_update' => true,
						'has_edition_upgrade' => false,
						'recent_version' => SEMPLICE_VER,
						'new_version' => $meta->update['new_version']
					);
					// is edition upgrade available?
					if(SEMPLICE_EDITION == 'single' && $license['product'] != 's7-single') {
						$output['has_edition_upgrade'] = true;
					}
				}
			}
		}
		// check if correct folder
		if($theme_folder !== 'semplice7') {
			$output['wrong_folder'] = true;
		} else {
			$output['wrong_folder'] = false;
		}
		// output
		return $output;
	}

	// -----------------------------------------
	// header check for the topbar
	// -----------------------------------------

	public static function header_check() {
		// get license
		$license = self::get();
		print_r($license);
		// is valid?
		if(!$license) {
			return '<li class="smp-activate"><a class="activate-button" href="#settings/license">Activate Now</a></li>';
		}
	}

	// ----------------------------------------
	// semplice about
	// ----------------------------------------

	public static function about() {
		// get currect license
		$license = self::get();
		// define licenses
		$licenses = array(
			's7-single'				=> 'Single',
			's7-studio'				=> 'Studio',
			's7-single-to-studio'	=> 'Studio',
			's7-business'			=> 'Business',
			's7-single-to-business'	=> 'Business',
			's7-studio-to-business'	=> 'Business',
			'subscription'			=> 'Semplice club',
		);
		// license
		$about = array(
			'registered-to' => 'Michael Schmidt',
			'license-type'  => 'Inactive'
		);
		$card_class = ' invalid';
		if($license && $license['is_valid'] && isset($licenses[$license['product']])) {
			$about['registered-to'] = $license['name'];
			$about['license-type'] = $licenses[$license['product']] . ' License';
			$card_class = ' valid';
		}
		return '
			<div class="labels">
				<div class="label label-type">License Type</div>
				<div class="label label-version">Version</div>
				<div class="label label-status">Status</div>
			</div>
			<div class="infos">
				<div class="info info-type">' . $about['license-type'] . '</div>
				<div class="info info-version">' . SEMPLICE_VER . '</div>
				<div class="info info-status">
					<p class="about-update"><a class="semplice-update" href="#settings/license">New Update (<span class="new-version"></span>)</a></p>
					<p class="about-uptodate">You\'re up to date</p>
					<p class="about-notactivated">Not Activated</p>
				</div>
			</div>
			<div class="license-card' . $card_class . '">
				<img src="' . SEMPLICE_URI . '/assets/images/admin/dashboard/license.png" alt="license-card">
				<div class="license-owner">' . $about['registered-to'] . '</div>
			</div>
		';
	}
}
new License;
?>