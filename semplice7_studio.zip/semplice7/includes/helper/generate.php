<?php

// namespace
namespace Semplice\Helper;

// use
use Semplice\Helper\Ram;
use Semplice\Helper\Background;
use Semplice\Helper\Image;
use stdClass;

// -----------------------------------------
// semplice generate helper
// -----------------------------------------

class Generate {

	// -----------------------------------------
	// generate post settings
	// -----------------------------------------

	public static function post_settings($settings, $post) {
		// check if row has page settings
		if($settings !== null && is_array($settings)) {
			// always get the latest saved title and permalink to match wordpress
			$settings['meta']['post_title'] = $post->post_title;
			$settings['meta']['permalink'] = $post->post_name;
		} else {
			// define some post settings defaults
			$settings = array(
				'thumbnail' => array(
					'image' => '',
					'width'	=> '',
					'hover_visibility' => 'disabled',
				),
				'meta' => array(
					'post_title' 	=> $post->post_title,
					'permalink'  	=> $post->post_name,
				),
			);
		}
		// has with already?
		if(isset($settings['thumbnail']) && empty($settings['thumbnail']['width'])) {
			$settings['thumbnail']['width'] = '4';
		}
		// is seo a string?
		$settings['seo'] = (empty($settings['seo'])) ? array() : $settings['seo'];
		// yoast seo settings
		$yoast = array('title', 'metadesc', 'opengraph-image', 'opengraph-title', 'opengraph-description', 'twitter-image', 'twitter-title', 'twitter-description', 'meta-robots-nofollow', 'meta-robots-noindex', 'canonical');
		$prefix = '_yoast_wpseo_';
		// get seo from db
		foreach ($yoast as $setting) {
			// get setting
			$setting = $prefix . $setting;
			// check if post meta is there
			$post_meta = get_post_meta($post->ID, $setting, true);
			// add to semplice or remove from semplice if not in post meta anymore
			if(!empty($post_meta)) {
				$settings['seo'][$setting] = get_post_meta($post->ID, $setting, true);
			} else if(isset($settings['seo'][$setting])) {
				unset($settings['seo'][$setting]);
			}
		}
		// still empty?
		if(!isset($settings['seo']) || empty($settings['seo'])) {
			$settings['seo'] = new stdClass();
		}
		return $settings;
	}

	// -----------------------------------------
	// generate template settings
	// -----------------------------------------

	public static function template_settings($settings) {
		// if not settings default add some default ones
		if(!$settings || !is_array($settings)) {
			// define some post settings defaults
			$settings = array(
				'thumbnail' => array(
					'image' => '',
					'width'	=> '',
					'hover_visibility' => 'disabled',
				),
				'meta' => array(
					'post_title' 	=> 'WP Template',
					'permalink'  	=> 'WP Template',
				),
			);
		}
		return $settings;
	}
}
new Generate;
?>