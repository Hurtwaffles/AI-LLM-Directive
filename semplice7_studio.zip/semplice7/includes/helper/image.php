<?php

// namespace
namespace Semplice\Helper;

// -----------------------------------------
// semplice image helper
// -----------------------------------------

class Image {


	// -----------------------------------------
	// get image
	// -----------------------------------------

	public static function get($id, $size) {
		// image
		$image = false;
		// make sure id is not empty
		if(!empty($id)) {
			// is id or url?
			if(is_numeric($id)) {
				// get attachment
				$attachment = wp_get_attachment_image_src($id, $size, false);
				// is array?
				if(is_array($attachment)) {
					// add image
					$image = array(
						'src'    => $attachment[0],
						'width'  => $attachment[1],
						'height' => $attachment[2],
						'alt' 	 => self::alt($id),
						'title'	 => get_the_title($id),
						'caption'=> wp_get_attachment_caption($id),
						'sizes'  => array(
							'medium'		=> wp_get_attachment_image_url($id, 'medium'),
							'medium_large'	=> wp_get_attachment_image_url($id, 'medium_large')
						),
					);
				} else {
					$image = array(
						'src' 		=> SEMPLICE_URI . '/assets/images/admin/image_missing.svg',
						'width' 	=> 500,
						'height'	=> 500,
						'alt'		=> 'Image not found',
						'caption'   => '',
					);
				}
			} else {
				$attachment = self::external($id);
				// is svg?
				$image = array(
					'src' 		=> $attachment['src'],
					'width' 	=> $attachment['width'],
					'height'	=> $attachment['height'],
					'alt'		=> $attachment['alt'],
					'caption'   => '',
				);
			}
		}
		// no sizes?
		if($image && !isset($image['sizes'])) {
			$image['sizes'] = array('medium' => 'notfound', 'medium_large' => 'notfound');
		}
		// return
		return $image;
	}

	// -----------------------------------------
	// get image src
	// -----------------------------------------

	public static function src($id, $size) {
		// get image url
		$image = wp_get_attachment_image_src($id, $size, false);
		// is still there?
		if(is_array($image)) {
			return $image[0];
		} else {
			return 'notfound';
		}
	}

	// -----------------------------------------
	// get images thats being used in a module
	// -----------------------------------------

	public static function used_in_module($content) {
		// vars
		$module = $content['module'];
		$options = $content['options'];
		$image = false;
		// get image
		if($module == 'video') {
			if(isset($options['poster'])) {
				$image = $options['poster'];
			}
		} else if($module == 'button') {
			if(isset($options['icon'])) {
				$image = $options['icon'];
			}
		} else if($module == 'beforeafter') {
			// before
			$image = array();
			if(isset($options['before'])) {
				$image[] = $options['before'];
			}
			if(isset($options['after'])) {
				$image[] = $options['after'];
			}
		} else if(!empty($content['content']['xl'])) {
			$image = $content['content']['xl'];
		}
		// check if gallery or normal image
		if(is_numeric($image)) {
			return $image . ',';
		} else if(is_array($image)) {
			return implode(',', $image) . ',';
		}
	}

	// -----------------------------------------
	// get external image
	// -----------------------------------------

	public static function external($id) {
		// get media json
		$media = json_decode(file_get_contents(SEMPLICE_DIR . '/assets/json/media.json'), true);
		// return image
		if(strpos($id, 'svg') !== false) {
			return array(
				'src' => self::semplice_image($id),
				'width' => 0,
				'height' => 0,
				'alt' => 'svg-image',
			);
		} else if(strpos($id, 'unsplash') !== false) {
			// set default image height
			$height = 1080;
			// get pos of ratio in url
			$pos = strpos($id, '#ratio');
			// check if ratio is set
			if ($pos !== false) {
				// get ratio
				$ratio = floatval(substr($id, $pos+strlen('#ratio:')));
				// set image height
				$height = round(1080 / $ratio, 0);
				// remove ratio from id
				$id = substr($id, 0, strpos($id, "#ratio"));
			}
			return array(
				'src' => $id,
				'width' => '1080',
				'height' => round(1080 / $ratio, 2),
				'alt' => 'unsplash-image',
			);
		} else if(strpos($id, 'semplice') !== false) {
			return array(
				'src' => self::semplice_image($id),
				'width' => $media['images'][$id]['width'],
				'height' => $media['images'][$id]['height'],
				'alt' => 'semplice-blocks-image',
			);
		} else {
			return array(
				'src' 		=> SEMPLICE_URI . '/assets/images/admin/image_missing.svg',
				'width' 	=> 500,
				'height'	=> 500,
				'alt'		=> 'Image not found',
				'caption'   => ''
			);
		}
	}

	// -----------------------------------------
	// semplice image
	// -----------------------------------------

	public static function semplice_image($id) {
		// get version
		$version = (strpos($id, 'semplice7') !== false) ? 'v7' : 'v5';
		$replace = (strpos($id, 'semplice7') !== false) ? 'semplice7_' : 'semplice_';
		// return
		return 'https://blocks.semplice.com/' . $version . '/images/' . str_replace($replace, '', $id);
	}	

	// -----------------------------------------
	// image alt
	// -----------------------------------------

	public static function alt($id) {
		$alt = get_post_meta($id, '_wp_attachment_image_alt', true);
		// check if alt text is available
		if(empty($alt)) {
			$alt = get_the_title($id);
		}
		// return
		return $alt;
	}

	// -----------------------------------------
	// blocks image array
	// -----------------------------------------

	public static function blocks_array($images) {
		$output = array();
		// check if images array is empty?
		if(!empty(array_filter($images))) {
			// fetch all image urls in case they have chnaged (ex domain)
			foreach ($images as $id) {
				// get image
				$output[$id] = self::get($id, 'full');
			}
		}
		// return
		return $output;
	}

	// ----------------------------------------
	// get admin images
	// ----------------------------------------

	public static function admin_images() {
		// vars
		$ids = json_decode(get_option('semplice_admin_images'), true);
		$images = array();
		// iterate through images
		if(is_array($ids) && !empty($ids)) {
			// check if broken or empty array
			if(array_key_exists (0, $ids) && null === $ids[0]) {
				$images = new stdClass();
			} else {
				// fetch all image urls in case they have chnaged (ex domain)
				foreach ($ids as $id => $url) {
					$image = self::get($id, 'full');
					// is array?
					if(is_array($image)) {
						// add image
						$images[$id] = $image;
					}
				}
			}
		}
		return $images;
	}
}
new Image;
?>