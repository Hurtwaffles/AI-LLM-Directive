<?php

// namespace
namespace Semplice\Helper;

// use
use Semplice\Helper\Get;

// -----------------------------------------
// semplice typography helper
// -----------------------------------------

class Typography {

	// -----------------------------------------
	// get inter
	// -----------------------------------------

	public static function setup_default_fonts() {
		// include semplice default fonts
		$css = '
			@font-face {
				font-family: "Inter";
				font-style:  normal;
				font-weight: 100 900;
				font-display: swap;
				src: url("' . SEMPLICE_URI . '/assets/fonts/inter.woff2") format("woff2");
			}
			@font-face {
				font-family: "Satoshi-Variable";
				font-style:  normal;
				font-weight: 300 900;
				font-display: swap;
				src: url("' . SEMPLICE_URI . '/assets/fonts/satoshi.woff2") format("woff2");
			}
			@font-face {
				font-family: "Satoshi-VariableItalic";
				font-style:  normal;
				font-weight: 300 900;
				font-display: swap;
				src: url("' . SEMPLICE_URI . '/assets/fonts/satoshi-italic.woff2") format("woff2");
			}
			@font-face {
				font-family: "Gambetta-Variable";
				font-style:  normal;
				font-weight: 300 700;
				font-display: swap;
				src: url("' . SEMPLICE_URI . '/assets/fonts/gambetta.woff2") format("woff2");
			}
			@font-face { 
				font-family: "Gambetta-VariableItalic";
				font-style:  normal;
				font-weight: 300 700;
				font-display: swap;
				src: url("' . SEMPLICE_URI . '/assets/fonts/gambetta-italic.woff2") format("woff2");
			}
			@font-face {
				font-family: "Source Code Pro";
				font-style:  normal;
				font-weight: 200 900;
				font-display: swap;
				src: url("' . SEMPLICE_URI . '/assets/fonts/source-code-pro.ttf") format("truetype");
			}
		';
		// generate css
		$weights = array('light' => 300, 'regular' => 400, 'medium' => 500, 'semibold' => 600, 'bold' => 700);
		$fonts = array(
			'satoshi' => array(
				'name' => 'Satoshi-Variable',
				'category' => 'Arial, sans-serif',
				'prefix' => '',
				'affix' => ''
			),
			'satoshi-italic' => array(
				'name' => 'Satoshi-VariableItalic',
				'category' => 'Arial, sans-serif',
				'prefix' => '',
				'affix' => '_italic'
			),
			'gambetta' => array(
				'name' => 'Gambetta-Variable',
				'category' => 'Times, serif',
				'prefix' => 'serif_',
				'affix' => ''
			),
			'gambetta-italic' => array(
				'name' => 'Gambetta-VariableItalic',
				'category' => 'Times, serif',
				'prefix' => 'serif_',
				'affix' => '_italic'
			),
			'inter' => array(
				'name' => 'Inter',
				'category' => 'Arial, sans-serif',
				'prefix' => 'inter_',
				'affix' => ''
			),
		);
		// iterate fonts
		foreach($fonts as $font => $values) {
			// iterate weights
			foreach($weights as $weight => $weight_num) {
				// add to css
				$css .= '
					.' . $values['prefix'] . $weight . $values['affix'] . ',
					[data-font="' . $values['prefix'] . $weight . $values['affix'] . '"],
					[data-font="' . $values['prefix'] . $weight . $values['affix'] . '"] li a { 
						font-family: "' . $values['name'] . '", ' . $values['category'] . ';
						font-weight: ' . $weight_num . ';
						font-style: normal;
						font-variation-settings: normal;
					}
				';
			}
		}
		// return
		return $css;
	}

	// -----------------------------------------
	// get default font list
	// -----------------------------------------

	public static function get_default_fonts($mode, $get_font) {
		// default fonts
		$fonts = json_decode(file_get_contents(SEMPLICE_DIR . '/assets/json/fonts.json'), true);
		// check mode
		if($mode == 'display') {
			$output = array();
			// create array to display names for the atts
			foreach ($fonts as $font => $values) {
				$output[$font] = $values['display-name'];
			}
		} else if($mode == 'get') {
			$output = $fonts[$get_font];
		} else {
			$output = $fonts;
		}
		// output
		return $output;
	}

	// -----------------------------------------
	// get font
	// -----------------------------------------

	public static function get_font($id) {
		// get fonts
		$webfonts = Get::customize('webfonts');
		// is array?
		if(is_array($webfonts) && !empty($webfonts['fonts'])) {
			// is font there?
			if(array_key_exists($id, $webfonts['fonts'])) {
				$font = $webfonts['fonts'][$id]['system-name'];
			} else {
				$font = false;
			}
		} else {
			$font = self::get_default_fontname($id);
		}
		return $font;
	}

	// -----------------------------------------
	// get default fontname
	// -----------------------------------------

	public static function get_default_fontname($font) {
		// get fontlist
		$fonts = self::get_default_fonts('display', false);
		// checkc if its default font
		if(isset($fonts[$font])) {
			return $fonts[$font];
		} else {
			return false;
		}	
	}

	// ----------------------------------------
	// get font family
	// ----------------------------------------

	public static function get_font_family($font_id) {
		// get webfonts
		$webfonts = Get::customize('webfonts');
		// define font
		$font = false;
		// set default font to true
		$default_font = true;
		// get font
		if(is_array($webfonts) && !empty($webfonts['fonts'])) {
			// get real font id if variable webfont
			if(strpos($font_id, 'style_') !== false) {
				foreach($webfonts['fonts'] as $id => $font_array) {
					if(isset($font_array['font_type']) && $font_array['font_type'] == 'variable') {
						if(isset($font_array['styles']) && is_array($font_array['styles']) && !empty($font_array['styles']) && isset($font_array['styles'][$font_id])) {
							$font = $webfonts['fonts'][$id];
						}
					}
				}
			} else if(isset($webfonts['fonts'][$font_id])) {
				$font = $webfonts['fonts'][$font_id];
			}
			// set default font to false
			if($font) {
				$default_font = false;
			}
		}
		// if font is still false use the default fonts
		if(!$font && self::get_default_fontname($font_id)) {
			$font = self::get_default_fonts('get', $font_id);
		} else if(!$font) {
			$font = self::get_default_fonts('get', 'regular');
		}
		// css
		$css = '';
		// valid array?
		if(is_array($font)) {
			// font array
			$font_atts = array(
				'family'   => '',
				'weight'   => '',
				'style'	   => '',
				'variable' => ''
			);
			// font family
			if(strpos($font['system-name'],',') !== false) {
				$font_name = explode(',', $font['system-name']);
				$font_atts['family'] = 'font-family: "' . $font_name[0] . '", "' . $font_name[1] . '", ' . $font['category'] . ';';
			} else {
				$font_atts['family'] = 'font-family: "' . $font['system-name'] . '", ' . $font['category'] . ';';
			}
			// font type
			if(isset($font['font_type']) && $font['font_type'] == 'variable') {
				// variable styles
				if(isset($font['styles']) && is_array($font['styles']) && !empty($font['styles']) && isset($font['styles'][$font_id])) {
					$style = $font['styles'][$font_id];
					// css
					$style_css = '';
					$exclude = array('name', 'font-size', 'line-height', 'letter-spacing');
					foreach ($style as $axis => $val) {
						if(!in_array($axis, $exclude)) {
							$style_css .= "'" . $axis . "' " . $val . ", ";
						}
					}
					// cut off last 2 chars
					$style_css = substr($style_css, 0, -2);
					// add to variable
					$font_atts['variable'] = 'font-variation-settings: ' . $style_css . '; font-weight: normal;';
				}
			} else {
				// font weight
				if(isset($font['font-weight-usage']) && $font['font-weight-usage'] == 'css' || $default_font) {
					$font_atts['weight'] = 'font-weight: ' . $font['font-weight'] . ';';
				} else {
					$font_atts['weight'] = 'font-weight: normal;';
				}
				// when a variable style is set as a font family for h1, p etc. in typography, these font variation settings will overwrite our font weight and needs to be resettet
				// inter (default) is an exception and gets a font-variation-setting because otherwise the styles from typography.scss would overwrite the normal font-weight
				if($font['system-name'] == 'Inter') {
					$font_atts['weight'] .= 'font-variation-settings: "wght" ' . $font['font-weight'] . ';';
				} else {
					$font_atts['weight'] .= 'font-variation-settings: normal;';
				}
				// style
				$font_atts['style'] = 'font-style: ' . $font['font-style'] . ';';
			}
			// css
			$css = $font_atts['family'] . $font_atts['weight'] . $font_atts['style'] . $font_atts['variable'];
		}
		// return
		return $css;
	}
}
new Typography;
?>