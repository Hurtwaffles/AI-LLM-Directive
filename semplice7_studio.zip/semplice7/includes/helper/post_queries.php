<?php

// namespace
namespace Semplice\Helper;

// use
use Semplice\Helper\Basic;
use Semplice\Helper\Thumbnails;
use Semplice\Helper\Get;

// -----------------------------------------
// semplice post queries helper
// -----------------------------------------

class PostQueries {

	// -----------------------------------------
	// get posts
	// -----------------------------------------

	public static function get_posts($request) {
		// output
		$output = array('html' => '', 'emptyState' => '');
		// get projects view
		$projects_view = Get::projects_view();
		// get post count
		$post_count = wp_count_posts($request['post_type']);
		$count = 0;
		// pubslihed posts
		if(isset($post_count->publish))
			$count = $count + $post_count->publish;
		// drafts
		if(isset($post_count->draft))
			$count = $count + $post_count->draft;
		// pending posts
		if(isset($post_count->pending))
			$count = $count + $post_count->pending;
		// private posts
		if(isset($post_count->private))
			$count = $count + $post_count->private;
		// posts per page
		$posts_per_page = 20;
		// pagination
		if($request['page'] != 'show-all') {
			$page_num = intval($request['page']);
		} else {
			$page_num = 1;
			$posts_per_page = -1;
		}
		if($page_num == 0) {
			$page_num = 1;
		}
		// pinned
		$pinned_posts = false;
		$exclude = '';
		if($page_num == 1) {
			if($request['post_type'] == 'page') {
				$pinned = self::get_pinned();
				if(false !== $pinned && !empty($pinned)) {
					$home = get_option('page_on_front');
					// has home?
					$pos = array_search($home, $pinned);
					if(false !== $pos) {
						// unset home and add home id as first id
						unset($pinned[$pos]);
						array_unshift($pinned, $home);
					}
					// pinned args
					$pinned_posts_args = array(
						'posts_per_page' => -1,
						'post_type' 	 => 'page',
						'orderby'		 => 'post__in',
						'post__in'		 => $pinned,
					);
					// excludes
					$exclude = $pinned; 
					// get posts
					$pinned_posts = wp_get_recent_posts($pinned_posts_args);
				}
			}
		}
		// ignore pagination for footers
		if($request['post_type'] == 'footer') {
			$posts_per_page = -1;
		}
		// get pagination
		$pagination = ceil($count / $posts_per_page);
		$pagination_html = '';
		// is page num allowed?
		if($page_num >= $pagination && $request['page'] != 'show-all') {
			$page_num = $pagination;
		}
		if(is_numeric($pagination) && $pagination > 1) {
			// vars
			$active_prev = '';
			$active_next = '';
			// make prev inactive
			if($page_num == 1) {
				$active_prev = 'inactive';
			}
			//make next inactive
			if($page_num == $pagination) {
				$active_next = 'inactive';
			}
			//pagination html

			$pagination_html .= '
				<div class="semplice-pagination">
					<ul>
						<li><a class="show-all" href="#content/pages/show-all">Show all</a></li>
						<li><a href="#content/pages/' . ($page_num-1) . '" id="nav-pages" class="' . $active_prev . ' prev">' . Get::svg('admin', 'post/prev') . '</a></li>
						<li><span>' . $page_num . ' / ' . $pagination . '</span></li>
						<li><a href="#content/pages/' . ($page_num+1) . '" id="nav-pages" class="' . $active_next . ' next">' . Get::svg('admin', 'post/next') . '</a></li>
					</ul>
				</div>
			';
		}
		$views = array('thumb' => '', 'list' => '');
		foreach($views as $view => $view_class) {
			if($view == $projects_view) {
				$views[$view] = ' active';
			}
		}
		// search sort html
		$sort_search = '
			<div class="semplice-page-search">
				<input type="text" placeholder="Search for title" class="search-semplice-pages" name="search-semplice-pages">
			</div>
			<div class="semplice-projects-view">
				<div class="projects-view">
					<button class="click-handler change-projects-view' . $views['thumb'] . '" data-handler="run" data-action-type="helper" data-setting-type="post" data-action="changeView" data-view="thumb">' . Get::svg('admin', '/media-library/view_thumbnails') . '</button>
					<button class="click-handler change-projects-view' . $views['list'] . '" data-handler="run" data-action-type="helper" data-setting-type="post" data-action="changeView" data-view="list">' . Get::svg('admin', '/media-library/view_details') . '</button>
				</div>
			</div>
		';
		// active page num
		$output['pageNum'] = $page_num;
		// check if auth
		$args = array(
			'posts_per_page' => $posts_per_page,
			'offset'		 => ($page_num - 1) * $posts_per_page,
			'post_type' 	 => $request['post_type'],
			'exclude'		 => $exclude,
			'orderby'		 => 'modified'
		);
		// on project pages, show all per default
		if($request['post_type'] == 'project') {
			// posts per page for dashboard
			$args['posts_per_page'] = -1;
			// categories?
			if(isset($request['project_categories'])) {
				$args['categories'] = $request['project_categories'];
			}
			// get portfolio order
			$output['portfolioOrder'] = json_decode(get_option('semplice_portfolio_order'));
			// empty pagination
			$pagination_html = '';
		}
		// get posts or search for posts
		if(isset($request['search_term']) && !empty($request['search_term'])) {
			$posts = self::search_by_title($request['search_term'], 'post_modified', $request['post_type']);
		} else {
			$posts = wp_get_recent_posts($args);
		}
		// posts top row
		$posts_top_row = '';
		if($request['post_type'] != 'project' || $projects_view == 'list') {
			$posts_top_row = '
				<div class="posts-list posts-view-' . $projects_view . ' admin-row">
					<div class="posts-top-row admin-row">
						<div class="admin-column" data-xl-width="5"><span class="post-title">Title</span></div>
						<div class="admin-column" data-xl-width="2">Status</div>
						<div class="admin-column" data-xl-width="2">Last Modified</div>
					</div>
			';
		} else {
			$posts_top_row = '
				<div class="projects-list admin-row">
			';
		}
		if(!$posts && !$pinned_posts) {
			$output['html'] .= 'nopost';
		} else {
			// header
			$header = '
				<div class="admin-row">
					<div class="admin-column admin-header posts-header">
						<div class="heading">
							<h2 class="admin-title">All ' . ucfirst($request['post_type']) . 's</h2>
						</div>
						<div class="actions">
							' . $sort_search . '
							<button class="click-handler add-post" data-button-icon="plus" data-handler="run" data-action-type="dialog" data-setting-type="post" data-action="add" data-post-type="' . $request['post_type'] . '"><span></span>Add New ' . $request['post_type'] . '</button>
						</div>
					</div>
				</div>
			';
			// hide header?
			if(isset($request['hide_row_header']) && $request['hide_row_header']) {
				$header = '';
			}
			// define post status
			$post_status = '';
			$posts_html = '';
			// get pinned
			if(is_array($pinned_posts)) {
				if(!isset($request['search_term']) || isset($request['search_term']) && empty($request['search_term'])) {
					$posts_html .= self::iterate_posts($pinned_posts, $request['post_type'], $projects_view);
				}
			}
			// get posts
			$posts_html .= self::iterate_posts($posts, $request['post_type'], $projects_view, false);
			// only posts (for sorting change) or complete page?
			if(isset($request['only_posts']) && Basic::boolval($request['only_posts'])) {
				$output['html'] .= $posts_top_row . $posts_html . '</div>' . $pagination_html;
			} else {
				$output['html'] .= '
					<div class="' . $request['post_type'] . 's posts admin-container">
						' . $header . '
						' . $posts_top_row . '
						' . $posts_html . '
						</div>
						' . $pagination_html . '
					</div>
				';
			}
		}
		return $output;
	}

	// -----------------------------------------
	// get projects
	// -----------------------------------------

	public static function get_projects($portfolio_order, $categories, $limit, $offset, $projectnav, $status) {
		// categories?
		if(is_array($categories) && !empty($categories)) {
			// first check if categories still exists
			foreach($categories as $key => $id) {
				if(!term_exists(intval($id))) {
					unset($categories[$key]);
				}
			}
			$categories = implode(', ', $categories);
		}
		// generate thumbnails
		$args = array(
			'posts_per_page'=> $limit,
			'post__in' 	 	=> $portfolio_order,
			'post_type'	  	=> 'project',
			'post_status' 	=> $status,
			'orderby' 	  	=> 'post__in',
			'category'      => $categories,
		);
		// offset
		if($offset && $offset > 0) {
			$args['offset'] = $offset;
		}
		$posts = get_posts($args);
		$projects = array();
		// go through order and add to list
		if(null !== $posts) {
			$i = 0;
			foreach ($posts as $post) {
				// get post settings
				$post_settings = json_decode(get_post_meta($post->ID, '_semplice_post_settings', true), true);
				// project nav visibility
				$projectnav_visibility = true;
				if(isset($post_settings['meta']['projectnav_visibility']) && !Basic::boolval($post_settings['meta']['projectnav_visibility'])) {
					$projectnav_visibility = false;
				}
				// add to projects
				if(!$projectnav || $projectnav && $projectnav_visibility) {
					// get thumbnails
					$thumbnails = Thumbnails::get($post->ID, true, 'full');
					// add to projects
					$projects[$i] = array(
						'post_id' => $post->ID,
						'post_title' => $post->post_title,
						'permalink' => get_permalink($post->ID),
						'image' => $thumbnails['image'],
						'pp_thumbnail' => $thumbnails['project_panel'],
						'nextprev_thumbnail' => $thumbnails['nextprev'],
						'categories' => wp_get_post_categories($post->ID),
					);
					// is individual thumb hover activated?
					if(isset($post_settings['thumbnail']['hover_visibility']) && $post_settings['thumbnail']['hover_visibility'] == 'enabled') {
						$projects[$i]['thumb_hover'] = $post_settings['thumbnail'];
					}
					// project type
					if(isset($post_settings['meta']['project_type']) && !empty($post_settings['meta']['project_type'])) {
						$projects[$i]['project_type'] = $post_settings['meta']['project_type'];
					} else {
						$projects[$i]['project_type'] = 'Project type';
					}
					// inc
					$i++;
				}
			}
		}
		return $projects;
	}

	// -----------------------------------------
	// iterate posts
	// -----------------------------------------

	public static function iterate_posts($posts, $post_type, $projects_view) {
		$posts_html = '';
		foreach ($posts as $key => $post) {
			// is semplice?
			$is_semplice = get_post_meta($post['ID'], '_is_semplice', true);
			// get thumbnail
			if($post_type == 'project') {
				// get thumbnail
				$thumbnail = Thumbnails::get($post['ID'], false, 'medium_large');
			} else {
				$thumbnail = false;
			}
			// format post
			$posts_html .= self::post_row($post, $post_type, false, $thumbnail, $is_semplice, $projects_view, false);
		}
		return $posts_html;
	}

	// -----------------------------------------
	// post row
	// -----------------------------------------

	public static function post_row($post, $post_type, $is_duplicate, $thumb, $is_semplice, $view, $is_dashboard) {
		// vars
		$output = '';
		$classes = array(
			'is_semplice' => '',
			'is_pinned' => ''
		);
		$thumb_data = ($thumb && $thumb['src']) ? ' data-thumbnail-src="' . $thumb['src'] . '"' : '';
		$activate_semplice = '';
		$front_page = (get_option('page_on_front') == $post['ID']) ? '<span class="semibold">&mdash; Front Page</span>' : '';
		$css = ($is_duplicate) ? 'style="opacity: 0; transform: translateY(-30px) scale(.9);"' : '';
		// post
		$post['post_status'] = ($post['post_status'] == 'publish') ? 'published' : $post['post_status'];
		$post['post_title'] = (empty($post['post_title'])) ? 'Untitled-' . $post['ID'] : $post['post_title'];
		// is semplice
		if(!$is_semplice) {
			$classes['is_semplice'] = ' no-semplice';
			$activate_semplice = '<button class="edit-with-semplice click-handler"  data-post-id="' . $post['ID'] . '" data-handler="run" data-action-type="dialog" data-setting-type="post" data-action="convert">Convert to Semplice</button>';
		}
		// is pinned
		$pinned_mode = 'favorite';
		$pinned = self::get_pinned();
		if(is_array($pinned) && in_array($post['ID'], $pinned)) {
			$classes['is_pinned'] = ' semplice-is-pinned';
			$pinned_mode = 'unfavorite';
		}
		// thumbview
		if($post_type == 'project' && $view == 'thumb') {
			// get post type again to make sure to support pages in the dashboard
			$post_type = get_post_type($post['ID']);
			// add page icon if post type is page (dashboard)
			if($post_type == 'page') {
				$thumbnail['bg'] = 'data-thumbnail="no-page-thumb"';
			}
			// thumbnail html
			$thumb_image = ($thumb['src']) ? '<img src="' . $thumb['src'] . '">' : '<img src="' . SEMPLICE_URI . '/assets/images/admin/post/' . $post_type . '_thumb.svg">';
			$thumbnail_html = '
				<div class="thumbnail" data-type-bg="' . $post_type . '">
					' . $thumb_image . '
					<div class="post-actions">' . self::post_actions($post, $post_type, $thumb_data, false, false, $view, $is_dashboard) . '</div>
				</div>
			';
			// add to thumb view output
			$output .= '
				<div class="project admin-column' . $classes['is_semplice'] . '" data-xl-width="3" id="' . $post['ID'] . '"' . $thumb_data . ' ' . $css . '>
					' . $activate_semplice . '
					<div class="column-inner">
						' . $thumbnail_html . '
						<div class="project-meta">
							<div class="post-title"><h2>' . $post['post_title'] . '</h2></div>
							<div class="post-status">' . self::post_status($post['ID'], $post['post_status']) . '</div>
							' . self::preview_link($post_type, 'project', $post['ID'], $post['post_name'], true, $view, $is_dashboard) . '
						</div>
					</div>
				</div>
			';
		} else {
			$output .= '
				<div class="' . $post_type . ' post ' . $classes['is_semplice'] . $classes['is_pinned'] . '" id="' . $post['ID'] . '" ' . $css . '>
					<div class="post-title admin-column" data-xl-width="5"><h2><a class="post-link" href="#edit/' . $post['ID'] . '">' . $post['post_title'] . $front_page . '</a></h2></div>
					<div class="post-status admin-column" data-xl-width="2">' . self::post_status($post['ID'], $post['post_status']) . '</div>
					<div class="post-date admin-column" data-xl-width="2">' . get_the_modified_date('d/m/Y', $post['ID']) . '</div>
					<div class="post-actions admin-column" data-xl-width="3">' . self::post_actions($post, $post_type, $thumb_data, true, $pinned_mode, $view, $is_dashboard) . '</div>
					' . $activate_semplice . '
				</div>
			';
		}
		return $output;
	}

	// ----------------------------------------
	// get post dropdown
	// ----------------------------------------

	public static function post_dropdown($type) {
		// get type
		$posts = get_posts(array('posts_per_page' => -1, 'post_type' => $type, 'post_status' => 'draft,publish'));
		// pages array
		$posts_array = array(0 => '— Select ' . $type);
		// iterate pages object
		if(is_array($posts)) {
			foreach ($posts as $post) {
				// title
				$title = !empty($post->post_title) ? $post->post_title : 'Untitled-' . $post->ID;
				// add to array
				$posts_array[$post->ID] = ($post->post_status == 'publish') ? $title : $title . ' (Draft)';
			}
			return $posts_array;
		} else {
			return array('0' => 'You have no ' . $type . 's');
		}
	}

	// ----------------------------------------
	// menu item select boxes
	// ----------------------------------------

	public static function menu_post_select() {
		// vars
		$output = '';
		$types = array('page', 'project', 'post');
		foreach($types as $type) {
			// get posts dropdown
			$posts = self::post_dropdown($type);
			// output
			$select = '<select>';
			// iterate
			foreach($posts as $id => $title) {
				$select .= '<option value="' . $id . '">' . $title . '</option>';
			}
			// close select
			$select .= '</select>';
			// return
			$output .= '
				<option-input class="menu-select menu-select-' . $type . '">
					<label>Select ' . ucfirst($type) . '</label>
					' . $select . '
				</option-input>
			';
		}
		// return
		return $output;
	}

	// ----------------------------------------
	// get all post queries for init editor
	// ----------------------------------------

	public static function init_editor() {
		// output
		$output = array(
			'apg' => array(),
			'covers' => array(),
			'templates' => '<option value="0">Clone from existing post</option>'
		);
		// fetch all pages and projects
		$args = array(
			'posts_per_page' => -1,
			'post_type' 	 => array('page', 'project'),
			'post_status'	 => 'publish,draft',
		);
		// get posts
		$posts = get_posts($args);
		// index
		$i = 0;
		// iterate throught posts
		if(is_array($posts) && !empty($posts)) {
			foreach ($posts as $id => $post) {
				// check if semplice
				$is_semplice = Basic::boolval(get_post_meta($post->ID, '_is_semplice', true));
				if($is_semplice) {
					// title
					$title = !empty($post->post_title) ? $post->post_title : 'Untitled-' . $post->ID;
					// get ram
					$ram = json_decode(get_post_meta($post->ID, '_semplice_content', true), true);

					// ----------------------------------------
					// covers
					// ----------------------------------------

					if(isset($ram['cover']) && !empty($ram['cover']) && $ram['cover_visibility'] != 'hidden') {
						if($post->post_status == 'publish' || $post->post_status == 'draft') {
							$output['covers'][$post->ID] = ($post->post_status == 'publish') ? $title : $title . ' (Draft)';
						}
					}

					// ----------------------------------------
					// templates
					// ----------------------------------------

					// ignore coversliders
					if(!Basic::boolval(get_post_meta($post->ID, '_is_coverslider', true))) {
						$output['templates'] .= '<option value="' . $post->ID . '">' . substr(($post->post_status == 'publish') ? $title : $title . ' (Draft)', 0, 50) . '</option>';
					}
					
					// ----------------------------------------
					// apg posts
					// ----------------------------------------

					$settings = json_decode(get_post_meta($post->ID, '_semplice_post_settings', true), true);
					// add published or draft
					if($post->post_status == 'publish' || $post->post_status == 'draft') {
						// posts array
						$output['apg'][$i] = array(
							'post_id'	 	=> $post->ID,
							'post_title' 	=> $title,
							'select_title'  => ($post->post_status == 'publish') ? $title : $title . ' (Draft)',
							'post_type'  	=> $post->post_type,
							'permalink'		=> get_permalink($post->ID),
							'thumbnail'  	=> Thumbnails::get($post->ID, false, 'full'),
						);
						// project type
						if(isset($settings['meta']['project_type']) && !empty($settings['meta']['project_type'])) {
							$output['apg'][$i]['project_type'] = $settings['meta']['project_type'];
						} else {
							$output['apg'][$i]['project_type'] = 'Project type';
						}
						$i++;
					}
				}
			}
		}
		// return
		return $output;
	}

	// -----------------------------------------
	// get blogposts checklist
	// -----------------------------------------

	public static function blogposts_checklist() {
		// get pages
		$posts = get_posts(array('posts_per_page' => -1, 'post_type' => array('post')));
		// output
		$output = '';
		// iterate pages object
		if(is_array($posts)) {
			foreach ($posts as $post) {
				$output .= '<li id="post-' . $post->ID . '"><input value="' . $post->ID . '" type="checkbox" name="post[]" id="in-post-' . $post->ID . '"/><p>' . $post->post_title . '</p></li>';
			}
		}
		// return
		return $output;
	}

	// -----------------------------------------
	// get a select list for a specific taxonomy
	// -----------------------------------------

	public static function taxonomy_checklist($taxonomy) {
		// output
		$output = '';
		// not author
		if($taxonomy != 'author') {
			// tag
			$taxonomy = ($taxonomy == 'tag') ? 'post_tag' : $taxonomy;
			// terms
			$terms = get_terms( array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
			));
			// iterate
			if(!empty($terms)) {
				foreach($terms as $term) {
					$output .= '<li id="' . $taxonomy . '-' . $term->term_id . '"><input value="' . $term->term_id . '" type="checkbox" name="' . $taxonomy . '[]" id="in-' . $taxonomy . '-' . $term->term_id . '"/><p>' . $term->name . '</p></li>';
				}
			}
		} else {
			// get users
			$authors = get_users();
			// iterate users
			foreach ($authors as $author) {
				$output .= '<li id="author-' . $author->ID . '"><input value="' . $author->ID . '" type="checkbox" name="author[]" id="in-author-' . $author->ID . '"/><p>' . $author->display_name . '</p></li>';
			}
		}
		// return
		return $output;
	}

	// ----------------------------------------
	// get apg posts
	// ----------------------------------------

	public static function get_apg_posts($mode, $order) {
		// get pages
		$args = array(
			'posts_per_page' => -1, 
			'post_type' => array('page', 'project'),
			'post_status' => 'publish,draft'
		);
		// is order?
		if($order && is_array($order)) {
			$args['post__in'] = $order;
			$args['orderby'] = 'post__in';
		}
		// get posts
		$posts = get_posts($args);
		// pages array
		$posts_array = array();
		// i
		$i = 0;
		// iterate pages object
		if(is_array($posts)) {
			if($mode == 'content') {
				foreach ($posts as $post) {
					// get post settings
					$post_settings = json_decode(get_post_meta($post->ID, '_semplice_post_settings', true), true);
					// title
					$title = !empty($post->post_title) ? $post->post_title : 'Untitled-' . $post->ID;
					// posts array
					$posts_array[$i] = array(
						'post_id'	 	=> $post->ID,
						'post_title' 	=> $title,
						'select_title'  => ($post->post_status == 'publish') ? $title : $title . ' (Draft)',
						'post_type'  	=> $post->post_type,
						'permalink'		=> get_permalink($post->ID),
						'thumbnail'  	=> Thumbnails::get($post->ID, false, 'full'),
					);
					// project type
					if(isset($post_settings['meta']['project_type']) && !empty($post_settings['meta']['project_type'])) {
						$posts_array[$i]['project_type'] = $post_settings['meta']['project_type'];
					} else {
						$posts_array[$i]['project_type'] = 'Project type';
					}
					// inc
					$i++;
				}
			} else {
				if($mode == 'ids') {
					foreach ($posts as $post) {
						$posts_array[] = $post->ID;
						$i++;
					}
				}
			}
		}
		// ret
		return $posts_array;
	}

	// ----------------------------------------
	// get posts with covers
	// ----------------------------------------

	public static function posts_with_covers() {
		// fetch all pages and projects
		$args = array(
			'posts_per_page' => -1,
			'post_type' 	 => array('page', 'project'),
			'post_status'	 => 'draft,publish',
		);
		// get posts
		$posts = get_posts($args);
		// covers
		$covers = array();
		// iterate throught posts
		if(is_array($posts) && !empty($posts)) {
			foreach ($posts as $id => $post) {
				// check if semplice
				$is_semplice = get_post_meta($post->ID, '_is_semplice', true);
				if($is_semplice) {
					// get ram
					$ram = json_decode(get_post_meta($post->ID, '_semplice_content', true), true);
					// check if cover
					if(isset($ram['cover']) && !empty($ram['cover']) && $ram['cover_visibility'] != 'hidden') {
						$covers[$post->ID] = $post->post_title;
					}
				}
			}
		}
		// return covers
		return $covers;
	}

	// ----------------------------------------
	// get pinned
	// ----------------------------------------

	public static function get_pinned() {
		// default
		$posts = false;
		// get pinned
		$pinned = json_decode(get_option('semplice_pinned'), true);
		// has value?
		if(null !== $pinned && is_array($pinned) && !empty($pinned)) {
			$posts = $pinned;
		} else if(null === $pinned) {
			// pin home
			$home = get_option('page_on_front');
			if($home != 0) {
				$posts = array($home);
				update_option('semplice_pinned', json_encode($posts));
			}
		}
		// return
		return $posts;
	}

	// -----------------------------------------
	// post status
	// -----------------------------------------

	public static function post_status($post_id, $status) {
		// get link
		if($status == 'published') {
			$link = '<a class="click-handler published has-tooltip" data-post-id="' . $post_id . '" data-post-status="draft" data-handler="run" data-action-type="helper" data-setting-type="post" data-action="updateStatus" data-tooltip="Make draft" data-tooltip-settings="right,center,auto" data-tooltip-theme="inverted">' . ucfirst($status) . '</a>';
		} else {
			$link = '<a class="click-handler draft has-tooltip" data-post-id="' . $post_id . '" data-post-status="publish" data-handler="run" data-action-type="helper" data-setting-type="post" data-action="updateStatus" data-tooltip="Publish" data-tooltip-settings="right,center,auto" data-tooltip-theme="inverted">' . ucfirst($status) . '</a>';
		}
		// return
		return $link;
	}

	// -----------------------------------------
	// post actions
	// -----------------------------------------

	public static function post_actions($post, $post_type, $thumb_data, $has_preview, $pinned_mode, $view, $is_dashboard) {
		// tooltip offset
		$tooltip_offset = ($post_type == 'page' && !$is_dashboard || $view == 'list') ? ' data-tooltip-offset="20"' : '';
		// has preview?
		$preview = ($has_preview) ? '<li>' . self::preview_link($post_type, 'page', $post['ID'], $post['post_name'], false, $view, $is_dashboard) . '</li>' : '';
		// pinned
		$pinned = ($post_type == 'page') ? '<li class="has-tooltip" data-tooltip="' . (($pinned_mode == 'favorite') ? 'Pin' : 'Unpin') . '" data-tooltip-settings="top,center,auto" data-tooltip-theme="inverted"' . $tooltip_offset . '><a class="semplice-pin click-handler" data-handler="run" data-action-type="helper" data-setting-type="post" data-action="pin" data-mode="' . $pinned_mode . '" data-post-id="' . $post['ID'] . '">' . Get::svg('admin', 'post/pin') . '</a></li<' : '';
		// return
		return '
			<ul>
				<li class="has-tooltip" data-tooltip="Edit" data-tooltip-settings="top,center,auto" data-tooltip-theme="inverted"' . $tooltip_offset . '>
					<a class="edit" href="#edit/' . $post['ID'] . '">' . Get::svg('admin', 'post/edit') . '</a>
				</li>
				<li class="has-tooltip" data-tooltip="Settings" data-tooltip-settings="top,center,auto" data-tooltip-theme="inverted"' . $tooltip_offset . '>
					<a class="page-settings click-handler" data-handler="postSettings" data-post-id="' . $post['ID'] . '"  data-ps-mode="posts" data-post-type="' . $post_type . '"' . $thumb_data . '>' . Get::svg('admin', 'post/settings') . '</a>
				</li>
				<li class="has-tooltip" data-tooltip="Duplicate" data-tooltip-settings="top,center,auto" data-tooltip-theme="inverted"' . $tooltip_offset . '>
					<a class="duplicate click-handler" data-handler="run" data-action-type="helper" data-setting-type="post" data-action="duplicate" data-post-type="' . $post_type . '" data-duplicate-id="' . $post['ID'] . '">' . Get::svg('admin', 'post/duplicate') . '</a>
				</li>
				<li class="has-tooltip" data-tooltip="Delete" data-tooltip-settings="top,center,auto" data-tooltip-theme="inverted"' . $tooltip_offset . '>
					<a class="delete click-handler" data-handler="run" data-action-type="dialog" data-setting-type="post" data-action="delete" data-post-type="' . $post_type . '" data-delete-id="' . $post['ID'] . '">' . Get::svg('admin', 'post/delete') . '</a>
				</li>
				' . $preview . '
				' . $pinned . '
			</ul>
		';
	}

	// -----------------------------------------
	// semplice preview link
	// -----------------------------------------

	public static function preview_link($type, $class, $id, $slug, $has_tooltip, $view, $is_dashboard) {
		// vars
		$project_slug = ($type == 'project') ? Get::project_slug() . '/' : '';
		$has_tooltip = ($type == 'page' && !$is_dashboard || $view == 'list') ? ' has-tooltip' : '';
		// return preview link
		return '<a class="preview-' . $class . $has_tooltip . '" data-tooltip="Preview" data-tooltip-settings="top,center,auto" data-tooltip-theme="inverted" data-tooltip-offset="20" href="' . home_url() . '/' . $project_slug . $slug . '?preview_id=' . $id . '&preview=true" target="_blank">' . Get::svg('admin', 'post/preview') . '</a>';
	}

	// ----------------------------------------
	// search posts by title
	// ----------------------------------------

	public static function search_by_title($search_term, $sortby, $post_type) {
		// global wpdb
		global $wpdb;
		// search posts
		$search_posts = $wpdb->get_results(
			$wpdb->prepare (
				"
				SELECT ID, post_title, post_status, post_name
				FROM $wpdb->posts
				WHERE post_title LIKE '%s'
				AND post_type = '$post_type'
				AND post_status != 'trash'
				ORDER BY $sortby DESC
				",
				'%' . $wpdb->esc_like($search_term) . '%'
			),
			ARRAY_A
		);
		return $search_posts;
	}

	// -----------------------------------------
	// save portfolio order
	// -----------------------------------------

	public static function save_portfolio_order($post_id) {
		// if project, add it to the order list
		if(get_post_status($post_id) != 'trash' && get_post_type($post_id) == 'project') {
			// get list
			$portfolio_order = json_decode(get_option('semplice_portfolio_order'),true);
			// check if in array
			if(is_array($portfolio_order) && !in_array($post_id, $portfolio_order)) {
				// add and save
				array_unshift($portfolio_order , $post_id);
			} else if(!is_array($portfolio_order)) {
				// looks like we are #1
				$portfolio_order = array(0 => $post_id);
			}
			// save
			update_option('semplice_portfolio_order', json_encode($portfolio_order));
		}
	}

	// -----------------------------------------
	// check if a post is removed or in trash
	// -----------------------------------------

	public static function is_removed($id) {
		$is_removed = true;
		// is post or navbar?
		if(strpos($id, 'nav_') !== false) {
			// get navs
			$navigations = Get::customize('navigations');
			if(is_array($navigations) && isset($navigations[$id])) {
				$is_removed = false;
			}
		} else if(false !== get_post_status($id) && get_post_status($id) != 'trash') {
			return false;
		}
		// return
		return $is_removed;
	}
}
new PostQueries;
?>