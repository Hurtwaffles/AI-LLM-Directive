<?php

// namespace
namespace Semplice\Helper;

// use
use Semplice\Helper\Color;
use Semplice\Helper\Background;

// -----------------------------------------
// semplice thumbnails helper
// -----------------------------------------

class Thumbnails {

	// -----------------------------------------
	// get thumbnail
	// -----------------------------------------

	public static function get($id, $all_types, $size) {
		// get post settings from meta
		$settings = json_decode(get_post_meta($id, '_semplice_post_settings', true), true);
		// types
		if(true === $all_types) {
			$types = array('image', 'project_panel', 'nextprev');
		} else {
			$types = array('image');
		}
		// thumbnails
		$thumbnails = array();
		// define defaults
		$defaults = array(
			'src' => SEMPLICE_URI . '/assets/images/admin/post/project_thumb.svg',
			'width' => '0',
			'height' => '0',
			'grid_width' => '4'
		);
		// iterate types
		foreach ($types as $type) {
			// add defaults to thumbnails
			$thumbnails[$type] = $defaults;
			// get img src
			if(is_array($settings)) {
				if(isset($settings['thumbnail'][$type]) && is_numeric($settings['thumbnail'][$type])) {
					$thumbnail_src = wp_get_attachment_image_src($settings['thumbnail'][$type], $size, false);
					// image still exists?
					if($thumbnail_src) {
						$thumbnails[$type] = array(
							'src'   => $thumbnail_src[0],
							'width' => $thumbnail_src[1],
							'height'=> $thumbnail_src[2],
						);
					}
				}
				// grid width
				if(isset($settings['thumbnail']['width']) && !empty($settings['thumbnail']['width'])) {
					$thumbnails[$type]['grid_width'] = $settings['thumbnail']['width'];
				} else if($type == 'image') {
					$thumbnails[$type]['grid_width'] = $defaults['grid_width'];
				}
			}
			// check if type is not image and if there is a thumbnail set, if not use the grid thumbnail
			if($type != 'image' && strpos($thumbnails[$type]['src'], 'project_thumb.svg') !== false) {
				$thumbnails[$type]['src'] = $thumbnails['image']['src'];
			} 
		}
		// return
		if(true === $all_types) {
			return $thumbnails;
		} else {
			return $thumbnails['image'];
		}
	}

	// -----------------------------------------
	// get thumbnail id
	// -----------------------------------------

	public static function get_id($settings) {
		return (is_array($settings) && isset($settings['thumbnail']['image']) && is_numeric($settings['thumbnail']['image'])) ? $settings['thumbnail']['image'] : '';
	}
}
new Thumbnails;
?>