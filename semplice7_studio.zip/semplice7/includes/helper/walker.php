<?php

// namespace
namespace Semplice\Helper;

// use
use Semplice\Helper\Get;
use Walker_Nav_Menu;

// -----------------------------------------
// custom walker
// -----------------------------------------

class Walker extends Walker_Nav_Menu {
	 // Suppress the start of a new level.
	public function start_lvl( &$output, $depth = 0, $args = array() ) {
		$output .= ($depth == 0) ? "\n<ul class=\"sub-menu\">\n" : '';
	}
	// Suppress the end of a level.
	public function end_lvl( &$output, $depth = 0, $args = array() ) {
		$output .= ($depth == 0) ? "</ul>\n" : '';
	}
	public function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
		// Get the list of classes for the menu item.
		$classes = empty($item->classes) ? array() : (array) $item->classes;
		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter($classes), $item, $args));
		$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';
		// Build the opening <li> tag.
		$output .= '<li' . $class_names . '>';
		// Set up the attributes for the <a> element.
		$attributes  = ! empty($item->attr_title) ? ' title="'  . esc_attr($item->attr_title) .'"' : '';
		$attributes .= ! empty($item->target)   ? ' target="' . esc_attr($item->target) .'"' : '';
		$attributes .= ! empty($item->xfn)  ? ' rel="'	. esc_attr($item->xfn) .'"' : '';
		$attributes .= ! empty($item->url)  ? ' href="'   . esc_attr($item->url) .'"' : '';
		// Begin building the output for the link.
		$item_output  = $args->before;
		$item_output .= '<a' . $attributes . '>';
		$item_output .= $args->link_before . apply_filters('the_title', $item->title, $item->ID) . $args->link_after;
		// hover effect
		if($args->semplice['effect'] == 'flip' && $depth === 0) {
			$item_output .= '<span class="copy">' . apply_filters('the_title', $item->title, $item->ID) . $args->link_after;
		}
		// Check if the menu item has children.
		if(in_array('menu-item-has-children', $classes, true) && $depth === 0) {
			// add arrow
			$item_output .= '<submenu-arrow>' . (($args->semplice['arrow']) ? $args->semplice['arrow'] : Get::svg('frontend', 'arrows/sub_menu')) . '</submenu-arrow>';
		}
		$item_output .= '</a>';
		$item_output .= $args->after;
		// Append the result to the overall output.
		$output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
	}
}

new Walker;
?>