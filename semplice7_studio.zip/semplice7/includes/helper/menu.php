<?php

// namespace
namespace Semplice\Helper;

// use
use Semplice\Helper\Basic;
use Semplice\Helper\Walker;

// -----------------------------------------
// semplice rest api helper
// -----------------------------------------

class Menu {

	// -----------------------------------------
	// get menu html
	// -----------------------------------------

	public static function html($id, $options) {
		$output = '';
		// default options if false
		$options = ($options) ? $options : array('effect' => false, 'arrow' => false);
		// has id?
		if($id) {
			// get menu
			$menu = wp_get_nav_menu_object($id);
			// exists?
			if($menu) {
				// get items
				$items = wp_get_nav_menu_items($id);
				// make sure its not empty
				if ($items || count($items) > 0) {
					$output = wp_nav_menu(
						array(
							'menu'			 => $id,
							'items_wrap' 	 => '%3$s',
							'echo' 			 => false,
							'container' 	 => false,
							'fallback_cb'	 => false,
							'link_before'	 => '<span>',
							'link_after'	 => '</span>',
							'semplice'   	 => $options,
							'walker'         => new Walker()
						)
					);
				}
			}
		}
		// get default page menu if output if empty
		if(empty($output)) {
			$output = wp_page_menu(
				array(
					'echo' 		  	=> false,
					'items_wrap'  	=> '%3$s',
					'container'   	=> false,
					'before'	  	=> '',
					'after'		  	=> '',
					'link_before' 	=> '<span>',
					'link_after' 	=> '</span>'
				)
			);
		}
		// remove div container
		$output = str_replace(array('<div class="menu">', '</div>'), array('', ''), $output);
		// return
		return '
			<nav>
				<ul>' . $output . '</ul>
			</nav>
		';
	}

	// -----------------------------------------
	// list menus
	// -----------------------------------------

	public static function list() {
		// vars
		$menus = get_terms('nav_menu');
		$options = array(
			0 => array(
				'name'	=> 'WordPress Fallback',
				'items' => false,
				'html'  => self::html(false, false)
			)
		);
		// has menus?
		if(!empty($menus)) {
			foreach($menus as $menu) {
				$options[$menu->term_id] = array(
					'name'  => $menu->name,
					'items' => self::items($menu->term_id),
					'html'  => self::html($menu->term_id, false)
				);
			}
		}
		// return
		return $options;
	}

	// -----------------------------------------
	// get menu items
	// -----------------------------------------

	public static function items($term_id) {
		// output
		$output = array();
		// get items
		$items = wp_get_nav_menu_items($term_id);
		// iterate items
		if(!empty($items) && is_array($items)) {
			foreach($items as $index => $item) {
				$output[$index] = array(
					'id'		=> $item->ID,
					'postId'	=> $item->object_id,
					'title' 	=> $item->title,
					'type'		=> $item->post_type,
					'parent' 	=> $item->menu_item_parent,
					'url'		=> $item->url,
					'target'	=> $item->target,
					'classes'	=> implode(' ', $item->classes)
				);
			}
		}
		// return
		return $output;
	}

	// -----------------------------------------
	// add menu
	// -----------------------------------------

	public static function add() {
		// create nav menu
		$id = wp_create_nav_menu('Menu ' . substr(md5(rand()), 0, 4));
		// add one item
		$home = array(
			'menu-item-title' => 'Home',
			'menu-item-url' => home_url(),
			'menu-item-status' => 'publish'
		);
		wp_update_nav_menu_item($id, 0, $home);
		// return new list
		return self::list();
	}

	// -----------------------------------------
	// save menu
	// -----------------------------------------

	public static function save($id, $menu) {
		// vars
		$menu = json_decode($menu, true);
		$menu_object = wp_get_nav_menu_object($id);
		$items = $menu['items'];
		$removed = (isset($menu['removed'])) ? $menu['removed'] : array();
		// remove nav items
		if(is_array($removed) && !empty($removed)) {
			foreach($removed as $removed_id)
			// cceck if post is there
			if(get_post_status($removed_id)) {
				wp_delete_post($removed_id, true);
			}
		}
		// iterate
		if(null !== $items && is_array($items) && is_object($menu_object)) {
			// update name
			wp_update_nav_menu_object($id, array('menu-name' => $menu['name']));
			// iterate items
			foreach ($items as $i => $item) {
				// is new item?
				if(false !== strpos($item['id'], 'item')) {
					// url
					$url = ($item['type'] == 'custom') ? $item['url'] : '';
					// add
					$new_item_id = wp_update_nav_menu_item($id, $item['id'], array(
						'menu-item-object' 		=> $item['type'],
						'menu-item-object-id' 	=> $item['postId'],
						'menu-item-title'  	 	=> __($item['title']),
						'menu-item-status' 	 	=> 'publish',
						'menu-item-type'	 	=> ($item['type'] == 'custom') ? 'custom' : 'post_type',
						'menu-item-url'			=> $url,
						'menu-item-parent-id' 	=> $item['parent'],
						'menu-item-position'  	=> $i
					));
				} else {
					// args
					$args = array(
						'ID' => $item['id'],
						'menu_order' => $i,
						'post_title' => $item['title']
					);
					wp_update_post($args);
					// update menu classes
					if(!empty($item['classes'])) {
						update_post_meta($item['id'], '_menu_item_classes', preg_split('/\s+/', $item['classes']));
					} else {
						update_post_meta($item['id'], '_menu_item_classes', '');
					}
					// update url
					if(!empty($item['link'])) {
						update_post_meta($item['id'], '_menu_item_url', $item['link']);
					}
					// update target
					if(!empty($item['target']) && $item['target'] == '_blank') {
						update_post_meta($item['id'], '_menu_item_target', $item['target']);
					} else {
						update_post_meta($item['id'], '_menu_item_target', '');
					}
					// parent
					if(!empty($item['parent'])) {
						update_post_meta($item['id'], '_menu_item_menu_item_parent', intval($item['parent']));
					} else {
						update_post_meta($item['id'], '_menu_item_menu_item_parent', 0);
					}
				}
			}
		}
		// return menu
		return array(
			'name'  => $menu['name'],
			'items' => self::items($id),
			'html'  => self::html($id, false)
		);
	}

	// -----------------------------------------
	// remove menu
	// -----------------------------------------

	public static function remove($request) {
		// get menu object
		$menu_object = wp_get_nav_menu_object($request['id']);
		// check if exsits
		if($menu_object) {
			wp_delete_nav_menu($request['id']);
		}
		return 'Deleted Menu ' . $request['id'];
	}
}
new Menu;
?>