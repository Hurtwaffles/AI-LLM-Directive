<?php

// namespace
namespace Semplice;

// use
use Semplice\Editor\EditorStyles;
use Semplice\Editor\Animate;
use Semplice\Editor\Components;
use Semplice\Helper\Basic;
use Semplice\Helper\Styles;
use Semplice\Helper\Get;
use Semplice\Helper\Image;
use Semplice\Helper\Ram;

// -----------------------------------------
// semplice editor
// -----------------------------------------

class Editor {

	// -----------------------------------------
	// public vars
	// -----------------------------------------

	public static $types;
	public static $modules;
	public static $db;
	public static $rev_db_version;
	public static $post_id;
	public static $post_filter;
	public static $output;
	public static $is_editor;
	public static $section;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// database
		global $wpdb;
		self::$db = $wpdb;
		// db version
		self::$rev_db_version = get_option("semplice_revisions_rev_db_version");
	}

	// -----------------------------------------
	// get output
	// -----------------------------------------

	public static function output($ram, $is_editor, $order, $is_coverslider) {

		// output
		self::$output = array(
			'html'   		 => '',
			'css'	 		 => '',
			'module_css'	 => array(),
			'js'	 		 => '',
			'images'		 => array(),
			'slider_ram'	 => array()
		);
		// is editor
		self::$is_editor = $is_editor;
		// post atts
		self::$post_id = isset($ram['post_id']) ? $ram['post_id'] : 0;
		self::$post_filter = isset($ram['posts_filter']) ? $ram['posts_filter'] : false;
		// get flat order
		$order = (!$order) ? Ram::section_order($ram, $is_editor) : $order;
		// iterate
		foreach($order as $key => $id) {
			if(strpos($id, 'close-') !== false) {
				$type = str_replace('close-', '', explode('_', $id)[0]);
				$content_id = str_replace('close-', '', $id);
				$prefix = '';
				if($type == 'cover' || $type == 'section') {
					$prefix = '</smp-container>';
					if($type == 'cover') {
						$prefix .= '</smp-cover-inner>';
					}
				} else if($type == 'column') {
					$prefix = '</smp-content-wrapper>';
				}
				self::$output['html'] .= $prefix . '</smp-' . $type . '>';
			} else if(strpos($id, '_') !== false || $id == 'cover') {
				$type = strtok($id, '_');
				self::$types[$type]->init($id, $ram);
				if(!$is_coverslider) {
					self::motions($id, $ram);
				} else {
					self::slider_modules($id, $ram);
				}
			}
		}
		// add animations
		if(!self::$is_editor) {
			self::$output['js'] = '(function ($) { "use strict"; var intro = ' . ((self::$post_id == 'intro') ? 'true' : 'false') . '; ' . self::$output['js'] . '$(window).scroll();})(jQuery);';
		}
		// branding
		if(isset($ram['branding']) && !empty($ram['branding'])) {
			self::branding($ram['branding']);
		}
		// return
		return self::$output;
	}

	// -----------------------------------------
	// add dynamic modules to slider ram
	// -----------------------------------------

	public static function slider_modules($id, $ram) {
		$modules = array('gallery', 'gallerygrid', 'portfoliogrid', 'beforeafter');
		if(isset($ram[$id]) && isset($ram[$id]['module']) && in_array($ram[$id]['module'], $modules)) {
			self::$output['slider_ram'][$id] = $ram[$id];
		}
	}

	// -----------------------------------------
	// motions
	// -----------------------------------------

	public static function motions($id, $ram) {
		// is frontend and id is in ram?
		if(!self::$is_editor && isset($ram[$id])) {
			// get motion
			$animate = Animate::get($ram[$id], $id, self::$post_id);
			// add motion css
			self::$output['css'] .= $animate['css'];
			// add motions to output
			self::$output['js'] .= $animate['js'];
		}
	}

	// -----------------------------------------
	// branding
	// -----------------------------------------

	public static function branding($branding) {
		// add bg image to images array
		self::images_array($branding);
		// is editor?
		if(self::$is_editor) {
			self::$output['css'] .= EditorStyles::css('branding', $branding, false, '#content-holder', false, 'xl');
		} else {
			// selector
			$sel = (self::$post_id == 'intro') ? '#semplice-intro' : 'body .transition-wrap';
			// editor styles
			self::$output['css'] .= EditorStyles::css('branding', $branding, false, $sel, false, 'xl');
			// top arrow color
			if(isset($branding['top_arrow_color'])) {
				self::$output['css'] .= '.back-to-top a svg { fill: ' . $branding['top_arrow_color'] . '; }';
			}
			// custom css
			if(isset($branding['custom_post_css'])) {
				self::$output['css'] .= $branding['custom_post_css'];
			}
		}
	}

	// -----------------------------------------
	// generate data attributes
	// -----------------------------------------

	public static function get_attributes($values) {
		// vars
		$attributes = '';
		foreach ($values as $attribute => $value) {
			if ((array) $value !== $value) {
				$attribute = (strpos($attribute, 'data-') === false) ? 'data-' . $attribute : $attribute;
				$attributes .= ' ' . $attribute . '="' . $value . '"';
			}	
		}
		$attributes = (!empty($attributes)) ? rtrim($attributes, ' ') : '';
		return $attributes;
	}

	// -----------------------------------------
	// has video
	// -----------------------------------------

	public static function has_bg_video($styles) {
		return (isset($styles['background_type']) && $styles['background_type'] == 'vid') ? true : false;
	}

	// -----------------------------------------
	// add bg image to images array
	// -----------------------------------------

	public static function images_array($styles) {
		if(isset($styles['background-image'])) {
			self::$output['images'][$styles['background-image']] = Image::get($styles['background-image'], 'full');
		}
	}

	// -----------------------------------------
	// get link
	// -----------------------------------------

	public static function link($ram) {
		// is link defined?
		if(!self::$is_editor && isset($ram['link'])) {
			// vars
			$link = $ram['link'];
			$type = isset($link['type']) ? $link['type'] : 'url';
			$target = isset($link['target']) ? $link['target'] : '_blank';
			$url = false;
			// url
			if($type == 'url' && isset($link['url']) && !empty($link['url'])) {
				$url = $link['url'];
			} else if($type == 'home') {
				$url = home_url();
			} else if($type != 'url' && isset($link[$type]) && !empty($link[$type])) {
				$url = get_permalink($link[$type]);
			}
			// has url?
			if($url) {
				return ' data-smp-link="' . $url . '" data-smp-link-target="' . $target . '" ';	
			}
		}
	}
}
new Editor;
?>