<?php

// namespace
namespace Semplice\Editor;

// use
use Semplice\Helper\Basic;
use Semplice\Helper\Ram;
use Semplice\Editor;
use Semplice\Editor\Components;

// -----------------------------------------
// semplice revisions
// -----------------------------------------

class Revisions {

	// -----------------------------------------
	// public vars
	// -----------------------------------------

	public static $db;
	public static $rev_db_version;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// database
		global $wpdb;
		self::$db = $wpdb;
		// db version
		self::$rev_db_version = get_option("semplice_revisions_rev_db_version");
		// check status
		add_action('init', array(&$this, 'revisions_status'));
	}

	// -----------------------------------------
	// status
	// -----------------------------------------

	public static function revisions_status() {
		// atts
		$atts = array(
			'rev_db_version' => '1.0',
			'is_update'  	 => false,
			'sql'		 	 => ''
		);
		// check if table is already created
		if(self::$db->get_var("SHOW TABLES LIKE '" . SEMPLICE_REV_TABLE . "'") != SEMPLICE_REV_TABLE || self::$rev_db_version != $atts['rev_db_version']) {
			// setup revisions (install or update)
			self::setup($atts);
		}
	}

	// -----------------------------------------
	// setup
	// -----------------------------------------

	public static function setup($atts) {
		// charset
		$charset_collate = self::$db->get_charset_collate();
		// database tables
		$atts['sql'] = "CREATE TABLE " . SEMPLICE_REV_TABLE . " (
			ID bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			post_id bigint(20) NOT NULL,
			revision_id tinytext NOT NULL,
			revision_title tinytext NOT NULL,
			content longtext NOT NULL,
			settings longtext NOT NULL,
			wp_changes boolean NOT NULL,
			PRIMARY KEY (ID)
		) $charset_collate;";
		// install or update table
		if(!function_exists('revisions_db_install')) {
			function revisions_db_install($atts) {
				require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
				dbDelta($atts['sql']);
				if($atts['is_update'] !== true) {
					// add db version to wp_options
					add_option('semplice_revisions_rev_db_version', $atts['rev_db_version']);
				} else {
					// update db version in wp_optionss
					update_option('semplice_revisions_rev_db_version', $atts['rev_db_version']);
				}
			}
		}
		// check if table exists, if not install table
		if(self::$db->get_var("SHOW TABLES LIKE '" . SEMPLICE_REV_TABLE . "'") != SEMPLICE_REV_TABLE) {
			revisions_db_install($atts);
		}
		// update db if version is newer
		if (self::$rev_db_version != $atts['rev_db_version']) {
			// is update
			$atts['is_update'] = true;
			// update db
			revisions_db_install($atts);
		}
	}

	// -----------------------------------------
	// save
	// -----------------------------------------

	public static function save($request) {
		// post
		$post = json_decode($request['post'], true);
		// revisions
		$revision = $post['revision'];
		// revision id
		$id = $revision['active'];
		// update revisions in the db
		update_post_meta($post['id'], '_semplice_revisions', $revision, '');
		// revision title
		$title = 'Latest Version';
		if(!empty($request['title'])) {
			$title = $request['title'];
		}
		// post id
		$post_id = $post['id'];
		// get content and check slashes
		$content = Basic::check_slashes($request['content']);	
		// get row
		$row = self::$db->get_row("SELECT * FROM " . SEMPLICE_REV_TABLE . " WHERE post_id = '$post_id' AND revision_id = '$id'");
		// check if this is the first save
		if(null === $row) {
			// save revision in the database
			self::$db->insert(
				SEMPLICE_REV_TABLE,
				array(
					"post_id"		 => $post_id,
					"revision_id"  	 => $id,
					"revision_title" => $title,
					"content"		 => $content,
					"settings"		 => '',
					"wp_changes"	 => 0
				)
			);
		} else {
			// update unsaved changes
			self::$db->update(
				SEMPLICE_REV_TABLE, 
				array(
					"content"	  	=> $content,
				),
				array(
					"post_id" 		=> $post['id'],
					"revision_id"	=> $id
				)
			);
		}
		// only return something if a new version is saved
		if(isset($request['save_version'])) {
			return new WP_REST_Response('Revision saved.', 200);
		}
	}

	// -----------------------------------------
	// load
	// -----------------------------------------

	public static function load($request) {
		// vars
		$post_id = $request['post_id'];
		$id = $request['id'];
		$post_revision = $request['post_revision'];
		// get revision
		$revision = self::$db->get_row("SELECT * FROM " . SEMPLICE_REV_TABLE . " WHERE post_id = '$post_id' AND revision_id = '$id'");
		// init components
		if(null !== $revision) {
			if(isset($revision->content) && !empty($revision->content)) {
				$revision->content = Components::get($revision->content);
				// get content
				$content = Editor::output(json_decode($revision->content, true), true, false, false);
				// module css
				$module_css = isset($content['module_css']) ? $content['module_css'] : array();
				// output
				$output = array(
					'ram' 		 => $revision->content,
					'html' 		 => $content['html'],
					'css' 		 => $content['css'],
					'module_css' => $module_css,
					'status'	 => 'ok',
				);
			} else {
				// output
				$output = array(
					'ram' 	=> 'empty',
					'html'  => $default_html = semplice_default_cover('hidden'),
					'status'=> 'ok',
				);
			}
			// set active revision
			$post_revision['active'] = $id;
			// update post meta
			update_post_meta($post_id, '_semplice_revisions', $post_revision, '');
		} else {
			$output = array('status' => 'error');
		}
		return $output;
	}

	// -----------------------------------------
	// get
	// -----------------------------------------

	public static function get($id, $post_id) {
		// get revision
		$revision = self::$db->get_row(
			self::$db->prepare("SELECT * FROM " . SEMPLICE_REV_TABLE . " WHERE post_id = %d AND revision_id = %s", array($post_id, $id))
		);
		// revision is not in the DB anymore or anything went wrwong? get latest version
		if($revision === null) {
			$revision = self::$db->get_row(
				self::$db->prepare("SELECT * FROM " . SEMPLICE_REV_TABLE . " WHERE post_id = %d AND revision_id = %s", array($post_id, 'latest_version'))
			);
		}
		return $revision;
	}

	// -----------------------------------------
	// get revisions list
	// -----------------------------------------

	public static function list($post_id) {
		// output
		$output = array();
		// get post revision
		$post_revision = self::post($post_id);
		// get revisions
		$revisions = self::$db->get_results( 
			"
			SELECT * 
			FROM " . SEMPLICE_REV_TABLE . "
			WHERE post_id = $post_id
			ORDER BY ID ASC
			"
		);
		// post status
		$post_status = get_post_status($post_id);
		if(!empty($revisions) && count($revisions) > 0) {
			// loop throuh blocks
			foreach($revisions as $revision) {
				// is latest version?
				if($revision->revision_title == 'Latest Version') {
					$revision->revision_title = 'Default Version';
				}
				// add to output
				$output[] = array(
					'id'	 => $revision->revision_id,
					'title'  => $revision->revision_title
				);
			}
		} else {
			// empty state
			$output = 'empty';
		}
		// return
		return $output;
	}
	
	// -----------------------------------------
	// get post revision
	// -----------------------------------------

	public static function post($post_id) {
		// get post revision
		$post_revision = get_post_meta($post_id, '_semplice_revisions', true);
		// is available?
		if(empty($post_revision) || !is_array($post_revision)) {
			return array(
				'active' => 'latest_version',
				'published' => 'latest_version',
			);
		} else {
			return $post_revision;
		}
	}

	// -----------------------------------------
	// rename revision
	// -----------------------------------------

	public static function rename($request) {
		// update title
		self::$db->update(
			SEMPLICE_REV_TABLE, 
			array(
				"revision_title" => $request['title'],
			),
			array(
				"post_id" 		=> $request['post_id'],
				"revision_id"	=> $request['id']
			)
		);
		// return list
		return self::list($request['post_id']);
	}

	// -----------------------------------------
	// delete revision
	// -----------------------------------------

	public static function delete($request) {
		// post revision
		$post_revision = $request['post_revision'];
		// update trigger
		$update_post_meta = false;
		// post id
		$post_id = $request['post_id'];
		// iterate post revision
		foreach ($post_revision as $status => $revision_id) {
			if($revision_id == $request['id']) {
				$post_revision[$status] = 'latest_version';
				// trigger update
				$update_post_meta = true;
				// if published, make default version published
				if($status == 'published') {
					// get latest version and save to post meta
					$latest_version = self::$db->get_row("SELECT * FROM " . SEMPLICE_REV_TABLE . " WHERE post_id = '$post_id' AND revision_id = 'latest_version'");
					if(null !== $latest_version && !empty($latest_version->content)) {
						$encoded_ram = json_encode(Ram::change_ids($latest_version->content, true, false, 'section'), JSON_FORCE_OBJECT);
					} else {
						$encoded_ram = '';
					}
					// save to post meta
					update_post_meta($post_id, '_semplice_content', wp_slash($encoded_ram));
				}
			}
		}
		// update post meta
		if(true === $update_post_meta) {
			update_post_meta($request['post_id'], '_semplice_revisions', $post_revision, '');
		}
		// delete from database
		self::$db->delete(
			SEMPLICE_REV_TABLE,
			array(
				'revision_id' => $request['id'],
				'post_id'	  => $post_id,
			)
		);
		// output
		return array(
			'list' => self::list($post_id),
			'post_revision' => $post_revision
		);
	}
}
new Revisions;
?>