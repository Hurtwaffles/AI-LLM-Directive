<?php

// namespace
namespace Semplice\Editor;

// helper
use Semplice\Helper\Get;
use Semplice\Editor\Blocks;

// -----------------------------------------
// sidebar helper class
// -----------------------------------------

class Sidebar {

	// -----------------------------------------
	// format post id
	// -----------------------------------------

	public static function init() {
		// output
		$output = '';
		// define sidebars
		$sidebars = array('navigator', 'modules', 'blocks', 'settings');
		// iterate sidebars
		foreach($sidebars as $sidebar) {
			$output .= '<div class="editor-sidebar sidebar-' . $sidebar . '">' . self::{$sidebar}() . '</div>';
		}
		// return output
		return '
			<div class="sidebar-overlay">
				<p class="sidebar-continue"><span class="text">Continue Editing</span> <span class="rsaquo">&rsaquo;</span></p>
			</div>
			<div id="editor-sidebars">' . $output . '</div>
		';
	}

	// -----------------------------------------
	// navigator
	// -----------------------------------------

	public static function navigator() {
		return '
			<div class="navigator-nav">
				<div class="navigator-exit">
					<button class="navigator-action editor-action" data-handler="run" data-action-type="dialog" data-setting-type="core" data-action="exitEditor">' . Get::svg('editor', 'sidebar/navigator/exit') . '<span>Overview</span></button>
				</div>
				<div class="navigator-quicknav">
					<button class="navigator-action click-handler" data-handler="run" data-action-type="dialog" data-setting-type="core" data-action="exitEditor" data-new-url="#content/pages/1" data-exit-mode="close">' . Get::svg('editor', 'sidebar/navigator/pages') . '<span>Pages</span></button>
					<button class="navigator-action click-handler" data-handler="run" data-action-type="dialog" data-setting-type="core" data-action="exitEditor" data-new-url="#content/projects/1" data-exit-mode="close">' . Get::svg('editor', 'sidebar/navigator/projects') . '<span>Projects</span></button>
					<button class="navigator-action click-handler" data-handler="run" data-action-type="dialog" data-setting-type="core" data-action="exitEditor" data-new-url="#customize/grid" data-exit-mode="close">' . Get::svg('editor', 'sidebar/navigator/customize') . '<span>Customize</span></button>
					<button class="navigator-action click-handler" data-handler="run" data-action-type="dialog" data-setting-type="core" data-action="exitEditor" data-new-url="#settings/general" data-exit-mode="close"">' . Get::svg('editor', 'sidebar/navigator/settings') . '<span>Settings</span></button>
				</div>
			</div>
			<div class="sidebar-content">
				<div class="posts" data-status="collapsed">
					<div class="pages">
						<h3>Pages</h3>
						<ul>' . self::get_posts('page') . '</ul>
					</div>
					<div class="projects">
						<h3>Projects</h3>
						<ul>' . self::get_posts('project') . '</ul>
					</div>
				</div>
				<div class="customize">
					<h3>Customize</h3>
					<div class="featured-settings">' . self::featured_settings() . '</div>
					<div class="customize-settings">' . Get::customize_nav('customize', 'editor', array('typography', 'grid', 'navigations')) . '</div>
				</div>
				<div class="customize">
					<h3>Settings</h3>
					<div class="customize-settings">' . Get::customize_nav('settings', 'editor', array()) . '</div>
				</div>
			</div>
		';
	}

	// -----------------------------------------
	// modules
	// -----------------------------------------

	public static function modules() {
		// modules
		$modules = array(
			'other' => array(
				'title' => 'General',
				'modules' => array(
					'fluidtext'				=> 'Fluid Text',
					'paragraph'				=> 'Text (Legacy)',
					'code'					=> 'Code',
					'mailchimp'				=> 'Mailchimp',
					'beforeafter'			=> 'Before After',
					'lottie'				=> 'Lottie',
					'marquee'				=> 'Marquee',
					'accordion'				=> 'Accordion',
					'gallerygrid'   		=> 'Gallery Grid',
				),
			),
			'portfolio' => array(
				'title' => 'Portfolio',
				'modules' => array(
					'portfoliogrid' 		=> 'Portfolio Grid',
					'singleproject'			=> 'Single Project'
				),
			),
			'apg' => array(
				'title' => 'Advanced Portfolio Grid',
				'modules' => array(
					'apg-horfull' => array('preset' => 'horizontal-fullscreen', 'name' => 'Column Grid'),
					'apg-text' => array('preset' => 'text', 'name' => 'Text Grid'),
					'apg-splitscreen' => array('preset' => 'splitscreen', 'name' => 'Splitscreen'),
					'apg-table' => array('preset' => 'table', 'name' => 'Table Grid'),
				),
			),
			'embed' => array(
				'title' => 'Embed Media',
				'modules' => array(
					'youtube' 				=> 'YouTube',
					'vimeo'					=> 'Vimeo',
					'oembed' 				=> 'oEmbed',
				)
			),
			'blog' => array(
				'title' => 'Blog',
				'modules' => array(
					'blogposts'				=> 'Posts',
					'blogarchives'			=> 'Archives',
					'blogsearch'			=> 'Search',
					'blogcomments'			=> 'Comments',
				),
			),
			'share' => array(
				'title' => 'Social Media',
				'modules' => array(
					'share'					=> 'Share',
					'socialprofiles'		=> 'Social Profiles',
				),
			)
		);
		// studio modules
		$studio_modules = array('advancedportfoliogrid', 'instagram', 'gallerygrid', 'mailchimp', 'beforeafter');
		// list
		$list = '';
		foreach ($modules as $groups => $group) {
			// label
			$list .= '
				<h3 class="group-label label-' . $groups . ' inter_regular"><span>' . $group['title'] . '</span></h3>
				<ul class="modules-list" data-group="' . $groups . '">
			';
			foreach ($group['modules'] as $module => $content) {
				// add specific classes
				if(strpos($module, 'apg-') !== false) {
					$classes = ' add-section-module section-only ' . $content['preset'];
					$apg_preset = ' data-apg="' . $content['preset'] . '" ';
					$name = $content['name'];
					$icon = Get::svg('editor', 'sidebar/modules/apg_' . $content['preset']);
					$module = 'advancedportfoliogrid';
				} else {
					// add section module class for coverslider
					$classes = ($module == 'coverslider') ? ' add-section-module section-only' : '';
					$icon = Get::svg('editor', 'sidebar/modules/' . $module);
					$name = $content;
					$apg_preset = '';
				}
				// add to list
				if(SEMPLICE_EDITION == 'single' && in_array($module, $studio_modules)) {
					$list .= '<li class="module-' . $module . '"><a class="add-content-single click-handler" data-module="' . $module . '" data-handler="run" data-action="studio" data-action-type="dialog" data-setting-type="core" data-feature="' . $module . '"><span class="icon">' . $icon . '</span><span>' . $name . '</span><i>Studio</i></a></li>';
				} else {
					$list .= '<li class="module-' . $module . '"><a class="add-content add-module' . $classes . '"' . $apg_preset . 'data-module="' . $module . '"><span class="icon">' . $icon . '</span><span>' . $name . '</span></a></li>';
				}
			}
			$list .= '</ul>';
		}
		// output list
		return '
			<div class="sidebar-content">
				<h2>Add Content with<br />our custom modules.</h2>
				<div class="modules">
				' . $list . '
				</div>
			</div>
		';
	}

	// -----------------------------------------
	// blocks
	// -----------------------------------------

	public static function blocks() {
		return '<div class="sidebar-content">' . Blocks::list() . '</div>';
	}

	// -----------------------------------------
	// settings
	// -----------------------------------------

	public static function settings() {
		// output list
		return '
			<div class="sidebar-content">
				<ul class="sidebar-tabs-nav"></ul>
				<div class="sidebar-active-line"></div>
				<div class="sidebar-gradient"></div>
				<div class="tab-content"></div>
			</div>
		';
	}

	// -----------------------------------------
	// get posts
	// -----------------------------------------

	public static function get_posts($type) {
		// global
		global $post;
		// output
		$output = '';
		// args
		$posts_args = array(
			'sort_order' 		=> 'ASC',
			'post_type' 		=> $type,
			'post_status' 		=> 'publish,private,draft',
			'posts_per_page'   	=> 30,
			'orderby'			=> 'modified',
		);
		$posts = get_posts($posts_args);
		if($posts) {
			foreach($posts as $post) {
				// output list element#
				$title = (empty($post->post_title)) ? 'Untitled' : $post->post_title;					
				$output .= '<li><a data-new-url="#edit/' . $post->ID . '" data-reopen="#edit/' . $post->ID . '" data-exit-mode="re-open" class="click-handler" data-handler="run" data-action-type="dialog" data-setting-type="core" data-action="exitEditor"><span>' . $title . '</span></a></li>';
			}
		}
		// ret
		return $output;
	}

	// -----------------------------------------
	// get featured settings
	// -----------------------------------------

	public static function featured_settings() {
		// output
		$output = '<ul>';
		// settings
		$settings = array(
			'typography'  => 'Typography',
			'grid'		  => 'Grid',
			'navigations' => 'Navigations'
		);
		// iterate settings
		foreach($settings as $setting => $name) {
			$atts = array(
				'type'		=> 'customize',
				'setting' 	=> $setting,
				'name'		=> $name,
				'where'		=> 'editor',
				'active'	=> '',
				'classes'	=> '',
			);
			// add to output
			$output .= Get::customize_nav_item($atts);
		}
		// ret
		return $output . '</ul>';
	}
}
new Sidebar;
?>