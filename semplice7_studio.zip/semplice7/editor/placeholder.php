<?php

// namespace
namespace Semplice\Editor;

// use
use Semplice\Helper\Get;
use Semplice\Helper\Covers;

// -----------------------------------------
// semplice editor placeholder
// -----------------------------------------

class Placeholder {

	// -----------------------------------------
	// get editor styles
	// -----------------------------------------

	public static function get($module, $id, $has_upload, $is_editor, $label) {
		// vars
		$prefix = (!$is_editor) ? 'mp_frontend_' : 'mp_title_';
		$upload_atts = ($is_editor && $has_upload) ? self::upload_atts($module, true) : '';
		$dropzone = ($is_editor && $has_upload) ? ' ml-dropzone' : '';
		$id = ($id) ? $id : '{{id}}';
		// label
		$label = ($label && gettype($label) == 'string') ? '<div class="mp-label">' . $label . '</div>' : '';
		// button
		$button = '';
		if($is_editor && $has_upload) {
			$button = self::upload($module, $id);
		} else if($is_editor) {
			$button = self::button($module, $id);
		}
		// content
		$content = '';
		if($module == 'cover') {
			$content = Covers::presets();
		}
		// return
		return '
			<div class="module-placeholder is-content' . $dropzone . '" data-id="' . $id . '" data-placeholder="' . $module . '"' . $upload_atts . '>
				' . $label . '
				<div class="mp-inner">
					<div class="mp-icon">' . Get::svg('editor', '/modules/' . $module) . '</div>
					<div class="mp-title">' . Get::svg('editor', '/placeholders/' . $module) . '</div>
					' . $content . '
					' . $button . '
				</div>
			</div>
		';
	}

	// -----------------------------------------
	// get upload
	// -----------------------------------------

	public static function upload($module, $id) {
		// upload form
		return '
			<div class="mp-upload">
				<button class="semplice-upload" data-mode="content" data-id="' . $id . '"' . self::upload_atts($module, false) . '><span class="wide">Add from </span>Media Library</button>
			</div>
			<div class="mp-upload-status">
				<div class="mp-upload-icon">' . Get::svg('editor', '/modules/' . $module) . '</div>
				<div class="mp-loader">
					<svg width="40" height="40">
						<circle class="progress-circle" stroke="#ffd300" stroke-width="2" fill="transparent" r="16" cx="20" cy="20" style="stroke-dasharray: 100.53, 100.53; stroke-dashoffset: 101px;"></circle>
					</svg>
				</div>
				<span>0%</span>
				<div class="mp-finish">Processing</div>
			</div>
			<div class="mp-upload-bg"></div>
		';
	}

	// -----------------------------------------
	// get button
	// -----------------------------------------

	public static function button($module, $id) {
		$titles = array(
			'lottie' 		=> 'Upload JSON',
			'oembed' 		=> 'Add Embed',
			'code'	 		=> 'Add Code',
			'blogposts' 	=> 'Edit Settings',
			'youtube' 		=> 'Edit Settings',
			'vimeo' 		=> 'Edit Settings',
			'portfoliogrid' => 'Edit Settings',
			'cover'			=> '<span></span> Or Start From Scratch',
			'singleproject' => 'Edit Settings'
		);
		// is video?
		if($module == 'video') {
			return '<div class="mp-button"><button class="semplice-upload" data-mode="content" data-id="' . $id . '"' . self::upload_atts($module, false) . '><span class="wide">Add from </span>Media Library</button></div>';
		} else if($module == 'advancedportfoliogrid' || $module == 'coverslider') {
			return '<div class="mp-button"><button class="apg-add-content" data-id="' . $id . '">Add Pages &amp; Projects</button></div>';
		} else if($module == 'subrow') {
			return '<div class="mp-subrow">' . Get::svg('editor', 'placeholders/subrow-plus') . '</div>';
		} else if($module == 'code') {
			return '<div class="mp-button"><button data-name="code" data-type="content" class="edit-code" data-code-id="module" data-id="' . $id . '" data-module="code" data-unique-name="code">Edit Code</button></div>';
		} else if($module) {
			return '<div class="mp-button"><button data-mode="content">' . $titles[$module] . '</button></div>';
		}
	}

	// -----------------------------------------
	// get upload atts
	// -----------------------------------------

	public static function upload_atts($module, $is_dropzone) {
		// basic upload atts
		$atts = array(
			'data-input-type'	   => 'upload',
			'data-upload'		   => 'content' . ucfirst($module),
			'data-upload-type' 	   => self::media_type($module),
			'data-upload-dropzone' => 'mp',
			'data-module'		   => $module,
		);
		// has dropzone?
		if($is_dropzone) {
			$atts['data-upload-dropzone'] = 'mp';
		}
		// gallery vs image
		if($module == 'gallery' || $module == 'gallerygrid') {
			$atts['name'] = 'images';
		} else if($module == 'image') {
			$atts['name'] = 'image';
			$atts['data-upload'] = 'contentImage';
		}
		// iterate upload atts
		$output = '';
		foreach ($atts as $name => $value) {
			$output .= ' ' . $name . '="' . $value . '"';
		}
		// return
		return $output;
	}

	// -----------------------------------------
	// get media type
	// -----------------------------------------

	public static function media_type($module) {
		$type = array(
			'image' 		=> 'image',
			'gallery' 		=> 'gallery',
			'gallerygrid' 	=> 'gallery',
			'video'			=> 'video',
			'oembed'		=> '',
			'youtube'		=> '',
			'vimeo'			=> '',
			'portfoliogrid' => '',
			'singleproject' => '',
			'dribbble'		=> '',
			'instagram'		=> '',
			'code'			=> '',
			'beforeafter'	=> '',
			'lottie'		=> '',
			'blogposts'		=> '',
			'marquee'		=> ''
		);
		return $type[$module];
	}
}
new Placeholder;
?>