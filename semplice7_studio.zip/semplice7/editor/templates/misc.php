<?php
	use Semplice\Editor;
	use Semplice\Editor\Placeholder;
	use Semplice\Helper\Get;
	use Semplice\Helper\Covers;
	use Semplice\Helper\PostQueries;
	$uri = SEMPLICE_URI;
?>
<template id="smp-tpl-empty-editor">
	<div id="empty-editor">
		<div class="content">
			<div class="svg-title"><?php echo Get::svg('editor', 'empty-editor'); ?></div>
			<div class="semplice-template">
				<div class="select-template-wrapper">
					<option-input>
						<select class="select-template"></select>
					</option-input>
				</div>
			</div>
			<div class="lottie-empty-editor"></div>
		</div>
		<div class="help-videos">
			<a href="https://www.semplice.com/videos" target="_blank">Video tutorials</a>
		</div>
	</div>
</template>

<template id="smp-tpl-empty-subrow">
	<?php echo Placeholder::get('subrow', false, false, true, false); ?>
</template>

<template id="smp-tpl-revisions-list-item">
	<li id="{{id}}" class="revision-list-item" data-active="{{active}}" data-published="{{published}}">
		<span class="circle"></span>
		<a class="load click-handler" data-handler="run" data-action-type="revisions" data-action="load" data-id="{{id}}">{{title}}</a>
		<div class="revision-options">
			<button class="rename click-handler" data-handler="run" data-action-type="dialog" data-action="rename" data-setting-type="revisions" data-id="{{id}}"></button>
			<button class="remove click-handler" data-handler="run" data-action-type="dialog" data-action="delete" data-setting-type="revisions" data-id="{{id}}"></button>
		</div>
	</li>
</template>

<template id="smp-tpl-published-notice">
	<div class="published-notice">
		<div class="icon">
			<?php echo Get::svg('editor', 'versions/success'); ?>
		</div>
		<p>Your <span class="post-type">{{type}}</span> has been<br />published.</p>
		<div class="button-wrapper">
			<a href="{{url}}" target="_blank">See it Live</a>
		</div>
	</div>
</template>

<template id="smp-tpl-blocks-category">
	<ul class="blocks-category{{emptyClass}}" data-blocks-category-id="{{id}}" data-display="expanded">
		<div class="blocks-category-handle"></div>
		<div class="blocks-category-display"></div>
		<p class="blocks-head-small blocks-head-first blocks-category-name" contenteditable="true">{{name}}</p>
		<div class="empty-state">This category is empty. <a class="click-handler" data-handler="run" data-action="removeCategory" data-action-type="blocks">Remove</a></div>
	</ul>
</template>

<template id="smp-tpl-embed-thumbnail">
	<div class="smp-{{type}} is-content">
		<img src="{{url}}">
	</div>
</template>

<template id="smp-tpl-share-buttons">
	<?php echo Editor::$modules['share']->html(0, 'buttons', 'visible'); ?>
</template>

<template id="smp-tpl-apg-missing-thumb">
	<div class="missing-thumbnail">
		<p>Missing thumbnail for<br />"{{postTitle}}"</p>
		<button class="apg-thumb-upload no-ep click-handler" data-handler="run" data-action-type="mediaLibrary" data-action="init" data-type="upload" data-upload="apg" data-input-type="upload" data-sub-type="inline" data-upload-type="image" data-video-support="false" data-id="{{contentId}}" data-post-id="{{postId}}" data-thumb-id="0">Upload Thumbnail</button>
	</div>
</template>

<template id="smp-tpl-apg-presets">
	<div class="apg-presets">
		<ul class="content apg-presets-content">
			<li class="apg-load-preset" data-preset="horizontal-fullscreen" data-content-id="{{id}}">
				<div class="apg-inner">
					<img alt="horizontal-fullscreen" class="preset-img" src="<?php echo $uri . '/assets/images/editor/sidebar/modules/apg_horizontal-fullscreen.svg'; ?>">
					<div class="title"><p>Column Grid</p></div>
				</div>
			</li>
			<li class="apg-load-preset" data-preset="text" data-content-id="{{id}}">
				<div class="apg-inner">
					<img alt="text-grid" class="preset-img" src="<?php echo $uri . '/assets/images/editor/sidebar/modules/apg_text.svg'; ?>">
					<div class="title"><p>Text Grid</p></div>
				</div>
			</li>
			<li class="apg-load-preset" data-preset="splitscreen" data-content-id="{{id}}">
				<div class="apg-inner">
					<img alt="splitscreen-grid" class="preset-img" src="<?php echo $uri . '/assets/images/editor/sidebar/modules/apg_splitscreen.svg'; ?>">
					<div class="title"><p>Splitscreen</p></div>
				</div>
			</li>
			<li class="apg-load-preset" data-preset="table" data-content-id="{{id}}">
				<div class="apg-inner">
					<img alt="table-grid" class="preset-img" src="<?php echo $uri . '/assets/images/editor/sidebar/modules/apg_table.svg'; ?>">
					<div class="title"><p>Table Grid</p></div>
				</div>
			</li>
		</ul>
	</div>
</template>

<template id="smp-tpl-default-cover">
	<?php echo Covers::default('visible'); ?>
		</smp-container>
	</smp-section>
</template>

<template id="smp-tpl-default-cover-hidden">
	<?php echo Covers::default('hidden'); ?>
		</smp-container>
	</smp-section>
</template>

<template id="smp-tpl-last-edited">
	<div id="last-edited">
		<div class="close-last-edited"><?php echo Get::svg('admin', 'close'); ?></div>
		<a href="#edit/{{postId}}">
			<div class="inner">
				<h5>Last Edited Post</h5>
				<h4>{{postTitle}}</h4>
			</div>
		</a>
	</a>
</template>

<template id="smp-tpl-blog-export">
	<a class="blog-import-export"></a><div class="blog-export"><h5>Export & Import Settings</h5><a class="blog-export-settings" data-type="export" data-id="{{id}}">Copy to clipboard</a><a class="blog-export-settings" data-type="import" data-id="{{id}}">Paste from clipboard</a></div>
</template>