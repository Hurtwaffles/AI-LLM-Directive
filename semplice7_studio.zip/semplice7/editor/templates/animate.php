<?php 
	use Semplice\Helper\Get;
?>
<template id="smp-tpl-animate-onboarding">
	<div class="create-animations">
		<p class="head">Element Trigger</p>
		<p class="desc">Please select which element trigger<br />should start your animation.</p>
		<ul>
			<li class="click-handler" data-handler="run" data-action-type="animation" data-action="add" data-id="{{id}}" data-event="on_load"><?php echo Get::svg('editor', 'animate/appear'); ?><p>On Appear</p></li>
			<li class="click-handler" data-handler="run" data-action-type="animation" data-action="add" data-id="{{id}}" data-event="on_hover"><?php echo Get::svg('editor', 'animate/hover'); ?><p>Mouseover</p></li>
			<li class="click-handler" data-handler="run" data-action-type="animation" data-action="add" data-id="{{id}}" data-event="on_click"><?php echo Get::svg('editor', 'animate/click'); ?><p>Click (tap)</p></li>
			<li class="click-handler" data-handler="run" data-action-type="animation" data-action="add" data-id="{{id}}" data-event="on_scroll"><?php echo Get::svg('editor', 'animate/onscroll'); ?><p>On Scroll</p></li>
		</ul>
		<div class="animation-trigger-help"></div>
	</div>
</template>

<template id="smp-tpl-animate-onboarding-intro">
	<div class="create-animations">
		<p class="head">Element Trigger</p>
		<p class="desc">Since all intro animations are getting played<br />on load this is the only event trigger.</p>
		<ul class="intro-events">
			<li class="click-handler" data-handler="run" data-action-type="animation" data-action="add" data-id="{{id}}" data-event="on_intro"><?php echo Get::svg('editor', 'animate/intro'); ?><p>On Load</p></li>
		</ul>
		<div class="animation-trigger-help"></div>
	</div>
</template>

<template id="smp-tpl-timeline-initial">
	<li class="animate-step expand-options admin-click-handler" data-expand-options="animate" data-timeline-step="initial" data-mode="initial" data-id="{{id}}"{{module}}>
		<div class="duration">0.0s</div>
		<p>Initial State</p>
	</li>
	<li class="add-step-between click-handler{{addAfterInitial}}" data-handler="run" data-expand-options="animate" data-action-type="animation" data-action="addStep" data-timeline-step="initial" data-id="{{id}}" data-module="{{module}}" data-mode="{{mode}}">+</li>
</template>

<template id="smp-tpl-timeline-step">
	<li class="animate-step expand-options" data-expand-options="animate" data-ep-timeline-step="{{step}}" data-timeline-step="{{step}}" data-mode="{{mode}}" data-id="{{id}}"{{module}}>
		<div class="duration duration-step">{{durationTotal}}s</div>
		<p>{{label}}</p>
		<a class="delete-step click-handler" data-handler="run" data-action-type="animation" data-action="deleteStep" data-timeline-step="{{step}}" data-id="{{id}}"><?php echo Get::svg('admin', 'delete'); ?></a>
	</li>
	<li class="add-step-between click-handler{{addBetween}}" data-handler="run"  data-expand-options="animate" data-action-type="animation" data-action="addStep" data-timeline-step="{{step}}" data-id="{{id}}" data-module="{{module}}" data-mode="{{mode}}">+</li>
</template>

<template id="smp-tpl-timeline-add-step">
	<li class="animate-step">
		<a class="add-animate-step click-handler" data-handler="run" data-action-type="animation" data-action="addStep" data-timeline-step="{{count}}" data-mode="{{mode}}" data-id="{{id}}"{{module}}><?php echo Get::svg('editor', 'animate/add-step'); ?></a>
	</li>
</template>

<!-- list animate presets -->
<template id="smp-tpl-animate-presets">
<div class="animate-presets-list" data-active-list="premade">
	<div class="apl-nav">
		<option-input data-size="4" data-var-support="true">
			<div class="toggle-button" data-size="2">
				<div class="toggle-state"></div>
				<ul>
					<li class="selected">
						<button class="toggle-option preset-type" data-input-type="toggleButton" data-val="premade" data-inline="true">Premade</button>
					</li>
					<li>
						<button class="toggle-option preset-type" data-input-type="toggleButton" data-val="custom" data-inline="true">Custom</button>
					</li>
				</ul>
			</div>
		</option-input>
	</div>
	<ul class="premade">{{premade}}</ul>
	<ul class="custom ep-ap-list">{{custom}}</ul>
</div>
</template>

<template id="smp-tpl-animate-presets-empty">
	<div class="apl-empty">
		<div class="apl-empty-inner">
			<div class="head-image"></div>
			<p class="apl-empty-head">Custom Presets</p>
			<p>You haven't created any custom presets yet. Use the + icon below to save a custom preset after finishing your animation.</p>
		</div>
	</div>
</template>

<template id="smp-tpl-animate-effects">
	<div class="animate-effects-list">
		<div class="ael-inner">
			<div class="ael-head">Add Effect</div>
			<button class="close-ael click-handler" data-handler="run" data-action-type="animateEffects" data-action="hideDropdown"><?php echo Get::svg('admin', 'close'); ?></button>
			<ul>
				<li class="title">Transform</li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="move" data-id="{{id}}" data-step="{{step}}">Move</a></li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="scale" data-id="{{id}}" data-step="{{step}}">Scale</a></li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="rotate" data-id="{{id}}" data-step="{{step}}">Rotate</a></li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="skew" data-id="{{id}}" data-step="{{step}}">Skew</a></li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="rotate3d" data-id="{{id}}" data-step="{{step}}">3D Rotate</a></li>
				<li class="title">Filter</li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="filter_blur" data-id="{{id}}" data-step="{{step}}">Blur</a></li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="filter_brightness" data-id="{{id}}" data-step="{{step}}">Brightness</a></li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="filter_contrast" data-id="{{id}}" data-step="{{step}}">Contrast</a></li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="filter_grayscale" data-id="{{id}}" data-step="{{step}}">Grayscale</a></li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="filter_hue-rotate" data-id="{{id}}" data-step="{{step}}">Hue-Rotate</a></li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="filter_invert" data-id="{{id}}" data-step="{{step}}">Invert</a></li>	
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="filter_saturate" data-id="{{id}}" data-step="{{step}}">Saturate</a></li>				
			</ul>
			<ul>
				<li class="title">Styling</li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="opacity" data-id="{{id}}" data-step="{{step}}">Opacity</a></li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="color" data-id="{{id}}" data-step="{{step}}">Text Color</a></li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="border" data-id="{{id}}" data-step="{{step}}">Border &amp; Radius</a></li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="background-color" data-id="{{id}}" data-step="{{step}}">Background Color</a></li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="box-shadow" data-id="{{id}}" data-step="{{step}}">Drop Shadow</a></li>
				<li class="empty-effect"><a>&nbsp;</a></li>
				<li class="title">Misc</li>
				<li><a class="click-handler" data-handler="run" data-action-type="animateEffects" data-action="add" data-effect="reveal" data-id="{{id}}" data-step="{{step}}">Reveal</a></li>
			</ul>
		</div>
	</div>
	<button class="add-effect click-handler" data-handler="run" data-action-type="animateEffects" data-action="showDropdown" data-step="{{step}}" data-button-color="bright-gray">Add Effect</button>
	<div class="animate-effects-empty">
		<p>You have not yet added any effects.<br />Added effects will be listed here.</p>
	</div>
</template>