<?php 
	use Semplice\Helper\Get;
?>
<template id="smp-tpl-dropdown-breakpoints">
	<?php echo Get::bp_select('editor'); ?>
</template>

<template id="smp-tpl-dropdown-publish">
	<div class="semplice-dropdown dropdown-publish">
		<div class="status">
			<h3>Status<span class="{{status}}">{{statusLabel}}</span></h3>
		</div>
		<div class="password-protected">
			<option-input data-state="{{ppState}}">
				<label>Post password</label>
				<div class="toggle toggle-password-protected toggle-small" data-state="{{ppState}}" data-on="on" data-off="off"><div class="circle"></div></div>
				<input type="text" data-type="postPassword" name="post-password" value="{{password}}">
			</option-input>
		</div>
		<div class="buttons" data-status="{{status}}">
			<button class="click-handler draft" data-handler="savePost" data-mode="draft" data-change-status="yes" data-exit="no">Switch to draft</button>
			<button class="click-handler publish" data-handler="savePost" data-mode="publish" data-change-status="no" data-exit="no">{{publishButton}}</button>
		</div>
	</div>
</template>

<template id="smp-tpl-dropdown-cover">
	<div class="semplice-dropdown dropdown-cover">
		<div class="cover-options" data-cover-visibility="{{val}}">
			<option-input class="full-width-toggle" data-size="4" data-var-support="false">
				<label>Enable Cover</label>
				<div class="toggle toggle-small cover-toggle" data-name="cover_visibility" data-input-type="toggle" data-default="hidden" data-on="visible" data-off="hidden" data-val="{{val}}" data-state="{{state}}">
					<div class="circle"></div>
				</div>
			</option-input>
			<option-input data-size="4" class="cover-sub-option">
				<label>Import Existing Cover</label>
				<div class="select-wrapper">
					<select data-name="import-cover" class="import-cover">
						<option>Select Page or Project</option>
						{{covers}}
					</select>
				</div>
			</option-input>
			<div class="reset-button cover-sub-option">
				<button class="reset-cover" data-button-color="red">Reset Cover</button>
			</div>
		</div>
	</div>
</template>

<template id="smp-tpl-dropdown-revisions">
	<div class="semplice-dropdown dropdown-revisions">
		<h3>Versions</h3>
		<ul class="revisions-list" data-status="{{status}}">{{list}}</ul>
		<div class="button-wrapper">
			<button class="click-handler" data-handler="run" data-action-type="dialog" data-action="add" data-setting-type="revisions">Add Version</a>
		</div>
	</div>
</template>

<template id="smp-tpl-dropdown-branding">
	<div class="semplice-dropdown dropdown-branding{{customClass}}">
		<h3>Page Background</h3>
		<div class="branding-picker-holder"></div>
		<div class="branding-options">{{options}}</div>
	</div>
</template>

<template id="smp-tpl-dropdown-animate">
	<div class="semplice-dropdown dropdown-animate">
		<div class="animate-options">
			<option-input data-size="4">
				<label>Preset Type</label>
				<div class="toggle-button bulk-apply-type" data-size="2">
					<div class="toggle-state"></div>
					<ul>
						<li class="selected">
							<button class="toggle-option preset-type-bulk" data-input-type="toggleButton" data-val="premade" data-inline="true">Premade</button>
						</li>
						<li>
							<button class="toggle-option preset-type-bulk" data-input-type="toggleButton" data-val="custom" data-inline="true">Custom</button>
						</li>
					</ul>
				</div>
			</option-input>
			<option-input data-size="4">
				<label>Element trigger</label>
				<div class="select-wrapper">
					<select class="bulk-apply-trigger">
						<option value="on_load" selected="">When in view</option>
						<option value="on_hover">Mouseover</option>
						<option value="on_click">Click (Tap)</option>
						<option value="on_scroll">Scrolling in view</option>
					</select>
				</div>
			</option-input>
			<option-input data-size="4">
				<label>Preset</label>
				<div class="select-wrapper">
					<select class="bulk-apply-dropdown">
					</select>
				</div>
			</option-input>
			<option-input data-size="4">
				<label>Apply to</label>
				<div class="select-wrapper">
					<select class="bulk-apply-content-type">
						<option value="section" selected="">Section</option>
						<option value="column">Column</option>
						<option value="content">Content</option>
						<option value="text">Text module</option>
						<option value="paragraph">Paragraph module</option>
						<option value="image">Image module</option>
						<option value="video">Video module</option>
						<option value="button">Button module</option>
					</select>
				</div>
			</option-input>
			<div class="bulk-apply-presets">
				<button class="click-handler" data-handler="run" data-action-type="dialog" data-setting-type="animate" data-action="bulkApply" data-button-color="yellow">Apply Presets</button>
			</div>
		</div>
	</div>
</template>