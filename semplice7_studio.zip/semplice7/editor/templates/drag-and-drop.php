<template id="smp-tpl-section-dropzone">
	<div class="section-dropzone">
		<div class="inner">Add Section</div>
	</div>
</template>

<template id="smp-tpl-row-dropzone">
	<div class="row-dropzone">
		<smp-container>
			<div class="grid-row">
				<div data-xl-width="12">
					<div class="inner">Add Row</div>
				</div>
			</div>
		</smp-container>
	</div>
</template>

<template id="smp-tpl-column-dropzone">
	<div class="column-dropzone" style="left: {{offset}}px">
		<div class="inner"></div>
	</div>
</template>

<template id="smp-tpl-section">
	<smp-section id="{{sectionId}}" class="{{classes}}" data-column-mode-xs="single" data-column-mode-sm="single">
		<smp-container>
			<smp-row id="{{rowId}}">
				<smp-column id="{{columnId}}" data-xl-width="12">
					<div class="move-column"></div>
					<smp-content-wrapper>
						{{content}}
					</smp-content-wrapper>
				</smp-column>
			</smp-row>
		</smp-container>
	</smp-section>
</template>

<template id="smp-tpl-row">
	<smp-row id="{{rowId}}">
		<smp-column id="{{columnId}}" data-xl-width="12">
			<div class="move-column"></div>
			<smp-content-wrapper>
				{{content}}
			</smp-content-wrapper>
		</smp-column>
	</smp-row>
</template>

<template id="smp-tpl-column">
	<smp-column id="{{columnId}}" data-xl-width="12">
		<div class="move-column"></div>
		<smp-content-wrapper>
			{{content}}
		</smp-content-wrapper>
	</smp-column>
</template>

<template id="smp-tpl-content">
	{{content}}
</template>

<template id="smp-tpl-subrow">
	{{content}}
</template>