<?php
	
	// namespace
	namespace Semplice\Editor;

	// use
	use Semplice\Editor;
	use Semplice\Helper\Get;
	use Semplice\Editor\Placeholder;

	// -----------------------------------------
	// Module templates
	// -----------------------------------------

	class ModuleTemplates {

		// -----------------------------------------
		// constructor
		// -----------------------------------------

		public function __construct() {
			// output
			$output = '';
			// modules
			$modules = array(
				'paragraph' 			=> 'text',
				'text'					=> 'text',
				'fluidtext' 			=> 'text',
				'share'					=> 'share',
				'image'					=> 'placeholder_upload',
				'video'					=> 'placeholder',
				'gallery'				=> 'placeholder_upload',
				'oembed'				=> 'placeholder',
				'youtube'				=> 'placeholder',
				'vimeo'					=> 'placeholder',
				'code'					=> 'placeholder',
				'lottie'				=> 'lottie',
				'blogposts'				=> 'empty',
				'blogarchives'			=> 'blogarchives',
				'blogsearch'			=> 'blogsearch',
				'blogcomments'			=> 'blogcomments',
				'button'				=> 'button',
				'portfoliogrid'			=> 'empty',
				'singleproject'			=> 'empty',
				'socialprofiles'		=> 'socialprofiles',
				'marquee'				=> 'marquee',
				'accordion'				=> 'empty',
				'advancedportfoliogrid' => 'empty',
				'spacer'				=> 'spacer'
			);
			// studio modules
			if(SEMPLICE_EDITION == 'studio') {
				$modules['beforeafter'] = 'beforeafter';
				$modules['gallerygrid'] = 'placeholder_upload';
				$modules['mailchimp'] = 'mailchimp';
			}
			// iterate modules
			foreach($modules as $module => $function) {
				$output .= '<template id="smp-tpl-module-' . $module . '">' . $this->{$function}($module) . '</template>';
			}
			// output
			echo $output;
		}

		// -----------------------------------------
		// text modules
		// -----------------------------------------

		public function text($module) {
			return '<div class="is-content wysiwyg-editor wysiwyg-edit" data-wysiwyg-id="{{id}}" contenteditable="false"><p>Hey there, this is the default text for a new paragraph. Feel free to edit this paragraph by double clicking on it. After you are done just click on the yellow checkmark button on the top right to save. Have Fun!</p></div>';
		}

		// -----------------------------------------
		// share module
		// -----------------------------------------

		public function share($module) {
			return Editor::$modules['share']->html(0, 'icons', 'visible');
		}

		// -----------------------------------------
		// mailchimp
		// -----------------------------------------

		public function mailchimp($module) {
			return '
				<div class="mailchimp-newsletter">
					<div class="mailchimp-inner is-content">
						<form action="" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate">
							<input type="text" value="" name="FNAME" id="mce-FNAME" class="mailchimp-input" size="16" placeholder="First Name" data-font-size="18px">
							<input type="email" value="" name="EMAIL" id="mce-EMAIL" class="mailchimp-input" size="16" placeholder="E-Mail Address">
							<button class="mailchimp-submit-button" type="submit"  value="Subscribe" name="subscribe" id="mc-embedded-subscribe">Subscribe</button>
						</form>
					</div>
				</div>
			';
		}

		// -----------------------------------------
		// before after
		// -----------------------------------------

		public function beforeafter($module) {
			$beforeafter = Editor::$modules['beforeafter']->editor(0, array('options' => array()));
			return $beforeafter['html'];
		}

		// -----------------------------------------
		// blogarchives
		// -----------------------------------------

		public function blogarchives($module) {
			$blogarchives = Editor::$modules['blogarchives']->editor(0, array('options' => array()));
			return $blogarchives['html'];
		}

		// -----------------------------------------
		// blogsearch
		// -----------------------------------------

		public function blogsearch($module) {
			return Editor::$modules['blogsearch']->form('inter_regular', 'Search posts');
		}

		// -----------------------------------------
		// blogcomments
		// -----------------------------------------

		public function blogcomments($module) {
			return '<div class="is-content"><div class="blogposts-comments">' . Editor::$modules['blogcomments']->customize_html(array()) . '</div></div>';
		}

		// -----------------------------------------
		// button
		// -----------------------------------------

		public function button($module) {
			return '
				<div class="smp-button">
					<div class="is-content" data-effect="colorfade">
						<a data-font="inter_medium">Semplice Button</a>
					</div>
				</div>
			';
		}

		// -----------------------------------------
		// social profiles
		// -----------------------------------------

		public function socialprofiles($module) {
			return '
				<div class="socialprofiles is-content" data-align="center">
					<div class="inner">
						<ul>
							<li class="social-profile social-profile-facebook"><a href="https://www.facebook.com/semplicelabs" target="_blank">' . Get::svg('frontend', 'networks/facebook') . '</a></li>
							<li class="social-profile social-profile-twitter"><a href="https://www.twitter.com/semplicelabs" target="_blank">' . Get::svg('frontend', 'networks/x') . '</a></li>
							<li class="social-profile social-profile-vimeo"><a href="https://vimeo.com/semplicelabs" target="_blank">' . Get::svg('frontend', 'networks/vimeo') . '</a></li>
						</ul>
					</div>
				</div>
			';
		}

		// -----------------------------------------
		// marquee
		// -----------------------------------------

		public function marquee($module) {
			return '
				<div class="is-content semplice-marquee">
					<div class="semplice-marquee-inner" data-direction="ltr" data-font="inter_semibold">
						<span class="semplice-marquee-content semplice-marquee-text">SEMPLICE MARQUEE &mdash; CLICK TO EDIT ME</span>
						<span class="semplice-marquee-content semplice-marquee-text">SEMPLICE MARQUEE &mdash; CLICK TO EDIT ME</span>
						<span class="semplice-marquee-content semplice-marquee-text">SEMPLICE MARQUEE &mdash; CLICK TO EDIT ME</span>
					</div>
				</div>
			';
		}

		// -----------------------------------------
		// spacer
		// -----------------------------------------

		public function spacer($module) {
			return '
				<div class="spacer-container">
					<div class="is-content">
						<div class="spacer"><!-- horizontal spacer --></div>
					</div>
				</div>
			';
		}

		// -----------------------------------------
		// lottie
		// -----------------------------------------

		public function lottie($module) {
			return '<div class="is-content semplice-lottie"><div id="{{id}}_lottie" class="lottie-holder"></div></div>' . Placeholder::get($module, false, false, true, false);
		}

		// -----------------------------------------
		// placeholder
		// -----------------------------------------

		public function placeholder($module) {
			// return placeholder
			return Placeholder::get($module, false, false, true, false);
		}

		// -----------------------------------------
		// placeholder upload
		// -----------------------------------------

		public function placeholder_upload($module) {
			return Placeholder::get($module, false, true, true, false);
		}

		// -----------------------------------------
		// empty
		// -----------------------------------------

		public function empty($module) {
			return '';
		}
	}
	new ModuleTemplates;
?>
