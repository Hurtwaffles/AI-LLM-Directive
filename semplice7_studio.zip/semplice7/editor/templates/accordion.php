<template id="smp-tpl-accordion-item">
	<div class="accordion-item" data-accordion-id="{{accordionId}}">
		<div class="title" data-font="inter_bold">
			<div class="title-span" contenteditable="true" data-accordion-editable="editable" data-name="title"><span>{{title}}</span></div>
			<div class="icon">
				<span class="expand">{{iconExpand}}</span>
				<span class="collapse">{{iconCollapse}}</span>
			</div>
		</div>
		<div class="description">
			<div class="description-inner" data-font="inter_light">
				<div id="{{contentId}}" class="accordion-text accordion-content">{{description}}</div>
			</div>
		</div>
		<div class="actions">
			<a class="accordion-add-element"></a>
			<a class="accordion-remove click-handler" data-handler="run" data-action-type="accordion" data-action="remove" data-id="{{id}}" data-remove-id="{{accordionId}}"></a>
			<a class="accordion-handle ui-sortable-handle"></a>
			<ul>
				<li><a class="click-handler" data-handler="run" data-action-type="accordion" data-action="addContent" data-content="text" data-item-id="{{accordionId}}">Text</a></li>
				<li><a class="semplice-upload" data-id="{{id}}" data-item-id="{{accordionId}}" data-upload-type="image" data-name="accordion-image" data-upload="accordionImage" data-video-support="false" data-has-unsplash="false">Image</a></li>
			</ul>
		</div>
	</div>
</template>
<template id="smp-tpl-accordion-content-actions">
	<ul class="accordion-content-actions">
		<li><a class="accordion-content-handle"></a></li>
		{{customActions}}
		<li><a class="click-handler" data-handler="run" data-action-type="accordion" data-action="contentRemove" data-content-action="remove"></a></li>
	</ul>
</template>
<template id="smp-tpl-accordion-image-settings">
	<div class="accordion-image-settings">
		<div class="ais-option">
			<div class="ais-title">Width</div>
			<div class="ais-select">
				<div class="ais-select-arrow"></div>
				<select name="ais-width" data-id="{{id}}">
					<option value="original">Original</option>
					<option value="grid">Grid</option>
				</select>
			</div>
		</div>
		<div class="ais-option">
			<div class="ais-title">Align</div>
			<div class="ais-select">
				<div class="ais-select-arrow"></div>
				<select name="ais-align" data-id="{{id}}">
					<option value="left">Left</option>
					<option value="center">Center</option>
					<option value="right">Right</option>
				</select>
			</div>
		</div>
		<div class="ais-option">
			<div class="ais-title">Link</div>
			<div class="ais-input">
				<input name="ais-link" type="text" data-id="{{id}}">
			</div>
		</div>
		<div class="ais-option">
			<div class="ais-title">Target</div>
			<div class="ais-select">
				<div class="ais-select-arrow"></div>
				<select name="ais-target" data-id="{{id}}">
					<option value="_self">Same tab</option>
					<option value="_blank">New tab</option>
				</select>
			</div>
		</div>
	</div>
</template>