<?php 
	use Semplice\Helper\Get;
?>
<template id="smp-tpl-wysiwyg-toolbar">
	<div class="wysiwyg-actions">
		<div class="wysiwyg-bp-notice"><div class="bp-icon"></div><div class="text">Format Sizings for Mobile</div></div>
		<div class="wysiwyg-formats custom-select" data-status="collapsed">
			<div class="cs-selected cs-selected-format"><span>Paragraph</span></div>
			<ul>
				<li class="wysiwyg-action" data-action="format" data-format="paragraph">Paragraph</li>
				<li class="wysiwyg-action" data-action="format" data-format="h1">Heading 1</li>
				<li class="wysiwyg-action" data-action="format" data-format="h2">Heading 2</li>
				<li class="wysiwyg-action" data-action="format" data-format="h3">Heading 3</li>
				<li class="wysiwyg-action" data-action="format" data-format="h4">Heading 4</li>
				<li class="wysiwyg-action" data-action="format" data-format="h5">Heading 5</li>
				<li class="wysiwyg-action" data-action="format" data-format="h6">Heading 6</li>
			</ul>
		</div>
		<button class="wysiwyg-action has-icon" data-action="Underline"><?php echo Get::svg('editor', 'tinymce/underline'); ?></button>
		<button class="wysiwyg-action has-icon" data-action="Strikethrough"><?php echo Get::svg('editor', 'tinymce/strikethrough'); ?></button>
		<button class="wysiwyg-action has-icon" data-action="Removeformat"><?php echo Get::svg('editor', 'tinymce/removeformat'); ?></button>
		<div class="wysiwyg-spacer"></div>
		<button class="wysiwyg-action has-icon non-fluid" data-action="InsertOrderedList"><?php echo Get::svg('editor', 'tinymce/orderedlist'); ?></button>
		<button class="wysiwyg-action has-icon non-fluid" data-action="InsertUnorderedList"><?php echo Get::svg('editor', 'tinymce/unorderedlist'); ?></button>
		<div class="wysiwyg-spacer non-fluid"></div>
		<div class="wysiwyg-justify custom-select" data-status="collapsed"><!-- holder for justfiy controls --></div>
		<button class="wysiwyg-action has-icon" data-action="mceLink"><?php echo Get::svg('editor', 'tinymce/link'); ?></button>
		<button class="wysiwyg-action has-icon non-fluid" data-action="editSource"><?php echo Get::svg('editor', 'tinymce/source'); ?></button>
		<div class="wysiwyg-spacer"></div>
		<div class="wysiwyg-font-select custom-select" data-status="collapsed"><div class="cs-selected cs-selected-font"><span>Font family</span></div><ul></ul></div>
		<div class="wysiwyg-typography"><!-- holder for typography controls --></div>
		<div class="color-picker tinymce-picker" data-holder="tinymce">
			<div class="color-preview"></div>
			<input type="text" value="#00000000" data-input-type="color" data-type="wysiwyg" data-sub-type="color" data-name="tinymce-color" data-picker="tinymce" data-unit="false" data-unique-name="tinymce-color" data-gradient="true">
		</div>
		<div class="tinymce-picker-holder"></div>
	</div>
	<div class="wysiwyg-save">
		<button class="wysiwyg-action" data-action="save" data-id="{{id}}" data-module="{{module}}">Done</button>
	</div>
	<div class="fluidtext-resize">
		<input type="range" min="1" max="100" value="100" step=".1" class="fluidtext-resize-slider" data-content-id="{{id}}">
		<div class="slider-breakpoints">
			<div class="xl"></div>
			<div class="lg"></div>
			<div class="md"></div>
			<div class="sm"></div>
		</div>
		<div class="fluidtext-slider-values">
			<div class="ft-resize-width">
				Width: <span class="ft-vp-width"></span>
			</div>
			<div class="ft-resize-fontsize">
				Font Size: <span class="ft-font-size"></span>
			</div>
		</div>
	</div>
</template>
<template id="smp-tpl-wysiwyg-justify">
	<div class="cs-selected cs-selected-alignment"><?php echo Get::svg('editor', 'tinymce/align-left'); ?></div>
	<ul>
		<li><button class="wysiwyg-action has-icon" data-action="JustifyLeft"><?php echo Get::svg('editor', 'tinymce/align-left'); ?></button></li>
		<li><button class="wysiwyg-action has-icon" data-action="JustifyCenter"><?php echo Get::svg('editor', 'tinymce/align-center'); ?></button></li>
		<li><button class="wysiwyg-action has-icon" data-action="JustifyRight"><?php echo Get::svg('editor', 'tinymce/align-right'); ?></button></li>
		<li><button class="wysiwyg-action has-icon" data-action="JustifyFull"><?php echo Get::svg('editor', 'tinymce/align-justify'); ?></button></li>
	</ul>
</template>
<template id="smp-tpl-wysiwyg-toolbar-bp">
	<div class="wysiwyg-actions toolbar-bp">
		<div class="wysiwyg-bp-notice"><div class="bp-icon"></div><div class="text">Format Sizings for {{bp}}</div></div>
		<div class="wysiwyg-justify custom-select" data-status="collapsed"><!-- holder for justfiy controls --></div>
		<div class="wysiwyg-typography"><!-- holder for typography controls --></div>
	</div>
	<div class="wysiwyg-save">
		<button class="wysiwyg-action" data-action="save" data-id="{{id}}" data-module="{{module}}">Done</button>
	</div>
</template>
<template id="smp-tpl-wysiwyg-typography">
	<div class="wysiwyg-input tinymce-font-size"><input type="number" class="tinymce-slider" value="18" data-input-type="rangeSlider" min="6" max="9999" data-type="wysiwyg" name="fontsize_semplice" data-negative="false"></div>
	<div class="wysiwyg-input tinymce-line-height"><input type="number" class="tinymce-slider" value="32" data-input-type="rangeSlider" min="6" max="9999" data-type="wysiwyg" name="lineheight_semplice" data-negative="false"></div>
	<div class="wysiwyg-input tinymce-letter-spacing"><input type="number" class="tinymce-slider" value="0" data-input-type="rangeSlider" min="0" max="9999" data-type="wysiwyg" name="letterspacing_semplice" data-negative="true"></div>
</template>
<template id="smp-tpl-wysiwyg-typography-fluid">
	<div class="wysiwyg-input tinymce-line-height"><input type="number" value="100" data-input-type="rangeSlider" min="1" max="1000" data-type="wysiwyg" data-sub-type="fluid" name="fluid-line-height" data-negative="false" data-id="{{id}}"></div>
	<div class="wysiwyg-input tinymce-letter-spacing"><input type="number" value="0" data-input-type="rangeSlider" min="0" max="9999" data-type="wysiwyg" data-sub-type="fluid" name="fluid-letter-spacing" data-negative="true" data-divider="10" data-id="{{id}}"></div>
	<div class="wysiwyg-text">Font Size</div>
	<div class="wysiwyg-input wysiwyg-fluid-min"><input type="number" value="18" data-input-type="rangeSlider" min="6" max="999" data-type="wysiwyg" data-sub-type="fluid" name="min-font-size" data-id="{{id}}"></div>
	<div class="wysiwyg-input wysiwyg-fluid-max"><input type="number" value="72" data-input-type="rangeSlider" min="6" max="999" data-type="wysiwyg" data-sub-type="fluid" name="max-font-size" data-id="{{id}}"></div>
	<div class="wysiwyg-input wysiwyg-fluid"><input type="number" value="20" data-input-type="rangeSlider" min="1" max="999" data-type="wysiwyg" data-sub-type="fluid" name="fluid-font-size" data-id="{{id}}"></div>
</template>