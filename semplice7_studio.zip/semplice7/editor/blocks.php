<?php

// namespace
namespace Semplice\Editor;

// use
use Semplice\Editor\Components;
use Semplice\Helper\Basic;
use Semplice\Helper\Get;
use Semplice\Helper\Ram;
use Semplice\Helper\Image;
use Semplice\Helper\Background;

// -----------------------------------------
// semplice blocks
// -----------------------------------------

class Blocks {

	// -----------------------------------------
	// public vars
	// -----------------------------------------

	public static $db;
	public static $db_version;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// database
		global $wpdb;
		self::$db = $wpdb;
		// db version
		self::$db_version = get_option('semplice_content_blocks_db_version');
		// add action
		add_action('init', array(&$this, 'status'));
	}

	// -----------------------------------------
	// check db status
	// -----------------------------------------

	public static function status() {
		// atts
		$atts = array(
			'db_version' => '1.2',
			'is_update'  => false
		);
		// check if table is already created
		if(self::$db->get_var("SHOW TABLES LIKE '" . SEMPLICE_BLOCKS_TABLE . "'") != SEMPLICE_BLOCKS_TABLE || self::$db_version != $atts['db_version']) {
			// setup blocks (install or update)
			self::setup($atts);
		}
	}

	// -----------------------------------------
	// setup database for blocks
	// -----------------------------------------

	public static function setup($atts) {
		// charset
		$charset_collate = self::$db->get_charset_collate();
		// database tables
		$atts['sql'] = "CREATE TABLE " . SEMPLICE_BLOCKS_TABLE . " (
			id mediumint(9) NOT NULL AUTO_INCREMENT,
			name tinytext NOT NULL,
			content longtext NOT NULL,
			masterblock tinytext NOT NULL,
			type tinytext NOT NULL,
			active boolean NOT NULL,
			UNIQUE KEY id (id)
		) $charset_collate;";
		// install or update table
		if (!function_exists('blocks_db_install')) {
			function blocks_db_install($atts) {
				require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
				dbDelta($atts['sql']);
				// update db version
				update_option('semplice_content_blocks_db_version', $atts['db_version']);
			}
		}
		// check if table exists, if not install table
		if(self::$db->get_var("SHOW TABLES LIKE '" . SEMPLICE_BLOCKS_TABLE . "'") != SEMPLICE_BLOCKS_TABLE) {
			blocks_db_install($atts);
		}
		if (self::$db_version !== $atts['db_version']) {
			// is update
			$atts['is_update'] = true;
			// update db
			blocks_db_install($atts);
		}
	}

	// -----------------------------------------
	// get block
	// -----------------------------------------
	
	public static function get($id, $type) {
		// get json
		switch($type) {
			case 'layout':
				if(strpos($id, 'cover_') !== false) {
					$ram = file_get_contents(get_template_directory() . '/assets/json/covers/' . $id . '.json');
				} else {
					$ram = file_get_contents(get_template_directory() . '/assets/json/blocks/' . $id . '.json');
				}
				$block = array(
					'ram' => $ram,
				);
			break;
			case 'user':
				// get block from the db
				$block = self::$db->get_row("SELECT * FROM " . SEMPLICE_BLOCKS_TABLE . " WHERE id = $id", ARRAY_A);
				// add content to ram
				$block = array(
					'ram' 		  => $block['content'],
					'masterblock' => ($block['masterblock'] != 'false') ? $block['masterblock'] : false,
					'type'	      => (!empty($block['type'])) ? $block['type'] : 'section'
				);
			break;
		}
		// return
		return $block;
	}

	// -----------------------------------------
	// list blocks
	// -----------------------------------------

	public static function list() {
		// return list
		return '
			<ul class="sidebar-tabs-nav">
				<li><a class="sidebar-tab-nav active" data-tab="custom">Custom</a></li>
				<li><a class="sidebar-tab-nav" data-tab="layout">Layout Blocks</a></li>
			</ul>
			<div class="sidebar-active-line"></div>
			<div class="sidebar-gradient"></div>
			<div class="tab-content">
				<div class="custom-blocks sidebar-tab blocks-view active" data-tab="custom" data-mode="view">
					' . self::user_blocks() . '
				</div>
				<div class="layout-blocks sidebar-tab" data-tab="layout">
					<div class="layout-blocks">
						' . self::layout_blocks() . '
					</div>
				</div>
			</div>
		';
	}

	// -----------------------------------------
	// save block
	// -----------------------------------------

	public static function save($content, $name, $mode, $masterblock, $type, $is_first) {
		// empty name?
		if(empty($name)) {
			$name = 'Untitled';
		}
		// mode
		if($mode == 'save') {
			// save block in the database
			self::$db->insert(
				SEMPLICE_BLOCKS_TABLE,
				array(
					'name'		 	 => json_encode($name),
					'content'		 => $content,
					'masterblock'	 => $masterblock,
					'type'			 => $type,
					'active'		 => true
				)
			);
		} else {
			// update masterblock
			self::$db->update(
				SEMPLICE_BLOCKS_TABLE, 
				array(
					'content'	  	=> $content,
					'type'			=> $type
				),
				array(
					'masterblock' 	=> $masterblock
				)
			);
		}
		// is first?
		if(!Basic::boolval($is_first)) {
			// get blocks
			$latest_block = self::$db->get_results( 
				"
				SELECT id, name, masterblock, type, active
				FROM " . SEMPLICE_BLOCKS_TABLE . "
				ORDER BY ID DESC LIMIT 1
				"
			);
			return self::user_block_output($latest_block[0], $name);
		} else {
			// output newest list
			return self::user_blocks();
		}
	}

	// -----------------------------------------
	// delete blocks
	// -----------------------------------------

	public static function delete($id) {
		self::$db->delete(SEMPLICE_BLOCKS_TABLE, array('id' => $id));
	}

	// -----------------------------------------
	// layout blocks
	// -----------------------------------------

	public static function layout_blocks() {
		// types
		$types = json_decode(file_get_contents(SEMPLICE_DIR . '/assets/json/blocks.json'), true);
		// vars
		$blocks = '';
		// loop through types
		foreach ($types as $type => $content) {
			// open block list
			$blocks .= '<ul class="layout-blocks-' . $type . ' layout-blocks-list">';
			// loop through blocks
			if($content['count'] > 0) {
				$column_left = '';
				$column_right = '';
				$blocks .= '<li>';
				for($i = 1; $i <= $content['count']; $i++) {
					$block_content = '<a class="smp-block smp-section-block" data-block-id="' . $type . '_' . $i . '" data-block-type="layout" data-content-type="section"><img src="https://blocks.semplice.com/v7/images/preview/' . $type . '_' . $i . '.jpg"></a>';
					if($i % 2 == 0) {
						$column_right .= $block_content;
					} else {
						$column_left .= $block_content;
					}
				}
				$blocks .= '
						<p class="blocks-head">' . $content['name'] . '</p>
						<div class="blocks-columns">
							<div class="blocks-columns-left">' . $column_left . '</div>
							<div class="blocks-columns-right">' . $column_right . '</div>
						</div>
					</li>
				';
			}
			// close blocklist
			$blocks .= '</ul>';
		}
		// output list
		return $blocks;
	}

	// -----------------------------------------
	// user blocks
	// -----------------------------------------

	public static function user_blocks() {
		// output
		$output = '';
		$category_output = array();
		// get order
		$order = json_decode(get_option('semplice_blocks_order'), true);
		// get blocks
		$blocks_db = self::$db->get_results( 
			"
			SELECT id, name, masterblock, type, active
			FROM " . SEMPLICE_BLOCKS_TABLE . "
			ORDER BY ID DESC
			"
		);
		// add to compatible array
		$blocks = array();
		foreach($blocks_db as $block) {
			$blocks[$block->id] = $block;
		}
		// get blocks
		if(false !== $order && is_array($order) && !empty($order)) {
			foreach($order as $category_id => $category_content) {
				// blocks output
				$blocks_output = '';
				// iterate blocks
				foreach($category_content['blocks'] as $block) {	
					// is block still there?
					if(isset($blocks[$block['id']])) {
						$blocks_output .= self::user_block_output($blocks[$block['id']], $block['name']);
						// remove from blocks array
						unset($blocks[$block['id']]);
					}
				}
				// display
				$display = 'expanded';
				if(isset($category_content['display']) && $category_content['display'] == 'collapsed') {
					$display = 'collapsed';
				}
				// output
				$category_output[$category_id] = self::category_output($category_id, $category_content['name'], $blocks_output, $display);
			}
			// are there uncategorized blocks left?
			if(!empty($blocks)) {
				// blocks output
				$blocks_output = '';
				foreach($blocks as $block) {
					$blocks_output .= self::user_block_output($block, false);
				}
				// add uncategorized if not there
				if(!isset($category_output['uncategorized'])) {
					$category_output['uncategorized'] = self::category_output('uncategorized', 'Uncategorized', $blocks_output, 'expanded');
				} else {
					$category_output['uncategorized'] .= $blocks_output;
				}
			}
		} else if(!empty($blocks)) {
			// blocks output
			$blocks_output = '';
			// loop throuh blocks
			foreach($blocks as $block) {
				$blocks_output .= self::user_block_output($block, false);
			}
			// output
			$category_output['uncategorized'] = self::category_output('uncategorized', 'Uncategorized', $blocks_output, 'expanded');
		}
		// no output?
		if(empty($blocks) && empty($order)) {
			// empty state
			$output .= '
				<div class="empty-blocks">
					<div class="inner">
						<a class="blocks-videos" href="https://www.semplice.com/videos#blocks" target="_blank"></a>
					</div>
				</div>
			';
		} else {
			// closing categories
			if(!empty($category_output)) {
				foreach($category_output as $cat_output) {
					$output .= $cat_output . '</ul>';
				}
			}
			// closing
			$output .= '
					</ul>
					<div class="edit-blocks">
						<button class="click-handler add-category" data-handler="run" data-action="addCategory" data-action-type="blocks">+ Add Category</button>
						<button class="click-handler save-order" data-handler="run" data-action="order" data-action-type="blocks">Customize Blocks</button>
					</div>
			';
		}
		// output
		return $output;
	}

	// -----------------------------------------
	// category output
	// -----------------------------------------

	public static function category_output($id, $name, $blocks, $display) {
		return '
			<ul class="blocks-category" data-blocks-category-id="' . $id . '" data-display="' . $display . '">
				<div class="blocks-category-handle"></div>
				<div class="blocks-category-display"></div>
				<p class="blocks-head-small blocks-head-first blocks-category-name">' . $name . '</p>
				<div class="empty-state">This category is empty. <a class="click-handler" data-handler="run" data-action="removeCategory" data-action-type="blocks">Remove</a></div>
				' . $blocks . '
		';		
	}

	// -----------------------------------------
	// user block output
	// -----------------------------------------

	public static function user_block_output($block, $name) {
		// masterblock
		$masterblock = '';
		if(strpos($block->masterblock, 'master_') !== false) {
			$masterblock = '<div class="component-label">Component</div>';
		}
		// has no name in order?
		if(false === $name) {
			$name = json_decode($block->name);
		}
		// type
		$type = (!empty($block->type)) ? $block->type : 'section';
		return '
			<li id="block-' . $block->id . '" class="sortable-block" data-block-type="' . ((strpos($block->masterblock, 'master_') !== false) ? 'component' : 'static') . '">
				<div class="blocks-handle"></div>
				<a class="smp-block smp-block-' . $type . '" data-block-id="' . $block->id . '" data-block-type="user" data-content-type="' . $type . '" data-component-id="' . $block->masterblock . '">
					<h5>' . $name . '</h5>
					' . $masterblock . '
				</a>
				<button class="remove-block click-handler" data-handler="run" data-action-type="dialog" data-action="delete" data-setting-type="blocks" data-block-id="' . $block->id . '" data-component-id="' . $block->masterblock . '"></button>
			</li>
		';
	}

	// -----------------------------------------
	// get images for a content block
	// -----------------------------------------

	public static function content_images($ram) {
		$images = '';
		$image_modules = Get::image_modules();;
		// styles
		if(isset($ram['styles'])) {
			$images .= Background::image_id($ram['styles']) . ',';
		}
		// module
		if(isset($ram['module']) && in_array($ram['module'], $image_modules)) {
			$images .= Image::used_in_module($ram);
		}
		// return
		return Image::blocks_array(explode(',', preg_replace('/,+/', ',', trim($images, ','))));
	}
}
new Blocks;
?>