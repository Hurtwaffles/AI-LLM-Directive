<?php

// namespace
namespace Semplice\Editor;

// use
use Semplice\Helper\Styles;
use Semplice\Helper\Background;
use Semplice\Helper\Get;

// -----------------------------------------
// semplice editor styles
// -----------------------------------------

class EditorStyles {

	// -----------------------------------------
	// get editor styles
	// -----------------------------------------

	public static function get($mode, $css, $id, $module) {
		$output = '';
		// save border dir for mobile if set
		$border_dir = 'all';
		if(isset($css['xl']['border-direction']) && $css['xl']['border-direction'] != 'all') {
			$border_dir = $css['xl']['border-direction'];
		}
		// get desktop css
		if(!empty($css['xl'])) {
			$output .= '#content-holder ' . self::css($mode, $css['xl'], false, $id, $module, 'xl');
		}
		// get breakpoints
		$breakpoints = Get::breakpoints();
		// iterate breakpoints
		foreach ($breakpoints as $breakpoint => $width) {
			if(!empty($css[$breakpoint])) {
				// set border dir for breakpoint
				$css[$breakpoint]['border-direction'] = $border_dir;
				// merged styles
				$merged_styles = array_merge($css['xl'], $css[$breakpoint]);
				// desktop
				$output .= '@media screen' . $width['min'] . $width['max'] . ' { #content-holder ' . self::css($mode, $css[$breakpoint], $merged_styles,  $id, $module, $breakpoint) . '}';
			}
		}
		return $output;
	}

	// -----------------------------------------
	// editor css
	// -----------------------------------------

	public static function css($mode, $styles, $merged_styles, $id, $module, $bp) {
		// add selector
		$sel = array(
			'container'		 => '#' . $id . ' smp-container {',
			'contentWrapper' => '#' . $id . ' smp-content-wrapper {',
			'branding'		 => $id . ' {',
			'cover'			 =>	'#' . $id . ' smp-cover-image {'
		);
		// css open
		$css = isset($sel[$mode]) ? $sel[$mode] : '#' . $id . ' {';
		// directions
		$directions = array('top', 'right', 'bottom', 'left');
		// spacing and outer spacing
		if($mode != 'branding') {
			foreach ($directions as $dir) {
				if(isset($styles['padding-' . $dir])) {
					$css .= 'padding-' . $dir . ': ' . $styles['padding-' . $dir] . ';';
				}
				if(isset($styles['margin-' . $dir])) {
					$css .= 'margin-' . $dir . ': ' . $styles['margin-' . $dir] . ';';
				}
				if(isset($styles[$dir])) {
					$css .= $dir . ': ' . $styles[$dir] . ';';
				}
			}
		}
		// content will get applied at the bottom with the is-content sel
		if($mode != 'content') {
			// border width
			$css .= self::border($styles);
			// container shadow
			$css .= self::shadow($styles, false);
		}
		// get bg image and attributes. for non xl only get image and position
		$css .= ($merged_styles) ? Background::css($merged_styles, false) : Background::css($styles, false);
		// single attributes
		$atts = array('height', 'opacity', 'z-index', 'order', 'gap');
		foreach($atts as $attr) {
			if(isset($styles[$attr])) {
				$css .= $attr . ': ' . $styles[$attr] . ';';
			}
		}
		// blend mode
		if(strpos($mode, 'section') !== false && isset($styles['mix-blend-mode'])) {
			$css .= 'mix-blend-mode: ' . $styles['mix-blend-mode'] . ';';
		}
		// backdrop filter
		if(isset($styles['backdrop-filter']) && intval($styles['backdrop-filter']) > 0) {
			$css .= '-webkit-backdrop-filter: blur(' . $styles['backdrop-filter'] . 'px); backdrop-filter: blur(' . $styles['backdrop-filter'] . 'px);';
		}
		// navbar overlay width
		if($id == 'navbar-overlay') {
			// make sure width is set so that it gets calced correctly with the offsets
			$styles['width'] = (isset($styles['width'])) ? $styles['width'] : '100%';
			if(isset($styles['width'])) {
				$left = (isset($styles['left'])) ? floatval($styles['left']) : 0;
				$right = (isset($styles['right'])) ? floatval($styles['right']) : 0;
				$css .= 'width: calc(' . $styles['width'] . ' - ' . ($left + $right) . 'rem);';
			} 
		}
		// element css close
		$css .= '}';
		// apply to .is-content
		if($mode == 'content') {
			$css .= '#content-holder #' . $id . ' .is-content {';
			$css .= self::shadow($styles, $module);
			if($module != 'button') {
				$css .= self::border($styles);
			}
			$css .= '}';
		}
		return $css;
	}

	// -----------------------------------------
	// get border
	// -----------------------------------------

	public static function border($styles) {
		$css = '';
		// border width based on direction
		if(isset($styles['border-width'])) {
			$width = $styles['border-width'];
			if(isset($styles['border-direction']) && $styles['border-direction'] != 'all') {
				$directions = array('top' => 0, 'right' => 0, 'bottom' => 0, 'left' => 0);
				$directions[$styles['border-direction']] = $width;
				$width = $directions['top'] . ' ' . $directions['right'] . ' ' . $directions['bottom'] . ' ' . $directions['left'];
			}
			$css .= 'border-width: ' . $width . ';';
		}
		// single attributes
		$atts = array('style', 'radius', 'color');
		foreach($atts as $attr) {
			if(isset($styles['border-' . $attr])) {
				$css .= 'border-' . $attr . ': ' . $styles['border-' . $attr] . ';';
			}
		}
		// return
		return $css;
	}

	// -----------------------------------------
	// get shadow
	// -----------------------------------------

	public static function shadow($styles, $module) {
		// text shadow supported
		$supported = array('paragraph', 'text', 'fluidtext');
		// box sahdow
		if(isset($styles['box-shadow']) && $module != 'paragraph') {
			return 'box-shadow: ' . $styles['box-shadow'] . ';';
		} else if(isset($styles['text-shadow']) && in_array($module, $supported)) {
			// only show shadow if values are set
			if(strpos($styles['text-shadow'], '0rem 0rem 0rem') === false) {
				return 'text-shadow: ' . $styles['text-shadow'] . ';';
			}
		}
	}
}
new EditorStyles;
?>