<?php

// namespace
namespace Semplice\Editor;

// use
use Semplice\Editor\Blocks;
use Semplice\Helper\Basic;
use Semplice\Helper\Image;
use Semplice\Helper\Ram;

// -----------------------------------------
// semplice components
// -----------------------------------------

class Components {

	// -----------------------------------------
	// public vars
	// -----------------------------------------

	public static $db;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// database
		global $wpdb;
		self::$db = $wpdb;
	}

	// ----------------------------------------
	// get component content
	// ----------------------------------------

	public static function content($id) {
		// get component
		$result = self::$db->get_row(
			self::$db->prepare("SELECT content, type, active FROM " . SEMPLICE_BLOCKS_TABLE . " WHERE masterblock = %s", $id),
			ARRAY_A
		);
		// decode json
		if($result) {
			return array(
				'content' => ($result['content'] !== null) ? json_decode($result['content'], true) : array(),
				'type' => ($result['type'] !== null && !empty($result['type'])) ? $result['type'] : 'section'
			);
		} else {
			return false;
		}	
	}

	// -----------------------------------------
	// init components
	// -----------------------------------------

	public static function get($ram) {
		// vars
		$ram = json_decode($ram, true);
		$order = Ram::section_order($ram, true);
		$order_encoded = json_encode($ram['order']);
		$components = array();
		// iterate order
		foreach($order as $id) {
			if(strpos($id, '_') !== false) {
				// has component?
				if(isset($ram[$id]) && isset($ram[$id]['masterblock']) && strpos($ram[$id]['masterblock'], 'master_') !== false) {
					// vars
					$host_id = $id;
					$local_options = (isset($ram[$id]['local'])) ? $ram[$id]['local'] : false;
					$component = self::content($ram[$id]['masterblock']);
					// is component still active?
					if($component) {
						// change ids for db component version
						$content = Ram::change_ids($component['content'], false, true, $component['type']);
						// get active ram order version
						$db_order = ($component['type'] != 'content') ? Ram::{$component['type'] . '_order'}($content, false) : $content['order'];
						// column width
						$column_width = (strpos($host_id, 'column_') !== false && $ram[$host_id]['width']) ? $ram[$host_id]['width'] : false;  
						// new id
						$new_host_id = $db_order[0];
						// get sub array for the host id
						$sub_array = Ram::find_sub_array($ram['order'], $host_id);
						// define unset ids starting with host id
						$unset_ids = array($host_id);
						// has sub array?
						if($sub_array !== null) {
							// extract ids from sub array
							Ram::extract_ids($sub_array, $unset_ids);
							// unset ids
							foreach($unset_ids as $id) {
								if(isset($ram[$id])) {
									unset($ram[$id]);
								}
							}
							// replace old block order with db order
							Ram::replace_in_order($ram['order'], $host_id, $content['order']);
						} else if($component['type'] == 'content' && isset($ram[$host_id])) {
							unset($ram[$host_id]);
							// replace content in order
							Ram::replace_content($ram['order'], $host_id, $new_host_id);
						}
						// add content to ram
						foreach($db_order as $id) {
							if(strpos($id, '_') !== false && isset($content[$id])) {
								// add new id to ram
								$ram[$id] = $content[$id];
							}
						}
						// revert local column width
						if($column_width) {
							$ram[$new_host_id]['width'] = $column_width;
						}
						// add back local options
						if($local_options) {
							$ram[$new_host_id]['local'] = $local_options;
						}
					} else {
						// merge local options and remove
						if($local_options) {
							$ram[$id]['options'] = array_merge($ram[$id]['options'], $local_options);
							unset($ram[$id]['local']);
						}
						// remove masterblock
						unset($ram[$id]['masterblock']);
					}
				}
			}
		}
		// return ram
		return json_encode($ram, JSON_FORCE_OBJECT);
	}

	// -----------------------------------------
	// get unset ids
	// -----------------------------------------

	public static function unset_ids($order, &$ids = array()) {
		foreach ($order as $key => $value) {
			// Add the key if it's not an integer (associative key)
			if (!is_int($key)) {
				$ids[] = $key;
			}
			// If the value is an order, recurse into it
			if (is_array($value)) {
				self::unset_ids($value, $ids);
			} else {
				// If the value is a string, add it to the IDs order
				if (is_string($value)) {
				    $ids[] = $value;
				}
			}
		}
	}

	// -----------------------------------------
	// sync components
	// -----------------------------------------

	public static function sync($components) {
		$components = json_decode($components, true);
		if(!empty($components) && is_array($components)) {
			foreach ($components as $id => $component) {
				// check slashes
				$content = Basic::check_slashes($component['content']);
				// save content
				Blocks::save($content, '', 'update', $id, $component['type'], false);
			}
		}
	}

	// -----------------------------------------
	// remove inactive masterblocks
	// -----------------------------------------

	public static function is_active($ram, $id, $active_components) {
		if(isset($ram[$id]) && isset($ram[$id]['masterblock']) && false !== strpos($ram[$id]['masterblock'], 'master_') && !in_array($ram[$id]['masterblock'], $active_components)) {
			unset ($ram[$id]['masterblock']);
		}
		// return
		return $ram;
	}

	// -----------------------------------------
	// get component name
	// -----------------------------------------

	public static function name($ram) {
		return (isset($ram['masterblock']) && false !== strpos($ram['masterblock'], 'master_')) ? 'data-component="' . $ram['masterblock'] . '"' : '';
	}
}
new Components;
?>