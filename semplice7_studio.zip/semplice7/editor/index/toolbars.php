<?php 
	use Semplice\Helper\Get;
?>
<div class="editor-toolbars">
	<!-- wysiwyg toolbar -->
	<div id="wysiwyg-toolbar"></div>
	<!-- accordion toolbar -->
	<div id="accordion-toolbar" class="editor-toolbar">
		<div class="toolbar-mode"><span><?php echo Get::svg('editor', 'sidebar/modules/accordion'); ?></span></div>
		<div class="toolbar-desc">Accordion Editor</div>
		<button class="toolbar-save" data-toolbar="accordion">Save</button>
	</div>
	<!-- reorder toolbar -->
	<div id="reorder-toolbar" class="editor-toolbar">
		<div class="toolbar-mode"><span><?php echo Get::svg('editor', 'tools/reorder'); ?></span></div>
		<div class="toolbar-desc">Re-Order</div>
		<div class="reorder-mode">
			<a class="toolbar-link click-handler" data-handler="run" data-action-type="helper" data-setting-type="editor" data-action="reOrder" data-mode="section">Sections</a>
			<a class="toolbar-link click-handler" data-handler="run" data-action-type="helper" data-setting-type="editor" data-action="reOrder" data-mode="row">Rows</a>
		</div>
		<div class="reorder-row-note">Only sections with multiple rows are displayed. (Components are hidden)</div>
		<button class="toolbar-save" data-toolbar="reorder">Save</button>
	</div>
	<!-- components toolbar -->
	<div id="components-toolbar">
		<button class="save-component" data-id="">Save</button>
	</div>
	<!-- animate toolbar -->
	<div id="animate-toolbar" class="editor-toolbar">
		<div class="toolbar-mode"><span><?php echo Get::svg('editor', 'tools/animate'); ?></span></div>
		<div class="toolbar-desc animate-desc">Animation Editor</div>
		<div class="animate-ba-wrapper"><a class="toolbar-link click-handler" data-handler="dropdown" data-dropdown="animate">Bulk Apply</a><div class="success">Preset applied successfully</div></div>
		<a class="toolbar-link reset-animations click-handler" data-handler="run" data-action-type="dialog" data-setting-type="animate" data-action="resetAll">Reset Animations</a>
		<div class="animate-actions">
			<a class="toolbar-link animate-preview click-handler" data-handler="run" data-action-type="animatePreview" data-action="prepare">Preview All</a>		
			<button class="animate-save animate-exit click-handler" data-handler="run" data-action-type="animate" data-action="exit">Done</button>
			<div class="preview-overlay">
				<a class="toolbar-link animate-exit-preview ajax-save click-handler" data-handler="run" data-action-type="animatePreview" data-action="exit"><span>Exit Preview</span></a>
				<div class="preview-scrollbar"><div class="bar-empty"></div><div class="bar-filled"></div></div>
			</div>
		</div>
	</div>
</div>