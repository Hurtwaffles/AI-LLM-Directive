<?php 
	use Semplice\Helper\Get;
?>
<header id="editor-header">
	<div class="click-handler navigator" data-handler="sidebar" data-sidebar="navigator"><?php echo Get::svg('editor', 'topbar/eagle'); ?></div>
	<div class="mobile-edit"></div>
	<div class="editor-add">
		<ul class="modules">
			<?php
				$modules = array('text', 'image', 'gallery', 'video', 'button', 'spacer', 'subrow', 'spacercolumn');
				$special = array('subrow' => 'Nested Row', 'spacercolumn' => 'Spacer Column');
				foreach($modules as $module) {
					$tooltip = (isset($special[$module])) ? $special[$module] : ucfirst($module);
					echo '<li class="has-tooltip" data-tooltip="' . $tooltip . '" data-tooltip-settings="bottom,center,auto"><a class="' . (($module != 'spacercolumn') ? 'add-content' : 'add-spacer-column') . '" data-module="' . $module . '">' . Get::svg('editor', 'modules/' . $module) . '</a></li>';
				}
			?>
		</ul>
		<ul class="text-links">
			<li class="eh-modules"><a class="click-handler" data-handler="sidebar" data-sidebar="modules">Modules</a></li>
			<li class="eh-cover"><a class="click-handler" data-handler="dropdown" data-dropdown="cover">Cover</a></li>
				<?php 
					if(SEMPLICE_EDITION == 'single') {
						echo '<li class="eh-blocks click-handler" data-handler="run" data-action="studio" data-action-type="dialog" data-setting-type="core" data-feature="blocks"><a>Blocks</a></li>';
					} else {
						echo '<li class="eh-blocks"><a class="click-handler" data-handler="sidebar" data-sidebar="blocks">Blocks</a></li>';
					}
				?>
		</ul>
	</div>
	<div class="editor-meta">
		<div class="animate click-handler" data-handler="run" data-action-type="animate" data-action="init"><?php echo Get::svg('editor', 'topbar/animate'); ?><span>Animate</span></div>
		<ul class="meta">
			<li class="meta-branding"><a class="click-handler has-tooltip" data-handler="dropdown" data-dropdown="branding" data-tooltip="Page Styling" data-tooltip-settings="bottom,center,auto"><?php echo Get::svg('editor', 'topbar/meta/branding'); ?></a></li>
			<li class="meta-settings"><a class="click-handler has-tooltip" data-handler="sidebar" data-sidebar="settings" data-tooltip="Page Settings" data-tooltip-settings="bottom,center,auto"><?php echo Get::svg('editor', 'topbar/meta/settings'); ?></a></li>
			<li class="meta-settings-footer"><a class="click-handler has-tooltip" data-handler="run" data-action-type="dialog" data-setting-type="core" data-action="footerSettings" data-tooltip="Footer Settings" data-tooltip-settings="bottom,center,auto"><?php echo Get::svg('editor', 'topbar/meta/settings'); ?></a></li>
			<li class="meta-breakpoints"><a class="click-handler has-tooltip" data-handler="dropdown" data-dropdown="breakpoints" data-tooltip="Breakpoints" data-tooltip-settings="bottom,center,auto"><?php echo Get::svg('editor', 'topbar/meta/breakpoints'); ?></a></li>
			<li class="meta-revisions"><a class="click-handler revisions-button has-tooltip" data-handler="dropdown" data-dropdown="revisions" data-tooltip="Versions" data-tooltip-settings="bottom,center,auto"><?php echo Get::svg('editor', 'topbar/meta/versions'); ?></a></li>
			<li class="meta-preview"><a class="editor-preview has-tooltip" target="_blank" data-tooltip="Preview" data-tooltip-settings="bottom,center,auto"><?php echo Get::svg('editor', 'topbar/meta/preview'); ?></a></li>
		</ul>
		<ul class="publish">
			<li><a class="publish-button ajax-save click-handler" data-handler="dropdown" data-dropdown="publish"><span>Publish</span><span id="unpublished-changes"></span></a></li>
			<li><a class="editor-save ajax-save click-handler" data-handler="savePost" data-mode="draft" data-change-status="no" data-exit="no"><span class="text">Save</span></a>
		</ul>
	</div>
</header>