<?php
	use Semplice\Helper\Get;
?>
<div id="editor-tools">
	<div class="editor-tool editor-tools-reorder has-tooltip" data-tooltip="Re-Order" data-tooltip-settings="top,center,auto">
		<a class="click-handler" data-handler="run" data-action-type="helper" data-setting-type="editor" data-action="reOrder" data-mode="section"><?php echo Get::svg('editor', 'tools/reorder'); ?></a>
	</div>
	<div class="editor-tool editor-tools-animate has-tooltip" data-tooltip="Animate" data-tooltip-settings="top,center,auto">
		<a class="click-handler" data-handler="run" data-action-type="animate" data-action="init"><?php echo Get::svg('editor', 'tools/animate'); ?></a>
	</div>
	<div class="editor-tool editor-tools-grid has-tooltip" data-tooltip="Grid Mode" data-tooltip-settings="top,center,auto">
		<a class="click-handler" data-handler="run" data-action-type="helper" data-setting-type="editor" data-action="showGrid"><?php echo Get::svg('editor', 'tools/grid'); ?></a>
	</div>
	<div class="editor-tool editor-tools-history has-tooltip" data-tooltip="Undo/Redo" data-tooltip-settings="top,center,auto">
		<smp-undo class="smp-history smp-undo" data-state="undo"></smp-undo>
		<smp-redo class="smp-history smp-redo disabled" data-state="redo"></smp-redo>
	</div>
</div>