<div id="animate-markers" data-is-pinned="false">
	<div class="animate-trigger-markers">
		<div class="marker-position start-trigger-position"><div class="animate-marker animate-start_trigger" data-trigger="start_trigger" data-type="trigger"><span class="trigger-label">Start Trigger</span><span class="marker-percent"></span></div></div>
		<div class="marker-position end-trigger-position"><div class="animate-marker animate-end_trigger" data-trigger="end_trigger" data-type="trigger"><span class="trigger-label">End Trigger</span><span class="marker-percent"></span></div></div>
	</div>
	<div class="animate-scroller-markers">
		<div class="marker-position start-scroller-position"><div class="animate-marker animate-start_scroller" data-trigger="start_scroller" data-type="scroller">Start Point<span class="marker-percent"></span></div></div>
		<div class="marker-position end-scroller-position"><div class="animate-marker animate-end_scroller" data-trigger="end_scroller" data-type="scroller">End Point<span class="marker-percent"></span></div></div>
	</div>
</div>