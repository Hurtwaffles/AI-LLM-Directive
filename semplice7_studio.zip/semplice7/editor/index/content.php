<?php 
	use Semplice\Helper\Get;
	use Semplice\Editor\Sidebar;
?>
<div id="editor-content">
	<!-- sidebars -->
	<?php echo Sidebar::init(); ?>
	<!-- content holder -->
	<div id="content-holder"></div>
	<!-- coverslider open popup -->
	<div class="cs-open-popup has-tooltip" data-tooltip="Edit coverslider" data-tooltip-settings="left,center,auto"><button class="click-handler" data-handler="run" data-action-type="helper" data-setting-type="coverslider" data-action="showPopup"><?php echo Get::svg('admin', 'edit'); ?></a></div>
</div>