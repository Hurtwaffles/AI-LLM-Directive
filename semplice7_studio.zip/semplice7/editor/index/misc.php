<!-- undo notice -->
<div id="undo-notice"></div>
<!-- column count -->
<div class="column-count"><span class="count"></span></div>
<!-- context menu -->
<div id="context-menu"></div>