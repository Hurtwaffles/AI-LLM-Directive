<?php
// use
use Semplice\Helper\Basic;
use Semplice\Helper\Color;
// output
$output = array(
	'html' => '',
	'css'  => '',
);
// attributes
extract(shortcode_atts(
	array(
		'hor_full_width'				=> '6',
		'hor_full_width_lg'				=> '6',
		'hor_full_width_md'				=> '6',
		'hor_full_width_sm'				=> '12',
		'hor_full_width_xs'				=> '12',
		'hor_full_object_fit'			=> 'cover',
		'hor_full_object_position'		=> 'top-center',
		'hor_full_bg_even'				=> '#000000',
		'hor_full_bg_odd'				=> '#cccccc',
		'hor_full_transition'			=> 'disabled',
		'hor_full_title_position'		=> 'bottom-center',
		'hor_full_title_visibility'		=> 'both',
		'hor_full_title_padding'		=> '4rem',
		'hor_full_title_offset'			=> '0rem',
		'hor_full_title_color'			=> 'white',
		'hor_full_title_font_family'	=> 'bold',
		'hor_full_title_fontsize'		=> '2.333333333333333rem',
		'hor_full_title_letter_spacing'	=> '0rem',
		'hor_full_title_line_height'	=> '100',
		'hor_full_title_text_transform' => 'none',
		'hor_full_type_color'			=> 'white',
		'hor_full_type_font_family'		=> 'regúlar',
		'hor_full_type_fontsize'		=> '1.111111111111111rem',
		'hor_full_type_text_transform' 	=> 'none',
		'hor_full_type_padding_top'		=> '0.5555555555555556rem',
		'hor_full_arrow_visibility'		=> 'visible',
		'hor_full_arrow'				=> 'default',
		'hor_full_arrow_custom'			=> false,
		'hor_full_arrow_size'			=> 'small',
		'hor_full_arrow_color'			=> '#ffffff',
		'hor_full_arrow_bg_color'		=> '#00000000',
		'hor_full_hover'				=> 'scale-opacity',
		'hor_full_hover_so_opacity'		=> 40,
		'hor_full_hover_so_scale'		=> 7,
		'hor_full_hover_dimdown_opacity'=> 40,
		'hor_full_hover_border_width'	=> '0.8333333333333333rem',
		'hor_full_hover_border_color'	=> '#ffffff',
		'hor_full_hover_title_fade'		=> 'none',
		'hor_full_attraction'			=> '0.025',
		'hor_full_friction'				=> '0.28',
	), $content['options'])
);
// group cells
$group_cells = array(
	'6' => 2,
	'4' => 3,
);
// custom transition
$custom_transition = ($hor_full_transition == 'enabled') ? ' data-custom-transition="horizontal-fullscreen"' : '';
// create apg wrapper
$output['html'] .= '<div class="apg apg-hor-full" data-object-fit="' . $hor_full_object_fit . '" data-title-visibility="' . $hor_full_title_visibility . '" data-arrow-visibility="' . $hor_full_arrow_visibility . '" data-arrow-size="' . $hor_full_arrow_size . '" data-mouseover="' . $hor_full_hover . '">';
// css open (even odd needs to be defined earlier to be able to get overwritten without important statement)
$selector = '#' . $id . ' .apg-hor-full';
$output['css'] .= $selector . ' .even { ' . Color::bg_css($hor_full_bg_even, self::$is_editor, false) . ' }' . $selector . ' .odd { ' . Color::bg_css($hor_full_bg_odd, self::$is_editor, false) . ' }';
// mobile detect
$mobile_detect = Basic::mobile_detect();
// remove hover on mobile
if($mobile_detect->isMobile()) {
	$hor_full_hover = 'none';
	$hor_full_hover_title_fade = 'none';
}
// iterate projects
foreach ($posts as $key => $post) {
	// bg color class
	$bg_color_class = 'odd';
	// is even?
	if ($key % 2 == 0) {
		$bg_color_class = 'even';
	}
	// options
	$values = $this->custom_options($post['post_id'], $post['thumbnail']['src'], $content['options']);
	// project type
	$project_type = '';
	if($post['post_type'] == 'project') {
		$project_type = '<div class="type" data-font="' . $hor_full_type_font_family . '"' . Color::has_gradient($hor_full_type_color, '') . '><span>' . $post['project_type'] . '</span></div>';
	}
	// output
	$output['html'] .= '
		<div class="post-' . $post['post_id'] . ' apg-post apg-post-hor-full carousel-cell ' . $bg_color_class . $values['custom_class'] . '" data-xl-width="' . $hor_full_width . '" data-lg-width="' . $hor_full_width_lg . '" data-md-width="' . $hor_full_width_md . '" data-sm-width="' . $hor_full_width_sm . '" data-xs-width="' . $hor_full_width_xs . '" data-apg-object-position="' . $hor_full_object_position . '">
			' . $this->custom_styles($id, 'hor-full', $post, $values) . '
			<a class="apg-link" href="' . $post['permalink'] . '"' . $custom_transition . ' data-transition-element="transition_' . substr(md5(rand()), 0, 9) . '"></a>
			<div class="apg-grid-item">
				<div class="post-thumbnail" data-scale="' . $hor_full_hover_so_scale . '">
					' . $this->thumbnail($values['thumbnail'], 'hor-full', $id, $post) . '
				</div>
				<div class="apg-post-title ' . $hor_full_hover_title_fade . '" data-title-align="' . $hor_full_title_position . '">
					<div class="title" data-font="' . $hor_full_title_font_family . '"' . Color::has_gradient($hor_full_title_color, '') . '><span>' . $post['post_title'] . '</span></div>
					' . $project_type . '
				</div>
			</div>
		</div>
	';
	// css output for background color
	if(isset($values['background-color']) && $values['background-color']) {
		// its a special case (since we can have a gradient from the odd/even bg color) so add background-image none for the frontend
		$affix = '';
		if(false === strpos($values['background-color'], 'gradient') && !self::$is_editor) {
			$affix = ' background-image: none;';
		}
		$output['css'] .= $selector . ' .post-' . $post['post_id'] . ' { ' . Color::bg_css($values['background-color'], self::$is_editor, false) . $affix . ' }';
	}
}
// css
$output['css'] .= '
	' . $section_element . ' .row, ' . $section_element . ' .row .column { height: 100% !important; } ' . $section_element . ' .column-content { height: 100vh; }
	' . $selector . ' .apg-post .apg-post-title, #apg-transition-' . $id . ' .apg-grid-item .apg-post-title { padding: ' . $hor_full_title_padding . '; margin: ' . $hor_full_title_offset . ' 0; }
	' . $selector . ' .apg-post .apg-post-title .title, #apg-transition-' . $id . ' .apg-grid-item .apg-post-title .title { font-size: ' . $hor_full_title_fontsize . '; text-transform: ' . $hor_full_title_text_transform . '; 
	letter-spacing: ' . $hor_full_title_letter_spacing . '; line-height: ' . $hor_full_title_line_height . '%;}
	' . $selector . ' .apg-post .apg-post-title .title span, #apg-transition-' . $id . ' .apg-grid-item .apg-post-title .title span { ' . Color::css($hor_full_title_color, self::$is_editor) . ' }
	' . $selector . ' .apg-post .apg-post-title .type, #apg-transition-' . $id . ' .apg-grid-item .apg-post-title .type { font-size: ' . $hor_full_type_fontsize . '; text-transform: ' . $hor_full_type_text_transform . '; padding-top: ' . $hor_full_type_padding_top . ';}
	' . $selector . ' .apg-post .apg-post-title .type span, #apg-transition-' . $id . ' .apg-grid-item .apg-post-title .type span { ' . Color::css($hor_full_type_color, self::$is_editor) . ' }
	' . $selector . ' .flickity-button-icon path { fill: ' . $hor_full_arrow_color . '; }
	' . $selector . ' .flickity-prev-next-button { background-color: ' . $hor_full_arrow_bg_color . '; }
';
// responsive css and mouseover
if(!self::$is_editor) {
	//mouseover
	if(!$mobile_detect->isMobile()) {
		switch($hor_full_hover) {
			case 'scale-opacity':
				$output['css'] .= '
					' . $selector . ' .flickity-slider:hover .apg-post .apg-grid-item { opacity: ' . ($hor_full_hover_so_opacity / 100) . '; }
					' . $selector . ' .flickity-slider .apg-post:hover .apg-grid-item .post-thumbnail img { transform: scale(' . (($hor_full_hover_so_scale / 100) + 1) . '); }
				';
			break;
			case 'dim-down':
				$output['css'] .= '
					' . $selector . ' .apg-post:hover .post-thumbnail { opacity: ' . ($hor_full_hover_dimdown_opacity / 100) . '; }
				';
			break;
			case 'border':
				$output['css'] .= '
					' . $selector . ' .apg-grid-item:hover:after { border-width: ' . $hor_full_hover_border_width . '; border-color: ' . $hor_full_hover_border_color . '; }
				';
			break;
		}
	}
	$output['css'] .= $this->breakpoints_css($id, 'hor-full', $content['options'], false);
}
// close apg wrapper
$output['html'] .= '</div>';
// ret
return $output;
?>