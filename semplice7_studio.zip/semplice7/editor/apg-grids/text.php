<?php
// use
use Semplice\Helper\Color;
// output
$output = array(
	'html' => '',
	'css'  => '',
);
// attributes
extract(shortcode_atts(
	array(
		'text_transition'				=> 'enabled',
		'text_hover_image_mode'			=> 'cover',
		'text_hover_image_width'		=> '60',
		'text_hover_effect'				=> 'fade_both',
		'text_hover_title_color'		=> '',
		'text_hover_title_opacity'		=> '20',
		'text_title_direction'			=> 'column-dir',
		'text_title_position'			=> 'middle-center',
		'text_title_padding'			=> '4rem',
		'text_title_item_padding_ver'	=> '0.5555555555555556rem',
		'text_title_item_padding_hor'	=> '1rem',
		'text_title_color'				=> 'white',
		'text_title_font_family'		=> 'bold',
		'text_title_fontsize'			=> '5',
		'text_title_line_height'		=> '100',
		'text_title_text_transform'		=> 'none',
		'text_title_letter_spacing'		=> '0',
		'text_seperator_color'			=> 'white',
		'text_seperator_font_family'	=> 'bold',
		'text_seperator_fontsize'		=> '5',
		'text_seperator_text_transform'	=> 'none',
		'text_seperator'				=> '/',
	), $content['options'] )
);
// custom transition
$custom_transition = ($text_transition == 'enabled') ? ' data-custom-transition="text"' : '';
// get item padding
$text_title_item_padding_ver = floatval(str_replace('rem', '', $text_title_item_padding_ver)) / 2;
$text_title_item_padding_hor = floatval(str_replace('rem', '', $text_title_item_padding_hor)) / 2;
// create apg wrapper
$output['html'] .= '<div class="apg apg-text ' . $text_title_direction . '" data-image-mode="' . $text_hover_image_mode . '" data-mouseover-effect="' . $text_hover_effect . '" data-title-align="' . $text_title_position . '">';
// count
$max = count($posts);
$i = 1;
// text gradient
$title_gradient = Color::has_gradient($text_title_color, '');
if(!self::$is_editor) {
	if(false !== strpos($text_title_color, 'gradient') || false !== strpos($text_hover_title_color, 'gradient')) {
		$title_gradient = 'data-has-gradient="true"';
	}
}
// seperator
$seperator = '<div class="apg-text-seperator" data-font="' . $text_seperator_font_family . '"' . Color::has_gradient($text_seperator_color, '') . '><span>' . $text_seperator . '</span></div>';
// iterate projects
foreach ($posts as $key => $post) {
	// options
	$values = $this->custom_options($post['post_id'], $post['thumbnail']['src'], $content['options']);
	// add seperator
	if($i == $max) {
		$seperator = '';
	}
	// output
	$output['html'] .= '
		<div class="post-' . $post['post_id'] . ' apg-post apg-post-text' . $values['custom_class'] . '" data-post-id="' . $post['post_id'] . '">
			' . $this->custom_styles($id, 'text', $post, $values) . '
			<a class="apg-grid-item" href="' . $post['permalink'] . '">
				<div class="post-thumbnail" data-image-width="' . $text_hover_image_width . '">
					' . $this->thumbnail($values['thumbnail'], 'hor-full', $id, $post) . '
				</div>
				<div class="apg-post-title">
					<div class="title" data-font="' . $text_title_font_family . '" ' . $title_gradient . '><span>' . $post['post_title'] . '</span></div>
				</div>
			</a>
			' . $seperator . '
		</div>
	';
	// inc
	$i++;
}
// gradient mouseover duration
$duration = ($text_hover_effect == 'none' || $text_hover_effect == 'fade_image') ? '.01' : '.75';
// css
$selector = '#' . $id . ' .apg-text';
$output['css'] .= '
	' . $section_element . ' .row, ' . $section_element . ' .row .column { height: 100% !important; } ' . $section_element . ' .column-content { min-height: 100vh; height: auto; }
	' . $selector . ' { padding: ' . $text_title_padding . '; }
	' . $selector . ' .apg-post .apg-post-title .title, #' . $id . ' .apg-text-seperator { font-size: ' . $text_title_fontsize . '; text-transform: ' . $text_title_text_transform . '; letter-spacing: ' . $text_title_letter_spacing . '; line-height: ' . $text_title_line_height . '%; }
	' . $selector . ' .apg-post .apg-post-title .title span { ' . Color::css($text_title_color, self::$is_editor) . '; transition: ' . Color::gradient_vars($duration, '--ease-out-expo') . '; }
	' . $selector . ' .apg-text-seperator span { ' . Color::css($text_seperator_color, self::$is_editor) . ' }
	' . $selector . ' .apg-text-active .apg-post-title .title, #' . $id . ' .apg-text .apg-text-active .apg-text-active.apg-text-seperator { opacity: ' . ($text_hover_title_opacity / 100) . '; }
	#' . $id . ' .row-dir { margin: -' . $text_title_item_padding_ver . 'rem -' . $text_title_item_padding_hor . 'rem; }
';

// mouseover title color
if(!empty($text_hover_title_color)) {
	$output['css'] .= $selector . ' .apg-post:hover .title span { ' . Color::css($text_hover_title_color, true) . ' }';
} else {
	$output['css'] .= $selector . ' .apg-post:hover .title span { ' . Color::css($text_title_color, true) . ' }';
}
// gradient animation for the frontend
if(!self::$is_editor) {
	$output['css'] .= Color::gradient_mouseover('#content-holder #' . $id . ' .apg .apg-post-text .title span', $text_title_color, $text_hover_title_color, false);
}
// padding
if($text_title_direction == 'column-dir') {
	$output['css'] .= $selector . ' .apg-post-title { padding-top: ' . $text_title_item_padding_ver . 'rem; padding-bottom: ' . $text_title_item_padding_ver . 'rem; }';
} else {
	$output['css'] .= $selector . ' .apg-post-text { padding-top: ' . $text_title_item_padding_ver . 'rem; padding-bottom: ' . $text_title_item_padding_ver . 'rem; }';
	$output['css'] .= $selector . ' .apg-grid-item { padding-left: ' . $text_title_item_padding_hor . 'rem; padding-right: ' . $text_title_item_padding_hor . 'rem; }';
}
// responsive css
if(!self::$is_editor) {
	$output['css'] .= $this->breakpoints_css($id, 'text', $content['options'], $text_title_direction);
}
// close apg wrapper
$output['html'] .= '</div>';
// ret
return $output;
?>