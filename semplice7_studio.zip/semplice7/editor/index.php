<?php
	use Semplice\Helper\Get;
	use Semplice\Editor\Sidebar;
?>
<!-- semplice editor -->
<div id="semplice-editor" data-mode="default" data-content-mode="regular" data-reorder="section">
	<?php
		// grid
		echo Get::background_grid('editor-grid');
		// header
		include('index/header.php');
		// content
		include('index/content.php');
		// toolbars
		include('index/toolbars.php');
		// markers
		include('index/markers.php');
		// tools
		include('index/tools.php');
		// misc
		include('index/misc.php');
	?>
</div>
<!-- editor templates -->
<div class="editor-templates"><?php foreach (glob(SEMPLICE_DIR  . '/editor/templates/*.php') as $filename) { include $filename; } ?></div>