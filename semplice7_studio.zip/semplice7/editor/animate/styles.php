<?php

// namespace
namespace Semplice\Editor;

// use
use Semplice\Helper\Get;
use Semplice\Helper\Color;
use Semplice\Editor\AnimateGet;

// -----------------------------------------
// semplice animate styles
// -----------------------------------------

class AnimateStyles {

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {}

	// -----------------------------------------
	// get styles
	// -----------------------------------------

	public static function get($mode, $atts, $motions, $id) {
		// vars
		$css = array('regular' => array(), 'transform' => array(), 'boxShadow' => array(), 'filter' => array(), 'reveal' => array());
		$output_css = '';
		$text_color_css = '';
		$transform = '';
		$box_shadow = '';
		$gradient = '';
		$gsap_set = array();
		$module = isset($atts['module']) ? $atts['module'] : false;
		$selector = AnimateGet::selector($id, $atts);
		$bg_image_url = AnimateGet::bg_image_url($atts['styles']['xl']);
		$perspective = AnimateGet::perspective($motions);
		// first get initial defaults
		$initial_defaults = AnimateGet::initial_defaults($css, $motions['initial']);
		// add values from initial state
		$css = AnimateStyles::effects($css, $initial_defaults, $atts['styles']['xl']);
		// text color
		$text_color = (isset($css['regular']['color'])) ? $css['regular']['color'] : false;
		if($text_color && !Color::is_transparent($text_color)) {
			if(strpos($text_color, 'gradient') !== false) {
				$text_color_css = $selector . ' [data-has-gradient="true"] { background: none !important; }';
				$text_color_css .= $selector . ' { background-image: ' . $text_color . '; -webkit-text-fill-color: transparent !important; -webkit-background-clip: text !important; }';
			} else {
				$text_color_css = $selector . ' * { color: inherit !important; background: none !important; -webkit-text-fill-color: initial !important; }';
			}
		} else if($text_color) {
			unset($css['regular']['color']);
		}
		// remove background-color from modules
		if($module) {
			unset($css['regular']['background-color']);
			$bg_image_url = 'none';
		}
		// generate regular css
		if(!empty($css['regular'])) {
			foreach ($css['regular'] as $attribute => $value) {
				// make sure its not an array (mesh) or background-color
				if($attribute != 'background-color' && !is_array($value)) {
					$output_css .= $attribute . ': ' . $value . ';';
				} else if($attribute == 'mesh' && isset($css['regular']['background-color']) && strpos($css['regular']['background-color'], 'radial-gradient(at') !== false) {
					$output_css .= 'background-color: ' . $value['backgroundColor']. ';';
				}
			}
		}
		// get box shadow
		$box_shadow = self::box_shadow($css['boxShadow'], $module);
		// add box shadow to css
		if(false !== $box_shadow) {
			if($module == 'text' || $module == 'paragraph') {
				$output_css .= 'text-shadow: ' . $box_shadow . ';';
			} else {
				$output_css .= 'box-shadow: ' . $box_shadow . ';';
			}
		}
		// process background
		if(!$module && isset($css['regular']['background-color'])) {
			$output_css = self::background('css', $css['regular']['background-color'], $bg_image_url, $output_css);
		}
		// get filter state
		$filter_initial = self::get_filter_state($motions, 'initial');
		if(false !== $filter_initial && is_array($filter_initial) && !empty($filter_initial)) {
			foreach ($filter_initial as $filter => $value) {
				$css['filter'][$filter] = $value;
			}
		}
		// get filter
		$filter = self::filter($css['filter']);
		// add filter to css
		if(false !== $filter && !empty($filter)) {
			$output_css .= 'filter: ' . $filter . ';';
			$gsap_set['filter'] = $filter;
		}
		// get reveal
		$reveal = self::reveal($css['reveal'], $motions['initial']);
		// has reveal in steps
		$has_reveal = self::has_reveal($motions);
		// only add if initial changed or steps with reveal
		$default_reveal = 'polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)';
		if(true === $has_reveal || $reveal != $default_reveal) {
			// add reveal to gsap
			if(false !== $reveal && !empty($reveal)) {
				$gsap_set['clipPath'] = $reveal;
				$output_css .= 'clip-path: ' . $reveal . ';';
			}
		}		
		// generate transform css
		if(!empty($css['transform'])) {
			$transformOrder = array('translateX', 'translateY', 'translateZ', 'rotate', 'rotateY', 'rotateX', 'skew', 'scale');
			foreach ($transformOrder as $key => $attribute) {
				$value = false;
				if(isset($css['transform'][$attribute])) {
					$value = $css['transform'][$attribute];
				}
				if(strpos($attribute, 'rotate') !== false) {
					$value = $value . 'deg';
				}
				// combine skew and scale so the animation looks like gsap
				if($attribute == 'skew' || $attribute == 'scale') {
					$unit = '';
					if($attribute == 'skew') {
						$unit = 'deg';
					}
					$transform .= ' ' . $attribute . '(' . $css['transform'][$attribute . 'X'] . $unit . ',' . $css['transform'][$attribute . 'Y'] . $unit . ')';
					// set individual values for gsap
					$gsap_set[$attribute . 'X'] = $css['transform'][$attribute . 'X'] . $unit;
					$gsap_set[$attribute . 'Y'] = $css['transform'][$attribute . 'Y'] . $unit;
				} else {
					$transform .= ' ' . $attribute . '(' . $value . ')';
					$gsap_set[$attribute] = $value;
				}
			}
		}
		// transform css available?
		if(strlen($transform) > 0) {
			$output_css .= 'transform:' . $transform . ';';
		}
		// add perspective to gsap
		if($perspective) {
			$gsap_set['transformPerspective'] = $perspective;
		}
		// output
		if($mode == 'css') {
			return $selector . '{' . $output_css . '}' . $text_color_css;
		} else {
			return $gsap_set;
		}
	}

	// -----------------------------------------
	// get effects css
	// -----------------------------------------

	public static function effects($css, $effects, $styles) {
		// effects defaults
		$effects_defaults = AnimateGet::effects_defaults();
		// transform
		$transform = array('scaleX', 'scaleY', 'translateX', 'translateY', 'translateZ', 'rotate', 'rotateX', 'rotateY', 'skewX', 'skewY');
		foreach ($effects as $effect => $value) {
			// rem kommastsellen matchen mit gsap
			if(!is_array($value)) {
				if(strpos(strval($value), 'rem') !== false && $effect != 'filter_drop-shadow') {
					$value = floatval(str_replace('rem', '', $value));
					if($value > 0) {
						$value = number_format($value, 4) . 'rem';
					} else {
						$value .= 'rem';
					}
				}
				// is transform effect?
				if(in_array($effect, $transform)) {
					$css['transform'][$effect] = $value;
				} else if(strpos($effect, 'box-shadow') !== false) {
					$css['boxShadow'][$effect] = $value;
				} else if(strpos($effect, 'gradient') !== false) {
					$css['gradient'][$effect] = $value;
				} else if(strpos($effect, 'filter_') !== false && intval($value) !== $effects_defaults[$effect][$effect]) {
					$css['filter'][$effect] = $value;
				} else if(strpos($effect, 'reveal') !== false) {
					$css['reveal'][$effect] = $value;
				} else if(strpos($effect, 'border-') !== false) {
					$css['regular'][$effect] = self::border_width($styles, $value);
				} else if(strpos($effect, 'filter_') === false) {
					$css['regular'][$effect] = $value;
				}
			} else if($effect == 'mesh') {
				$css['regular'][$effect] = $value;
			}
		}
		return $css;
	}

	// -----------------------------------------
	// get box shadow
	// -----------------------------------------

	public static function box_shadow($box_shadow_values, $module) {
		// define
		$box_shadow = false;
		if(!empty($box_shadow_values)) {
			$box_shadow = '';
			// bsopacity
			$box_shadow_opacity = 1;
			$box_shadow_color = '#ffd300';
			$is_default = true;
			foreach ($box_shadow_values as $attribute => $value) {
				// is default?
				if(strpos(strval($value), 'rem') !== false && floatval($value) > 0) {
					$is_default = false;
				}
				// change defaults or add to css instantly
				if(strpos($attribute, 'opacity') !== false) {
					$box_shadow_opacity = $value;
				} else if(strpos($attribute, 'color') !== false && true === ctype_xdigit(str_replace('#', '', $value)) && strlen(str_replace('#', '', $value)) == 6) {
					$box_shadow_color = $value;
				} else {
					// has rem?
					if(is_numeric($value)) {
						$value .= 'rem';
					}
					if($attribute == 'box-shadow-spread-radius' && $module == 'paragraph' || $attribute == 'box-shadow-spread-radius' && $module == 'text') {
						$box_shadow = $box_shadow;
					} else {
						$box_shadow .= $value . ' ';
					}
				}
			}
			if(false === $is_default) {
				// color and opacity
				$rgb = Color::hex_to_rgb($box_shadow_color);
				// generate shadow
				$box_shadow .= 'rgba(' . $rgb['r'] . ',' . $rgb['g'] . ',' . $rgb['b'] . ',' . $box_shadow_opacity . ')';
			} else {
				$box_shadow = false;
			}
		}
		// return box shadow
		return $box_shadow;
	}

	// -----------------------------------------
	// process background
	// -----------------------------------------

	public static function background($type, $bg, $bg_image_url, $output) {
		// vars
		$is_gradient = (strpos($bg, 'gradient') !== false) ? true : false;
		$css_attr = ($is_gradient) ? 'background-image' : 'background-color';
		$js_attr = ($is_gradient) ? 'backgroundImage' : 'backgroundColor';
		// add image to gradient
		if($is_gradient && $bg_image_url) {
			$bg = $bg . ', ' . $bg_image_url;
		}
		// type
		if($type == 'css') {
			$output .= $css_attr . ':' . $bg . ';';
		} else {
			$output[$js_attr] = $bg;
		}
		return $output;
	}

	// -----------------------------------------
	// filter
	// -----------------------------------------

	public static function filter($filter_values) {
		$filter = false;
		// order
		ksort($filter_values);
		// iterate filter values
		if(!empty($filter_values)) {
			$filter = '';
			// iterate filters
			foreach ($filter_values as $attribute => $value) {
				$unit = '%';
				// change unit individualle
				if($attribute == 'filter_blur') { $unit = 'px'; }
				if($attribute == 'filter_hue-rotate') { $unit = 'deg'; }
				// add to filter
				$filter .= str_replace('filter_', '', $attribute) . '(' . $filter_values[$attribute] . $unit . ') ';
			}
		}
		// return gradient
		return $filter;
	}

	// -----------------------------------------
	// reveal
	// -----------------------------------------

	public static function reveal($reveal_values, $initial) {
		if(!empty($reveal_values)) {
			$type = 'rectangle';
			$values = array('reveal_x1_hor' => 0, 'reveal_x1_ver' => 0, 'reveal_x2_hor' => 100, 'reveal_x2_ver' => 0, 'reveal_y1_hor' => 100, 'reveal_y1_ver' => 100, 'reveal_y2_hor' => 0, 'reveal_y2_ver' => 100);
			// is circle?
			if(isset($initial['reveal_type']) && $initial['reveal_type'] == 'circle') {
				$type = 'circle';
				$values = array('reveal_circle_size' => 50, 'reveal_circle_x' => 50, 'reveal_circle_y' => 50);
			}
			// iterate reveal values
			if(!empty($reveal_values)) {
				foreach ($reveal_values as $attribute => $value) {
					$values[$attribute] = $value;
				}
			}
			// check reveal type and return
			if($type == 'rectangle') {
				return 'polygon(' . $values['reveal_x1_hor'] . '% ' . $values['reveal_x1_ver'] . '%, ' . $values['reveal_x2_hor'] . '% ' . $values['reveal_x2_ver'] . '%, ' . $values['reveal_y1_hor'] . '% ' . $values['reveal_y1_ver'] . '%, ' . $values['reveal_y2_hor'] . '% ' . $values['reveal_y2_ver'] . '%)';
			} else {
				return 'circle(' . $values['reveal_circle_size'] . '% at ' . $values['reveal_circle_x'] . '% ' . $values['reveal_circle_y'] . '%)';
			}
		} else {
			return false;
		}
	}

	// -----------------------------------------
	// has reveal?
	// -----------------------------------------

	public static function has_reveal($motions) {
		$has_reveal = false;
		// iterate steps
		foreach($motions['timeline'] as $steps => $step) {
			foreach($step['effects'] as $attribute => $value) {
				if(false !== strpos($attribute, 'reveal_')) {
					$has_reveal = true;
				}
			}
		}
		// ret
		return $has_reveal;
	}

	// -----------------------------------------
	// get filter state
	// -----------------------------------------

	public static function get_filter_state($motions, $step) {
		// define css
		$css = array('filter' => array());
		// filters
		$used_filters = array();
		// first get initial defaults
		$initial_defaults = AnimateGet::initial_defaults($css, $motions['initial']);
		// effects defaults
		$effects_defaults = AnimateGet::effects_defaults();
		// itearte initial defautls and add all used filters to list
		foreach ($initial_defaults as $attribute => $value) {
			if(false !== strpos($attribute, 'filter_') && !in_array($attribute, $used_filters) && intval($value) !== $effects_defaults[$attribute][$attribute]) {
				$used_filters[] = $attribute;
			}
		}
		// iterate all steps and add used filters to list
		foreach ($motions['timeline'] as $key => $animation) {
			$effects = $animation['effects'];
			if(!empty($effects)) {
				foreach ($effects as $effect => $value) {
					if(false !== strpos($effect, 'filter_') && !in_array($effect, $used_filters)) {
						$used_filters[] = $effect;
					}
				}
			}
		}
		// first add defaults to used filters
		foreach ($used_filters as $filter) {
			// add to css
			$css['filter'][$filter] = $initial_defaults[$filter];
		}
		// finally add stepp values
		if($step != 'initial') {
			for($i=0; $i<=$step; $i++) {
				$effects = $motions['timeline'][$i]['effects'];
				$shadow_props = array();
				if(!empty($effects)) {
					foreach ($effects as $effect => $value) {
						if(false !== strpos($effect, 'filter_')) {
							$css['filter'][$effect] = $value;
						}
					}
				}
			}
		}
		return $css['filter'];
	}

	// -----------------------------------------
	// get border width
	// -----------------------------------------

	public static function border_width($styles, $val) {
		$width = $val;
		if(isset($styles['border-direction']) && $styles['border-direction'] != 'all') {
			$directions = array('top' => 0, 'right' => 0, 'bottom' => 0, 'left' => 0);
			$directions[$styles['border-direction']] = $width;
			$width = $directions['top'] . ' ' . $directions['right'] . ' ' . $directions['bottom'] . ' ' . $directions['left'];
		}
		return $width;
	}

	// -----------------------------------------
	// generate initial styles
	// -----------------------------------------

	public static function initial($atts) {
		// initial
		$initial = array();
		// get default styles if available
		$animate_styling = array('opacity', 'background-color', 'border-color', 'border-width', 'border-radius', 'box-shadow-color', 'box-shadow-h-length', 'box-shadow-v-length', 'box-shadow-blur-radius', 'box-shadow-spread-radius', 'box-shadow-opacity');
		foreach ($animate_styling as $key => $attribute) {
			// define val
			$val = false;
			// button module individual
			if(isset($atts['module']) && $atts['module'] == 'button' && isset($atts['options'][$attribute])) {
				$val = $atts['options'][$attribute];
			} else if(isset($atts['styles']['xl'][$attribute])) {
				$val = $atts['styles']['xl'][$attribute];
			}
			// add rem to box shadow values if val true
			if(false !== $val) {
				if(strpos($attribute, 'box-shadow') !== false && strpos($attribute, 'color') === false && strpos($attribute, 'opacity') === false) {
					$initial[$attribute] = ($val / 18) . 'rem';
				} else {
					$initial[$attribute] = $val;
				}
			}
		}
		// ret
		return $initial;
	}
}
new AnimateStyles;
?>