<?php

// namespace
namespace Semplice\Editor;

// use
use Semplice\Helper\Image;
use Semplice\Editor\AnimateStyles;

// -----------------------------------------
// semplice animate get
// -----------------------------------------

class AnimateGet {

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {}

	// -----------------------------------------
	// get selector
	// -----------------------------------------

	public static function selector($id, $atts) {
		$selector = '#content-holder #' . $id;
		$module = isset($atts['module']) ? $atts['module'] : false;
		// exclude from is content
		$exclude = array('advancedportfoliogrid', 'portfoliogrid', 'dribbble', 'instagram', 'gallerygrid', 'video');
		// if module add to selector
		if(strpos($id, 'content_') !== false && !in_array($module, $exclude)) {
			$selector .= ' .is-content';
		}
		// return
		return $selector;
	}

	// -----------------------------------------
	// get bg image url
	// -----------------------------------------

	public static function bg_image_url($styles) {
		// define url
		$url = false;
		// get background image
		if(!empty($styles['background-image'])) {
			if(!isset($styles['background_type']) || $styles['background_type'] != 'vid') {
				$img = Image::get($styles['background-image'], 'full');
				if($img) {
					$url = 'url(' . $img['src'] . ')';
				}
			}
		}
		// return
		return $url;
	}

	// -----------------------------------------
	// get initial defaults
	// -----------------------------------------

	public static function initial_defaults($css, $initial_values) {
		// remove dropshadow
		if(isset($initial_values['filter_drop-shadow'])) {
			unset($initial_values['filter_drop-shadow']);
		}
		$defaults = self::effects_defaults();
		$transform = array('scaleX', 'scaleY', 'translateX', 'translateY', 'translateZ', 'rotate', 'rotateX', 'rotateY', 'skewX', 'skewY');
		foreach ($defaults as $effect_group => $effects) {
			foreach ($effects as $effect => $val) {
				if(!isset($initial_values[$effect])) {
					$initial_values[$effect] = $val;
				}
			}
		}
		return $initial_values;
	}
	// -----------------------------------------
	// get effects defaults
	// -----------------------------------------

	public static function effects_defaults() {
		return array(
			'opacity' => array(
				'opacity' => 1,
			),
			'border' => array(
				'border-color' => '#000000',
				'border-width' => 0,
			),
			'box-shadow' => array(
				'box-shadow-color' => '#000000',
				'box-shadow-h-length' => 0,
				'box-shadow-v-length' => 0,
				'box-shadow-blur-radius' => 0,
				'box-shadow-spread-radius' => 0,
				'box-shadow-opacity' => 1,
			),
			'background-color' => array(
				'background-color' => 'transparent',
			),
			'color' => array(
				'color' => 'transparent',
			),
			'gradient' => array(
				'gradient_applyto' => 'background',
				'gradient_angle' => 0,
				'gradient_color_1' => '#000000',
				'gradient_color_1_opacity' => 0,
				'gradient_color_1_progress' => 0,
				'gradient_color_2' => '#000000',
				'gradient_color_2_opacity' => 0,
				'gradient_color_2_progress' => 100
			),
			'move' => array(
				'translateX' => 0,
				'translateY' => 0,
				'translateZ' => 0
			),
			'rotate' => array(
				'rotate' => 0,
			),
			'rotate3d' => array(
				'rotateX' => 0,
				'rotateY' => 0
			),
			'scale' => array(
				'scaleX' => 1,
				'scaleY' => 1
			),
			'skew' => array(
				'skewX' => 0,
				'skewY' => 0
			),
			'reveal' => array(
				'reveal_x1_hor' => 0,
				'reveal_x1_ver' => 0,
				'reveal_x2_hor' => 100,
				'reveal_x2_ver' => 0,
				'reveal_y1_hor' => 100,
				'reveal_y1_ver' => 100,
				'reveal_y2_hor' => 0,
				'reveal_y2_ver' => 100,
				'reveal_circle_size' => 50,
				'reveal_circle_x' => 50,
				'reveal_circle_y' => 50
			),
			'filter_blur' => array(
				'filter_blur' => 0,
			),
			'filter_brightness' => array(
				'filter_brightness' => 100,
			),
			'filter_contrast' => array(
				'filter_contrast' => 100,
			),
			'filter_grayscale' => array(
				'filter_grayscale' => 0,
			),
			'filter_hue-rotate' => array(
				'filter_hue-rotate' => 0,
			),
			'filter_invert' => array(
				'filter_invert' => 0,
			),
			'filter_saturate' => array(
				'filter_saturate' => 100,
			),
		);
	}

	// -----------------------------------------
	// get gsap element
	// -----------------------------------------

	public static function gsap_element($id, $atts) {
		// vars
		$gsap = array();
		$motions = $atts['motions'];
		$count = 0;
		$repeat = 0;
		// set event
		if(!isset($motions['event'])) {
			$motions['event'] = 'on_load';
		}
		// repeat and loop
		if(isset($motions['loop']) && $motions['loop'] == 'yes') {
			$repeat = -1;
		} else if(isset($motions['repeat'])) {
			$repeat = intval($motions['repeat']) - 1;
		}
		// set basic gsap element
		$gsap = array('repeat' => $repeat, 'timeline' => array(), 'event' => $motions['event']);
		// steps
		$steps = count($motions['timeline']);
		// get gsap set
		$css = AnimateStyles::get('gsap', $atts, $atts['motions'], $id);
		// iterate steps
		foreach ($motions['timeline'] as $key => $animation) {
			// get animation props
			$props = self::animation_props($animation, $id, $atts, $key);
			// add to timeline
			$gsap['timeline'][$count] = array(
				'props' => $props
			);
			// set css
			if(!empty($css)) {
				$gsap['timeline'][$count]['css'] = $css;
			}
			// inc count
			$count++;
		}
		// return gsap
		return $gsap;
	}

	// -----------------------------------------
	// get lottie element
	// -----------------------------------------

	public static function lottie_element($id, $options) {
		// vars
		$event = 'on_load';
		$lottie = array();
		// get event
		if(isset($options['event'])) {
			$event = $options['event'];
		}
		// add to lottie, set repeat to 0 for lottie because looping will get defined in the lottie animation itself, not gsap
		$lottie = array(
			'event' => $event,
			'isLottie' => true,
			'repeat' => 0
		);
		if($event == 'on_scroll') {
			$lottie['options'] = $options;
		} else {
			// add timeline
			$lottie['timeline'][0] = array(
				'props' => array(
					'ease' => 'expo'
				),
				'css' => array(),
			);
		}
		// return lottie
		return $lottie;
	}

	// -----------------------------------------
	// get animation props
	// -----------------------------------------

	public static function animation_props($animation, $id, $atts, $step) {
		// define props
		$props = array();
		$box_shadow_props = array();
		$gradient_props = array();
		$filter_props = array();
		$reveal_props = array();
		$module = isset($atts['module']) ? $atts['module'] : false;
		$styles = $atts['styles']['xl'];
		$bg_image_url = self::bg_image_url($styles);
		// remove bg mage on modules
		if(false !== $module) {
			$bg_image_url = 'none';
		}
		// duration, delay and easing
		$transition_atts = array(
			'duration' => 800,
			'ease' => 'Power1.easeOut',
			'delay' => 0
		);
		// iterate transitions atts
		foreach ($transition_atts as $transition_attr => $value) {
			if(isset($animation[$transition_attr])) {
				$props[$transition_attr] = $animation[$transition_attr];
			} else {
				$props[$transition_attr] = $value;
			}
			// is duration?
			if($transition_attr == 'duration' || $transition_attr == 'delay') {
				$props[$transition_attr] = $props[$transition_attr] / 1000;
			}
		}
		// get bg color outside because it will be overwritten in the props with a mesh gradient bg and we need it later in the styles.background function
		$bg_color = (isset($animation['effects']['background-color'])) ? $animation['effects']['background-color'] : false;
		// iterate effects
		foreach ($animation['effects'] as $attribute => $value) {
			// make sure attr is not a object
			if(!is_array($value)) {
				// rem kommastsellen matchen mit gsap
				if(strpos(strval($value), 'rem') !== false && $attribute != 'filter_drop-shadow') {
					$value = floatval(str_replace('rem', '', $value));
					if($value > 0) {
						$value = number_format($value, 4) . 'rem';
					} else {
						$value .= 'rem';
					}
					// is border width? check direction
					if($attribute == 'border-width') {
						$value = self::border_width($styles, $value);
					}
				}
				// is rotate or skew?
				if(strpos($attribute, 'rotate') !== false || strpos($attribute, 'skew') !== false) {
					// exclude some attributes
					if($attribute != 'filter_hue-rotate') {
						$value = $value . 'deg';
					}
				}
				// add value if not box shadow
				if(strpos($attribute, 'box-shadow') !== false) {
					$box_shadow_props[$attribute] = $value;
				} else if(strpos($attribute, 'gradient') !== false) {
					$gradient_props[$attribute] = $value;
				} else if(strpos($attribute, 'filter') !== false) {
					$filter_props[$attribute] = $value;
				} else if(strpos($attribute, 'reveal') !== false) {
					$reveal_props[$attribute] = $value;
				} else if(strpos($attribute, 'z-index') === false) {
					$props[self::js_attribute($attribute)] = $value;
				}
			} else if($attribute == 'mesh' && isset($animation['effects']['background-color']) && strpos($animation['effects']['background-color'], 'radial-gradient(at') !== false) {
				$props['backgroundColor'] = $value['backgroundColor'];
			}
		}
		// text color
		if(isset($props['color']) && strpos($props['color'], 'gradient') !== false) {
			$props['backgroundImage'] = $props['color'];
			unset($props['color']);
		}
		// get box shadow
		$box_shadow = AnimateStyles::box_shadow($box_shadow_props, $module);
		// add box shadow to css
		if(false !== $box_shadow) {
			if($module == 'text' || $module == 'paragraph') {
				$props['textShadow'] = $box_shadow;
			} else {
				$props['boxShadow'] = $box_shadow;
			}
		}
		// gradient
		if($bg_color) {
			$props = AnimateStyles::background('props', $bg_color, $bg_image_url, $props);
		}
		// for css filters we need to add the initial filter value if changed since we overwrite the css values else
		$filter_state = AnimateStyles::get_filter_state($atts['motions'], $step);
		if(false !== $filter_state && is_array($filter_state) && !empty($filter_state)) {
			foreach ($filter_state as $filter => $value) {
				// add to filter props but only if its not already in as an effect
				if(!isset($filter_props[$filter])) {
					$filter_props[$filter] = $value;
				}
			}
		}
		// get filter
		$filter = AnimateStyles::filter($filter_props);
		// add filter to css
		if(false !== $filter && !empty($filter)) {
			$props['filter'] = $filter;
		}
		// get reveal
		$reveal = AnimateStyles::reveal($reveal_props, $atts['motions']['initial']);
		// add reveal to css
		if(false !== $reveal && !empty($reveal)) {
			$props['clipPath'] = $reveal;
		}
		// return props
		return $props;
	}

	// -----------------------------------------
	// get border width
	// -----------------------------------------

	public static function border_width($styles, $val) {
		$width = $val;
		if(isset($styles['border-direction']) && $styles['border-direction'] != 'all') {
			$directions = array('top' => 0, 'right' => 0, 'bottom' => 0, 'left' => 0);
			$directions[$styles['border-direction']] = $width;
			$width = $directions['top'] . ' ' . $directions['right'] . ' ' . $directions['bottom'] . ' ' . $directions['left'];
		}
		return $width;
	}

	// -----------------------------------------
	// get js attribute
	// -----------------------------------------

	public static function js_attribute($attribute) {
		// js atts
		$js_atts = array(
			'opacity' => 'opacity',
			'translateX' => 'x',
			'translateY' => 'y',
			'translateZ' => 'z',
			'scaleX' => 'scaleX',
			'scaleY' => 'scaleY',
			'skewX' => 'skewX',
			'skewY' => 'skewY',
			'rotate' => 'rotation',
			'rotateX' => 'rotateX',
			'rotateY' => 'rotateY',
			'background-color' => 'backgroundColor',
			'color' => 'color',
			'border-color' => 'borderColor',
			'border-width' => 'borderWidth',
			'border-radius' => 'borderRadius',
			'duration' => 'duration',
			'easing' => 'easing'
		);
		// return
		return $js_atts[$attribute];
	}

	// -----------------------------------------
	// perspective
	// -----------------------------------------

	public static function perspective($motions) {
		$perspective = false;
		$initial = (isset($motions['initial'])) ? $motions['initial'] : false;
		// is set?
		if($initial && isset($initial['use_perspective']) && $initial['use_perspective'] == 'enabled') {
			$perspective = (isset($initial['perspective'])) ? $initial['perspective'] : 500;
		}
		// return
		return $perspective;
	}

	// -----------------------------------------
	// get z index
	// -----------------------------------------

	public static function zindex($atts, $id) {
		$selector = '#' . $id;
		if(strpos($id, 'section_') !== false || strpos($id, 'cover') !== false) {
			$selector = '.sp_' . $id;
		}
		if(isset($atts['styles']['xl']) && isset($atts['styles']['xl']['z-index'])) {
			$z_index = $atts['styles']['xl']['z-index'];
			if(is_numeric($z_index)) {
				return 'gsap.set("' . $selector . '", {zIndex: "' . $z_index . '"});';
			}
		}
	}
}
new AnimateGet;
?>