<?php

// namespace
namespace Semplice\Editor\Types;

// use
use Semplice\Editor;
use Semplice\Editor\EditorStyles;
use Semplice\Editor\Components;

// -----------------------------------------
// semplice subrow
// -----------------------------------------

class Subrow extends Editor {

	// -----------------------------------------
	// init content
	// -----------------------------------------

	public static function init($id, $ram) {
		// subrow
		$subrow = $ram[$id];
		$layout_atts = '';
		// styles and layout atts for the frontend
		if(!self::$is_editor) {
			// styles
			self::$output['css'] .= EditorStyles::get('subrow', $subrow['styles'], $id, false);
			// layout atts
			if(!empty($subrow['layout'])) {
				$layout_atts = 'data-layout=\'' . json_encode($subrow['layout']) . '\' ';
			}
		}
		// output
		self::$output['html'] .= '<smp-subrow id="' . $id . '"' . $layout_atts . Components::name($subrow) . self::link($subrow) .  '>';
	}
}

// instance
Editor::$types['subrow'] = new Subrow;
?>