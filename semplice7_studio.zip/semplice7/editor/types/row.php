<?php

// namespace
namespace Semplice\Editor\Types;

// use
use Semplice\Editor;

// -----------------------------------------
// semplice row
// -----------------------------------------

class Row extends Editor {

	// -----------------------------------------
	// init row
	// -----------------------------------------

	public static function init($id, $ram) {
		// output
		self::$output['html'] .= '<smp-row id="' . $id . '">';
	}
}

// instance
Editor::$types['row'] = new Row;
?>