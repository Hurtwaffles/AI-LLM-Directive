<?php

// namespace
namespace Semplice\Editor\Types;

// use
use Semplice\Editor;
use Semplice\Helper\Basic;
use Semplice\Editor\Components;
use Semplice\Editor\EditorStyles;

// -----------------------------------------
// semplice content
// -----------------------------------------

class Content extends Editor {

	// -----------------------------------------
	// init content
	// -----------------------------------------

	public static function init($id, $ram) {
		// first is for duplicate which is never a component
		$content = (isset($ram['module'])) ? $ram : $ram[$id];
		// vars
		$module = $content['module'];
		$styles = $content['styles']['xl'];
		$css_classes = '';
		// css classes
		if(isset($content['classes']) && !empty($content['classes'])) {
			$css_classes .= ' ' . $content['classes'];
		}
		// locked content
		if(isset($content['locked']) && Basic::boolval($content['locked'])) {
			$css_classes .= ' locked-content';
		}
		$css_classes = (!empty($css_classes)) ? ' class="' . substr($css_classes, 1) . '" ' : ' ';
		// merge local options
		$content = self::local_options($module, $content);
		// make sure the module is available
		if(isset(self::$modules[$module])) {
			// visibility
			if(self::$is_editor) {
				$module_content = self::$modules[$module]->editor($id, $content);
			} else {
				$module_content = self::$modules[$module]->frontend($id, $content);
			}
		} else {
			$module_content = self::missing_module($module);
		}
		// styles
		if(!self::$is_editor) {
			self::$output['css'] .= EditorStyles::get('content', $content['styles'], $id, $module);
		}
		// add bg image to images array
		self::images_array($styles);
		// css
		$css = (!empty($module_content['css'])) ? $module_content['css'] : '';
		// module css betrifft nur module die im editor die html struktur ändern können (z.b. apg grid preset, gallery cover mode, blog layout)
		$module_css = array('blogposts', 'gallery', 'advancedportfoliogrid');
		if(in_array($module, $module_css) && self::$is_editor) {
			if(!isset(self::$output['module_css'][$module])) {
				self::$output['module_css'][$module] = array();
			}
			self::$output['module_css'][$module][$id] = $css;
		} else {
			self::$output['css'] .= $css;
		}
		// output
		self::$output['html'] .= '<smp-content id="' . $id . '"' . $css_classes . Components::name($content) . ' data-module="' . $module . '" ' . Editor::get_attributes(self::atts($content)) . self::link($content) .  '>' . $module_content['html'] . '</smp-content>';
	}

	// -----------------------------------------
	// merge local optins
	// -----------------------------------------

	public static function local_options($module, $content) {
		// has local options?
		if(isset($content['local']) && !empty($content['local'])) {
			// switch module
			switch($module) {
				case 'button':
					$content['options'] = array_merge($content['options'], $content['local']);
				break;
			}
		}
		// return content
		return $content;
	}

	// -----------------------------------------
	// get module atts
	// -----------------------------------------

	public static function atts($content) {
		$atts = array();
		// add css classes for individual modules
		switch($content['module']) {
			case "advancedportfoliogrid":
				// get preset
				$preset = 'horizontal-fullscreen';
				if(isset($content['options']['preset']) && !empty($content['options']['preset'])) {
					$preset = $content['options']['preset'];
				}
				$atts['data-apg-preset'] = $preset;
			break;
		}
		// return
		return $atts;
	}

	// -----------------------------------------
	// missing module
	// -----------------------------------------

	public static function missing_module($module) {
		return array(
			'html' => '<div class="missing-module"><span>Missing Module</span> The ' . $module . ' module got removed from Semplice.</div>',
			'css'  => ''
		);
	}
}

// instance
Editor::$types['content'] = new Content;
?>