<?php

// namespace
namespace Semplice\Editor\Types;

// use
use Semplice\Editor;
use Semplice\Editor\Components;
use Semplice\Editor\EditorStyles;
use Semplice\Helper\Basic;
use Semplice\Helper\Image;
use Semplice\Helper\Background;
use Semplice\Helper\Get;

// -----------------------------------------
// semplice section
// -----------------------------------------

class Section extends Editor {

	// -----------------------------------------
	// init section
	// -----------------------------------------

	public static function init($id, $ram) {
		// shortcuts
		$section = $ram[$id];
		$styles = $section['styles']['xl'];
		$layout = $section['layout'];
		//var_dump($component);
		// vars
		$css_classes = '';
		$video = array('section' => '', 'container' => '');
		// css classes
		if(isset($section['classes']) && !empty($section['classes'])) {
			$css_classes .= ' ' . $section['classes'];
		}
		if(isset($section['type']) && $section['type'] == 'section-module') {
			$css_classes .= ' section-module';
		}
		if(isset($section['locked']) && Basic::boolval($section['locked'])) {
			$css_classes .= ' locked-section';
		}
		$css_classes = (!empty($css_classes)) ? ' class="' . substr($css_classes, 1) . '" ' : ' ';
		// section height
		self::$output['css'] .= (isset($layout['data-height']) && $layout['data-height'] == 'custom') ? EditorStyles::get('container', $section['customHeight'], $id, false) : '';
		// section visibility
		self::visibility($id, $section);
		// add bg image to images array
		self::images_array($styles);
		// container styles
		if(isset($section['containerStyles'])) {
			$con_styles = $section['containerStyles']['xl'];
			// add background image to images array
			if(isset($con_styles['background-image'])) {
				self::$output['images'][$con_styles['background-image']] = Image::get($con_styles['background-image'], 'full');
			}
			// styles for the frontend
			if(!self::$is_editor) {
				self::$output['css'] .= EditorStyles::get('container', $section['containerStyles'], $id, true);
			}
			// get background video
			if(self::has_bg_video($con_styles)) {
				$video['container'] = '<smp-bg-video>' . Background::video($con_styles, self::$is_editor, true) . '</smp-bg-video>';
				self::$output['css'] .= Background::video_fallback_css($con_styles, $id, self::$is_editor, true);
			}
		}
		// section styles
		self::$output['css'] .= EditorStyles::get('section', $section['styles'], $id, false);
		// get section background video
		if(self::has_bg_video($styles)) {
			$video['section'] = '<smp-bg-video>' . Background::video($styles, self::$is_editor, true) . '</smp-bg-video>';
			self::$output['css'] .= Background::video_fallback_css($styles, $id, self::$is_editor, false);
		}
		// output
		self::$output['html'] .= '
			<smp-section id="' . $id . '"' . $css_classes . Components::name($section) . self::get_attributes($layout) . self::link($section) .  '>
				' . $video['section'] . '
				<smp-container>
					' . $video['container'] . '
		';
	}

	// -----------------------------------------
	// frontend visibility
	// -----------------------------------------

	public static function visibility($id, $section) {
		// visibility on frontend
		if(!self::$is_editor) {
			$breakpoints = Get::breakpoints(true);
			foreach ($breakpoints as $bp => $width) {
				$hidden = false;
				if($bp == 'xl' && isset($section['options']['desktop_visibility']) && $section['options']['desktop_visibility'] == 'hidden') {
					$hidden = true;
				} else if(isset($section['layout']['data-' . $bp . '-visibility']) && $section['layout']['data-' . $bp . '-visibility'] == 'hide') {
					$hidden = true;
				}
				// is hidden?
				if($hidden) {
					self::$output['css'] .= '@media screen' . $width['min'] . $width['max'] . ' { #' . $id . ' { display: none !important; }}';
				}
			}
		}
	}
}

// instance
Editor::$types['section'] = new Section;
?>