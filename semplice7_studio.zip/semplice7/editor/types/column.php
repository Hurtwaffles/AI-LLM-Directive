<?php

// namespace
namespace Semplice\Editor\Types;

// use
use Semplice\Editor;
use Semplice\Editor\Components;
use Semplice\Editor\EditorStyles;
use Semplice\Helper\Basic;
use Semplice\Helper\Image;
use Semplice\Helper\Background;
use Semplice\Helper\Get;

// -----------------------------------------
// semplice column
// -----------------------------------------

class Column extends Editor {

	// -----------------------------------------
	// init column
	// -----------------------------------------

	public static function init($id, $ram) {
		// vars
		$column = $ram[$id];
		$styles = $column['styles']['xl'];
		$html = array(
			'head'         => '',
			'width'	       => '',
			'classes'      => '',
			'video' 	   => '',
			'wrapperVideo' => ''
		);
		// css classes
		if(isset($column['classes']) && !empty($column['classes'])) {
			$html['classes'] .= ' ' . $column['classes'];
		}
		if(isset($column['type']) && $column['type'] == 'spacer') {
			$html['classes'] .= ' spacer-column';
		}
		if(isset($column['locked']) && Basic::boolval($column['locked'])) {
			$html['classes'] .= ' locked-column';
		}
		$html['classes'] = (!empty($html['classes'])) ? ' class="' . substr($html['classes'], 1) . '" ' : ' ';
		// column width
		foreach ($column['width'] as $width => $value) {
			if(!empty($width)) {
				$html['width'] .= 'data-' . $width . '-width="' . $value . '" ';
			}
		}
		// add bg image to images array
		self::images_array($styles);
		// only append styles css for the frontend
		if(!self::$is_editor) {
			self::$output['css'] .= EditorStyles::get('column', $column['styles'], $id, false);
		} else {
			$html['head'] = '<div class="move-column"></div>';
		}
		// get column background video
		if(self::has_bg_video($styles)) {
			$html['video'] = '<smp-bg-video>' . Background::video($styles, self::$is_editor, true) . '</smp-bg-video>';
			self::$output['css'] .= Background::video_fallback_css($styles, $id, self::$is_editor, false);
		}
		// content wrapper styles
		if(isset($column['wrapperStyles'])) {
			// shortcut
			$wrapper_styles = $column['wrapperStyles']['xl'];
			// add bg image to images array
			self::images_array($wrapper_styles);
			// only append styles css for the frontend
			if(!self::$is_editor) {					
				self::$output['css'] .= EditorStyles::get('contentWrapper', $column['wrapperStyles'], $id, false);
			}
			// get column background video
			if(self::has_bg_video($wrapper_styles)) {
				$html['wrapperVideo'] = '<smp-bg-video>' . Background::video($wrapper_styles, self::$is_editor, true) . '</smp-bg-video>';
				self::$output['css'] .= Background::video_fallback_css($wrapper_styles, $id, self::$is_editor, false);
			}
		}
		// output
		self::$output['html'] .= '
			<smp-column id="' . $id . '"' . $html['classes'] . rtrim($html['width'], ' ') . Components::name($column) . self::get_attributes($column['layout']) . self::link($column) . '>
				' . $html['head'] . '
				' . $html['video'] . '
				<smp-content-wrapper>
					' . $html['wrapperVideo'] . '
		';
	}
}

// instance
Editor::$types['column'] = new Column;
?>