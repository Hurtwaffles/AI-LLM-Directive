<?php

// namespace
namespace Semplice\Editor\Types;

// use
use Semplice\Editor;
use Semplice\Editor\EditorStyles;
use Semplice\Helper\Get;
use Semplice\Helper\Covers;
use Semplice\Helper\Image;
use Semplice\Helper\Background;

// -----------------------------------------
// semplice cover
// -----------------------------------------

class Cover extends Editor {

	// -----------------------------------------
	// init cover
	// -----------------------------------------

	public static function init($id, $ram) {
		// vars
		$visibility = isset($ram['cover_visibility']) ? $ram['cover_visibility'] : 'hidden';
		$element_id = $id;
		// get cover
		if(isset($ram[$element_id])) {
			// shortcut
			$cover = $ram[$element_id];
			// styles
			$styles = $cover['styles']['xl'];
			// empty cover class
			$empty_cover = self::empty($ram['order'][$element_id]);
			// frontend only options
			if(!self::$is_editor) {
				// start at top
				self::$output['css'] .= '@media screen and (min-width: 1170px) { #content-holder .sections { margin-top: 0px !important; }}';
				// on the frontend, change the section element id to avoid problems in the coverslider and single page app motions
				$element_id = 'cover-' . self::$post_id;
			}
			// section visibility
			self::visibility($element_id, $cover);
			// add bg image to images array
			self::images_array($styles);
			// cover media
			$cover_media = '<smp-cover-image' . self::parallax($ram) . '></smp-cover-image>';
			// get bg video or image if not editor (for editor css will be done in the inline styles)
			if(self::has_bg_video($styles)) {
				// get bg video html and css
				$cover_media = '<smp-bg-video' . self::parallax($ram) . '>' . Background::video($styles, self::$is_editor, true) . '</smp-bg-video>';
				self::$output['css'] .= Background::video_fallback_css($styles, $element_id, self::$is_editor, false);
			} else if(!self::$is_editor) {
				// is tilt scale set?
				if(isset($styles['mousemove_effect']) && $styles['mousemove_effect'] == 'tilt') {
					// set default perspective
					if(!empty($styles['tilt_perspective'])) {
						self::$output['css'] .= '#content-holder ' . $element_id . ' smp-cover-inner { transform: translateZ(0) perspective(' . $styles['tilt_perspective'] . 'px); }';
					}
					// image scale
					if(!empty($styles['tilt_scale'])) {
						self::$output['css'] .= '#content-holder ' . $element_id . ' smp-cover-media-wrapper { transform: scale(' . ($styles['tilt_scale'] / 100) . ') !important; }';
					}
				}
				// get cover image css
				self::$output['css'] .= EditorStyles::get('cover', $cover['styles'], $element_id, false);
				// get cover effects
				$cover['layout'] = self::effects($styles, $cover['layout']);
			} 
			// output
			self::$output['html'] .= '
				<smp-section id="' . $element_id . '" class="semplice-cover' . $empty_cover . '" data-cover="' . $visibility . '"' . self::get_attributes($cover['layout']) . self::link($cover) .  '>
					<smp-cover-inner' . self::effects_settings($styles) . '>
						' . self::arrow($styles) . '
						<smp-cover-media-wrapper>' . $cover_media . '</smp-cover-media-wrapper>
						<smp-container>
			';
		} else if(self::$is_editor) {
			// default cover on editor
			self::$output['html'] .= Covers::default($visibility);
		}
	}

	// -----------------------------------------
	// get empty cover class
	// -----------------------------------------

	public static function empty($cover) {
		$first_key = key($cover);
		if(isset($cover['columns']) && empty($cover['columns']) || isset($cover[$first_key]['columns']) && empty($cover[$first_key]['columns'])) {
			return ' is-empty-cover';
		}
	}

	// -----------------------------------------
	// get cover arrow
	// -----------------------------------------

	public static function arrow($styles) {
		// arrow atts
		$visibility = isset($styles['arrow_visibility']) ? $styles['arrow_visibility'] : 'visible';
		$custom = isset($styles['arrow_cover']) ? $styles['arrow_cover'] : false;
		$width = isset($styles['arrow_width']) ? $styles['arrow_width'] : '2.9444rem';
		// add width to css
		self::$output['css'] .= '#content-holder .semplice-cover .show-more svg, #content-holder .semplice-cover .show-more img { width: ' . $width . '; }';
		// is custom arrow?
		if($custom) {
			$image = '<img src="' . Image::src($custom, 'full') . '" alt="custom-cover-arrow">';
		} else {
			$image = Get::svg('frontend', 'arrows/arrow_down');
			// add color css
			if(isset($styles['arrow_color'])) {
				self::$output['css'] .= '#content-holder .semplice-cover .show-more svg { fill: ' . $styles['arrow_color'] . '; }';
			}
		}
		// arrow output
		return '<a class="show-more show-more-' . $visibility . ' click-handler" data-handler="run" data-action-type="helper" data-setting-type="animate" data-action="scrollToContent">' . $image . '</a>';
	}

	// -----------------------------------------
	// cover effects
	// -----------------------------------------

	public static function effects($styles, $layout) {
		// backwards compatibility for older effects structure. Check if effect is set, if not look if older effects are already set
		if(isset($styles['image_effect'])) {
			$layout['data-cover-effect'] = $styles['image_effect'];
		} else if(isset($styles['zoom']) && $styles['zoom'] == 'on') {
			$layout['data-cover-effect'] = 'zoom';
		} else if(isset($styles['parallax']) && $styles['parallax'] == 'on') {
			$layout['data-cover-effect'] = 'parallax';
		}
		// mouse move effects
		if(isset($styles['mousemove_effect'])) {
			$layout['data-cover-mousemove'] = $styles['mousemove_effect'];
		}
		// return
		return $layout;
	}

	// -----------------------------------------
	// get cover effects setting
	// -----------------------------------------

	public static function effects_settings($styles) {
		// output
		$output = array();
		// settings
		$settings = array('tilt_scale', 'tilt_max', 'tilt_perspective');
		// iterate settings
		foreach ($settings as $setting) {
			if(isset($styles[$setting])) {
				$output[$setting] = $styles[$setting];
			}
		}
		// output
		return ' data-effect-settings=\'' . json_encode($output) . '\'';
	}

	// -----------------------------------------
	// parallax for the coverslide
	// -----------------------------------------

	public static function parallax($ram) {
		// check if parallax is enabled
		if(isset($ram['coverslider']) && isset($ram['coverslider']['parallax']) && $ram['coverslider']['parallax'] == 'enabled') {
			$offset = (isset($ram['coverslider']['parallax_offset'])) ? $ram['coverslider']['parallax_offset'] : '60';
			return ' data-swiper-parallax="' . $offset . '%"';
		}
	}

	// -----------------------------------------
	// frontend visibility
	// -----------------------------------------

	public static function visibility($id, $cover) {
		// visibility on frontend
		if(!self::$is_editor) {
			$breakpoints = Get::breakpoints(true);
			foreach ($breakpoints as $bp => $width) {
				$hidden = false;
				if(isset($cover['layout']['data-' . $bp . '-visibility']) && $cover['layout']['data-' . $bp . '-visibility'] == 'hide') {
					$hidden = true;
				}
				// is hidden?
				if($hidden) {
					self::$output['css'] .= '@media screen' . $width['min'] . $width['max'] . ' { #' . $id . ' { display: none !important; }}';
				} else {
					self::$output['css'] .= '@media screen' . $width['min'] . $width['max'] . ' { #content-holder .sections { margin-top: 0px !important; }}';
				}
			}
		}
	}
}

// instance
Editor::$types['cover'] = new Cover;
?>