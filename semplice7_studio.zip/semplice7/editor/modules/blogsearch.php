<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Helper\Get;
use Semplice\Helper\Color;

// -----------------------------------------
// module
// -----------------------------------------

class BlogsearchModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// extract options
		extract( shortcode_atts(
			array(
				'placeholder'					=> 'Search posts',
				'color'							=> '#000000',
				'bg_color' 						=> '#f5f5f5',
				'placeholder_color'				=> '#999999',
				'font_family'					=> 'inter_regular',
				'font_size'						=> '0.8888888888888889rem',
				'letter_spacing'				=> '0rem',
				'padding_ver'					=> '0.8888888888888889rem',
				'padding_hor'					=> '1.111111111111111rem',
				'icon_padding'					=> '1.111111111111111rem',
				'icon_color'					=> '#aaaaaa',
				'mouseover_color'				=> '#000000',
				'placeholder_mouseover_color'	=> '#666666',
				'bg_mouseover_color'			=> '#e9e9e9',
				'icon_mouseover_color'			=> '#666666'
			), $values['options'] )
		);
		// define output
		$output = $this->form($font_family, $placeholder);
		// search field
		$css = '#' . $id . ' .search-field {
				color: ' . $color . ';
				' . Color::bg_css($bg_color, self::$is_editor, true) . '
				font-size: ' . $font_size . ';
				letter-spacing: ' . $letter_spacing . ';
				padding: ' . $padding_ver . ' ' . $padding_hor . ';
			}
			#' . $id . ' .blogsearch-icon {
				right: ' . $icon_padding. ';
			}
			#' . $id . ' .blogsearch-icon svg {
				fill: ' . $icon_color. ';
			}
			#' . $id . ' .search-field:hover,
			#' . $id . ' .search-field:focus {
				color: ' . $mouseover_color . ';
				' . Color::bg_css($bg_mouseover_color, self::$is_editor, true) . '
			}
			#' . $id . ' .search-form:hover .blogsearch-icon svg {
				fill: ' . $icon_mouseover_color . ';
			}
			#' . $id . ' input::placeholder {
				color: ' . $placeholder_color . ';
			}
			#' . $id . ' input:hover::placeholder,
			#' . $id . ' input:focus::placeholder {
				color: ' . $placeholder_mouseover_color . ';
			}
		';
		// get breakpoint css
		$css .= $this->breakpoint_css($values['options'], '[data-breakpoint="##breakpoint##"] #' . $id, $padding_ver, $padding_hor);
		// gradient mouseover on frontend
		if(!self::$is_editor) {
			$css .= Color::gradient_mouseover('#content-holder #' . $id . ' .search-field', $bg_color, $bg_mouseover_color, true);
			// add transition
			if(!empty($css)) {
				$css .= '#' . $id . ' .search-field { transition: ' . Color::gradient_vars('.75', '--ease-out-expo') . '; }';
			}
		}
		// add to html output
		$this->module['html'] = $output;
		// add to css output
		$this->module['css'] = $css;
		// output
		return $this->module;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// same as editor
		return $this->editor($id, $values);
	}

	// -----------------------------------------
	// breakpoint css
	// -----------------------------------------

	public function breakpoint_css($styles, $selector, $padding_ver, $padding_hor) {
		// output css
		$output_css = '';
		// get breakpoints
		$breakpoints = Get::breakpoints(false);
		// iterate breakpoints
		foreach ($breakpoints as $breakpoint => $width) {
			// css
			$css = '';
			// font size
			if(isset($styles['font_size_' . $breakpoint])) {
				$css .= $selector . ' .search-field { font-size: ' . $styles['font_size_' . $breakpoint] . '; }';
			}
			// letter spacing
			if(isset($styles['letter_spacing_' . $breakpoint])) {
				$css .= $selector . ' .search-field { letter-spacing: ' . $styles['letter_spacing_' . $breakpoint] . '; }';
			}
			// icon padding
			if(isset($styles['icon_padding_' . $breakpoint])) {
				$css .= $selector . ' .blogsearch-icon { right: ' . $styles['icon_padding_' . $breakpoint] . '; }';
			}
			// padding ver
			if(isset($styles['padding_ver_' . $breakpoint])) {
				$padding_ver = $styles['padding_ver_' . $breakpoint];
			}
			// padding hor
			if(isset($styles['padding_hor_' . $breakpoint])) {
				$padding_hor = $styles['padding_hor_' . $breakpoint];
			}
			// set padding
			$css .= $selector . ' .search-field { padding: ' . $padding_ver . ' ' . $padding_hor . '; }';			
			// add to css output
			if(!empty($css)) {
				if(self::$is_editor) {
					$output_css .= str_replace('##breakpoint##', $breakpoint, $css);
				} else {
					$output_css .= '@media screen' . $width['min'] . $width['max'] . ' { ' . str_replace('[data-breakpoint="##breakpoint##"] ', '', $css) . '}';
				}
			}
		}
		// return
		return $output_css;
	}

	// -----------------------------------------
	// search form
	// -----------------------------------------

	function form($font_family, $placeholder) {
		return '
			<form role="search" method="get" class="search-form blogposts-search is-content" action="' . esc_url(home_url('/')) . '">
				<input type="search" class="search-field" placeholder="' . $placeholder . '" name="s" data-font="' . $font_family . '" />
				<span class="blogsearch-icon">' . Get::svg('editor', 'blog/search') . '</span>
				<input type="submit" class="search-submit" value="" />
			</form>
		';
	}
}

// instance
Editor::$modules['blogsearch'] = new BlogsearchModule;
?>