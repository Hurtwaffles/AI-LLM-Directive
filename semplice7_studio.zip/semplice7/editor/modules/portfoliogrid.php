<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Editor\Placeholder;
use Semplice\Admin\Customize;
use Semplice\Helper\Color;
use Semplice\Helper\Basic;
use Semplice\Helper\Get;
use Semplice\Helper\Image;
use Semplice\Helper\Masonry;
use Semplice\Helper\PostQueries;
use Semplice\Helper\Styles;

// -----------------------------------------
// module
// -----------------------------------------

class PortfoliogridModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// is editor
		self::$is_editor = (NULL == self::$is_editor) ? true : self::$is_editor;
		// module
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// css output
		$styles = array(
			'css' => '',
			'mobile_css' => array(
				'lg' => '',
				'md' => '',
				'sm' => '',
				'xs' => '',
			),
		);
		// extract options
		extract( shortcode_atts(
			array(
				'project_display'			=> 'default',
				'limit'						=> 20,
				'lazy_load_initial'			=> 20,
				'lazy_load_per_load'		=> 20,
				'lazy_load_button'			=> SEMPLICE_URI . '/assets/images/frontend/portfoliogrid/load-more.svg',
				'lazy_load_button_width'	=> '3.333333333333333rem',
				'lazy_load_padding_top'		=> '2.222222222222222rem',
				'lazy_load_padding_bottom'	=> '5.555555555555556rem',
				'categories'				=> '',
				'hor_gutter'				=> 30,
				'ver_gutter'				=> 30,
				'corner_radius'				=> 0,
				'title_visibility'			=> 'both',
				'title_position'			=> 'below',
				'title_padding'				=> '1rem',
				'title_color'				=> '#000000',
				'title_fontsize'			=> '16px',
				'title_font'				=> 'regular',
				'title_text_transform'		=> 'none',
				'category_color'			=> '#999999',
				'category_fontsize'			=> '14px',
				'category_font'				=> 'regular',
				'category_text_transform'	=> 'none',
				'category_padding_top'		=> '0.4444444444444444rem',
				'filter_alignment'			=> 'flex-end',
				'filter_showall'			=> 'Show All',
				'filter_color'				=> '#bbbbbb',
				'filter_color_active'		=> '#000000',
				'filter_fontsize'			=> '1.111111111111111rem',
				'filter_font'				=> 'regular',
				'filter_text_transform'		=> 'none',
				'filter_padding'			=> '1.555555555555556rem',
				'filter_item_padding'		=> '1.555555555555556rem',
				'filter_letter_spacing'		=> '0',
				'filter_text_decoration'	=> 'none',
				'filter_mobile_visibility'	=> 'visible',
			), $values['options'])
		);
		// get portfolio order
		$portfolio_order = json_decode(get_option('semplice_portfolio_order'));
		// limit and lazy load
		$limit_num = -1;
		if($project_display == 'limit' && $limit > 0) {
			$limit_num = $limit;
		} else if($project_display == 'lazy_load') {
			$limit_num = $lazy_load_initial;
			// add button width
			$styles['css'] .= '.semplice-load-more { width: ' . $lazy_load_button_width . '; padding: ' . $lazy_load_padding_top . ' 0 ' . $lazy_load_padding_bottom . '; }';
			$values['options']['lazy_load'] = array(
				'start_offset'  => $lazy_load_initial,
				'per_load' 		=> $lazy_load_per_load,
				'button'		=> $lazy_load_button,
			);
		}
		// get projects
		$projects = PostQueries::get_projects($portfolio_order, $categories, $limit_num, false, false, 'publish');
		// count projects and add it to the options values
		$values['options']['count'] = count($projects);
		// get thumb hover options
		$global_hover_options = Basic::customize('thumbhover');
		// change title position to below if visibility is hidden
		if($title_visibility == 'hidden') {
			$title_position = 'below';
		}
		// show filter
		$filter_output = '';
		if($project_display == 'category') {
			// open filter
			$filter_output .= '<nav class="pg-category-filter" data-mobile-visibility="' . $filter_mobile_visibility . '"><ul class="masonry-filter">';
			// show all
			$filter_output .= '<li><a class="click-handler pg-filter-active" data-handler="run" data-action-type="masonry" data-action="filter" data-category="show-all" data-font="' . $filter_font . '" data-masonry-element="#masonry-' . $id . '">' . $filter_showall . '</a></li>';
			// if not categories get all categories
			if(!is_array($categories) || empty($categories)) {
				// category ids
				$category_ids = array();
				// get categories
				$categories = get_terms('category','hide_empty=0');
				// iterate categories to get the right format
				foreach ($categories as $index => $category) {
					$category_ids[$index] = $category->term_id;
				}
				// define filter categories
				$categories = $category_ids;
			}
			// iterate categories and add to filter
			foreach ($categories as $category_id) {
				$filter_output .= '<li><a class="click-handler" data-handler="run" data-action-type="masonry" data-action="filter" data-font="' . $filter_font . '" data-category="' . $category_id . '" data-masonry-element="#masonry-' . $id . '">' . get_cat_name($category_id) . '</a></li>';
			}
			// end filter
			$filter_output .= '</ul></nav>';
			// css defaults
			$values['options']['filter_alignment'] = $filter_alignment;
			$values['options']['filter_padding'] = $filter_padding;
			$values['options']['filter_item_padding'] = $filter_item_padding;
			$values['options']['filter_fontsize'] = $filter_fontsize;
			$values['options']['filter_letter_spacing'] = $filter_letter_spacing;
			// get filter css
			$selector = '[data-breakpoint="##breakpoint##"] #content-holder #' . $id . ' nav ul';
			$styles = Styles::css($selector, 'filter_alignment', array('justify-content'), $values['options'], false, false, $styles);
			$styles = Styles::css($selector, 'filter_padding', array('padding-bottom'), $values['options'], false, false, $styles);
			$styles = Styles::css($selector . ' li a', 'filter_item_padding', array('padding-right'), $values['options'], false, false, $styles);
			$styles = Styles::css($selector . ' li a', 'filter_fontsize', array('font-size'), $values['options'], false, false, $styles);
			$styles = Styles::css($selector . ' li a', 'filter_letter_spacing', array('letter-spacing'), $values['options'], false, false, $styles);
			// remove breakpoint prefix for desktop styles
			$styles['css'] = str_replace('[data-breakpoint="##breakpoint##"] ', '', $styles['css']);
		}
		// are there any published projects
		if(!empty($projects)) {
			// get masonry items
			$atts = array(
				'global_hover_options' => $global_hover_options,
				'title_visibility' => $title_visibility,
				'title_position' => $title_position,
				'category_font' => $category_font,
				'category_color' => $category_color,
				'title_font' => $title_font,
				'title_color' => $title_color
			);
			// gutter numeric?
			if(!is_numeric($hor_gutter)) { $hor_gutter = 30; }
			if(!is_numeric($ver_gutter)) { $ver_gutter = 39; }
			// masonry items
			$masonry_items = '';
			foreach ($projects as $key => $project) {
				// get masonry items
				$masonry_items .= $this->masonry_items($id, $project, $atts, self::$is_editor, '');
				// thumb hover css if custom thumb hover is set
				if(isset($project['thumb_hover'])) {
					$styles['css'] .= Customize::$setting['thumbhover']->css('project-' . $project['post_id'], $project['thumb_hover'], false, '#content-holder', self::$is_editor);
				}
			}
			// get title css
			$styles = $this->title_corner_css($id, $values, $styles);
			// add filter format
			$styles['css'] .= '
				#content-holder #' . $id . ' nav ul li a {
					color: ' . $filter_color . ';
					text-transform: ' . $filter_text_transform . ';
				}
				#content-holder #' . $id . ' nav ul li a:hover,
				#content-holder #' . $id . ' nav ul li a.pg-filter-active {
					color: ' . $filter_color_active . ';
					text-decoration: ' . $filter_text_decoration . ';
				}
			';
			// add gutters to css
			$styles['css'] .= Masonry::css($id, $values['options'], false, self::$is_editor, $hor_gutter, $ver_gutter, true);
			// add css
			$this->module['css'] = $styles['css'];
			// get masonry
			$this->module['html'] = $filter_output . Masonry::html('portfoliogrid', $id, $values['options'], $masonry_items, self::$is_editor, false); //$values['script_execution'] is last normally
		} else {
			$this->module['html'] = Placeholder::get('portfoliogrid', $id, false, self::$is_editor, false);
		}
		// output
		return $this->module;
	}

	// -----------------------------------------
	// output frontend 
	// -----------------------------------------

	public function frontend($id, $values) {
		return $this->editor($id, $values);
	}

	// -----------------------------------------
	// get title
	// -----------------------------------------

	public function title($atts, $project) {
		// define title
		$title = '';
		// title visibility
		if($atts['title_visibility'] == 'both') {
			$title = '
				<div class="post-title ' . $atts['title_font'] . '"><div class="pt-title"' . Color::has_gradient($atts['title_color'], '') . '><span>' . $project['post_title'] . '</span></div><div class="pt-category ' . $atts['category_font'] . '"' . Color::has_gradient($atts['category_color'], '') . '><span>' . $project['project_type'] . '</span></div></div>
			'; 
		} else if($atts['title_visibility'] == 'title') {
			$title = '
				<div class="post-title ' . $atts['title_font'] . '"><div class="pt-title"' . Color::has_gradient($atts['title_color'], '') . '><span>' . $project['post_title'] . '</span></div></div>
			'; 
		} else if($atts['title_visibility'] == 'category') {
			$title = '
				<div class="post-title ' . $atts['title_font'] . '"><div class="pt-category ' . $atts['category_font'] . '"' . Color::has_gradient($atts['category_color'], '') . '><span>' . $project['project_type'] . '</span></div></div>
			'; 
		}
		// link title if below
		if(false !== strpos($atts['title_position'], 'below')) {
			$title = '<a class="pg-title-link pg-link" href="' . $project['permalink'] . '" title="' . $project['post_title'] . '">' . $title . '</a>';
		}
		// return
		return $title;
	}

	// -----------------------------------------
	// get title and corner radius css
	// -----------------------------------------

	public function title_corner_css($id, $values, $styles) {
		// extract options
		extract( shortcode_atts(
			array(
				'corner_radius'				=> 0,
				'title_position'			=> 'below',
				'title_padding'				=> '1rem',
				'title_color'				=> '#000000',
				'title_fontsize'			=> '16px',
				'title_text_transform'		=> 'none',
				'category_color'			=> '#999999',
				'category_fontsize'			=> '14px',
				'category_text_transform'	=> 'none',
				'category_padding_top'		=> '0.4444444444444444rem',
			), $values['options'])
		);
		// title padding
		$title_css = $this->title_padding($title_position, $title_padding);
		// add to css
		$styles['css'] .= '
			#content-holder #' . $id . ' .thumb .post-title { 
				' . $title_css . '
			}
			#' . $id . ' .thumb-inner {
				border-radius: ' . $corner_radius . ';
			}
			#' . $id . ' .thumb .post-title .pt-title span,
			#' . $id . ' .thumb .post-title a .pt-title span {
				font-size: ' . $title_fontsize . ';
				text-transform: ' . $title_text_transform . ';
				' . Color::css($title_color, self::$is_editor) . '
			}
			#' . $id . ' .thumb .post-title .pt-category,
			#' . $id . ' .thumb .post-title a .pt-category {
				padding-top: ' . $category_padding_top . ';
			}
			#' . $id . ' .thumb .post-title .pt-category span,
			#' . $id . ' .thumb .post-title a .pt-category span {
				font-size: ' . $category_fontsize . ';
				text-transform: ' . $category_text_transform . ';
				' . Color::css($category_color, self::$is_editor) . '
			}
		';
		// mobile title options
		$selector = '[data-breakpoint="##breakpoint##"] #content-holder #' . $id . ' .thumb';
		$styles = Styles::css($selector . ' .thumb-inner', 'corner_radius', array('border-radius'), $values['options'], false, false, $styles);
		$styles = Styles::css($selector . ' .post-title .pt-title span, ' . $selector . ' .post-tile a .pt-title', 'title_fontsize', array('font-size'), $values['options'], false, false, $styles);
		$styles = Styles::css($selector . ' .post-title .pt-category span, ' . $selector . ' .post-tile a .pt-category', 'category_fontsize', array('font-size'), $values['options'], false, false, $styles);
		$styles = Styles::css($selector . ' .post-title .pt-category, ' . $selector . ' .post-tile a .pt-category', 'category_padding_top', array('padding-top'), $values['options'], false, false, $styles);
		// iterate breakpoints
		$breakpoints = Get::breakpoints(false);
		foreach ($breakpoints as $breakpoint => $width) {
			if(isset($values['options']['title_padding_' . $breakpoint])) {
				$styles['mobile_css'][$breakpoint] .= $selector . ' .post-title {' . $this->title_padding($title_position, $values['options']['title_padding_' . $breakpoint]) . '}';
			}
			if(!empty($styles['mobile_css'][$breakpoint])) {
				if(self::$is_editor) {
					$styles['css'] .= str_replace('##breakpoint##', $breakpoint, $styles['mobile_css'][$breakpoint]);
				} else {
					$styles['css'] .= '@media screen' . $width['min'] . $width['max'] . ' { ' . str_replace('[data-breakpoint="##breakpoint##"] ', '', $styles['mobile_css'][$breakpoint]) . '}';
				}
			}
		}
		// return styles
		return $styles;
	}

	// -----------------------------------------
	// get title padding
	// -----------------------------------------

	public function title_padding($pos, $val) {
		if(strpos($pos, 'below') === false) {
			return 'padding: ' . $val . ';';
		} else {
			return 'padding: ' . $val . ' 0 0 0;';
		}
	}

	// -----------------------------------------
	// get masonry items
	// -----------------------------------------

	public function masonry_items($id, $project, $atts, $is_editor, $lazy_load_class) {
		if(empty($project['image']['width'])) {
			$project['image']['width'] = 6;
		}
		// title and category
		$title = $this->title($atts, $project);
		// show post settings link on admin
		if(!$is_editor) {
			$thumb_inner = '<a href="' . $project['permalink'] . '" class="pg-link">' . $this->thumb_inner($id, $atts['global_hover_options'], $project, true, $title, $atts['title_position']);
		} else {
			$thumb_inner = $this->thumb_inner($id, $atts['global_hover_options'], $project, false, $title, $atts['title_position']);
		}
		// category classes
		$category_classes = '';
		if(is_array($project['categories']) && !empty($project['categories'])) {
			$category_classes = ' ';
			foreach ($project['categories'] as $categories => $cat_id) {
				$category_classes .= 'cat-' . $cat_id . ' ';
			}
		}
		// video thumbnail hover
		$video_hover = '';
		if(isset($atts['global_hover_options']['hover_bg_type']) && $atts['global_hover_options']['hover_bg_type'] == 'vid' || isset($project['thumb_hover']['hover_bg_type']) && $project['thumb_hover']['hover_bg_type'] == 'vid') {
			$video_hover = ' video-hover';
		}
		// masonry items open
		$masonry_item = '<div id="project-' . $project['post_id'] . '" class="masonry-item thumb masonry-' . $id . '-item ' . $atts['title_position'] . '' . $category_classes . '' . $video_hover . '' . $lazy_load_class . '" data-xl-width="' . $project['image']['grid_width'] . '" data-sm-width="6" data-xs-width="12">';
		// add thumb inner
		$masonry_item .= $thumb_inner;
		// masonry items close
		$masonry_item .= '</div>';
		// return item
		return $masonry_item;
	}

	// -----------------------------------------
	// get thumb inner
	// -----------------------------------------

	public function thumb_inner($id, $global_hover_options, $project, $is_frontend, $title, $title_position) {
		// vars
		$post_settings = '';
		if(!$is_frontend) {
			$post_settings = '<a class="post-settings-grid click-handler no-ep" data-handler="sidebar" data-sidebar="settings" data-content-id="' . $id . '" data-post-id="' . $project['post_id'] . '" data-ps-mode="grid" data-post-type="project">' . Get::svg('admin', 'settings') . '</a>';
		}
		// define output
		$output = '
			<div class="thumb-inner">
				' . Customize::$setting['thumbhover']->html($global_hover_options, $project, $is_frontend) . '
				' . $post_settings . '
				<img src="' . $project['image']['src'] . '" width="' . $project['image']['width'] . '" height="' . $project['image']['height'] . '" alt="' . $project['post_title'] . '">
		';
		// if title is below close the thumb inner link before the title. if title is above, include the title within thumb inner a tag. Note: the title only contains a tags if below
		if(false !== strpos($title_position, 'below')) {
			$output .= '</div></a>' . $title;
		} else {
			$output .= $title . '</div></a>';
		}
		// output
		return $output;
	}
}

// instance
Editor::$modules['portfoliogrid'] = new PortfoliogridModule;
?>