<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Helper\Basic;

// -----------------------------------------
// module
// -----------------------------------------

class ParagraphModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// get content
		$content = $values['content']['xl'];
		// add paragraph to content
		$this->module['html'] = '<div class="is-content wysiwyg-editor wysiwyg-edit" data-wysiwyg-id="' . $id . '">' . $content  . '</div>';
		// output
		return $this->module;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// get content
		$content = $values['content']['xl'];
		// define breakpoints
		$breakpoints = array('xl', 'lg', 'md', 'sm', 'xs');
		// vars
		$classes = '';
		$content = '';
		// has other content?
		foreach ($breakpoints as $breakpoint) {
			if(isset($values['content'][$breakpoint]) && !empty($values['content'][$breakpoint])) {
				if($breakpoint != 'xl') {
					$classes .= ' has-' . $breakpoint;
				}
				$content .= '<div data-content-for="' . $breakpoint . '">' . $values['content'][$breakpoint]  . '</div>';
			}
		}
		// add paragraph to content
		$this->module['html'] = '<div class="is-content' . $classes . Basic::has_animate_gradient($values['motions']) . '">' . $content . '</div>';
		// output
		return $this->module;
	}
}

// instance
Editor::$modules['paragraph'] = new ParagraphModule;
?>