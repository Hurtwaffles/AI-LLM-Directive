<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Helper\Basic;
use Semplice\Helper\Color;
use Semplice\Helper\Get;
use Semplice\Helper\Image;
use Semplice\Helper\Masonry;
use Semplice\Editor\Placeholder;

// -----------------------------------------
// module
// -----------------------------------------

class GallerygridModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		// is editor
		self::$is_editor = (NULL == self::$is_editor) ? true : self::$is_editor;
		// module
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// extract options
		extract( shortcode_atts(
			array(
				'col'						=> 4,
				'target'					=> 'lightbox',
				'random'					=> 'disabled',
				'hor_gutter'				=> 30,
				'ver_gutter'				=> 30,
				'corner_radius'				=> 0,
				'mouseover'					=> 'none',
				'mouseover_color'			=> '#000000',
				'mouseover_opacity'			=> 100,
				'title_visibility'			=> 'hidden',
				'title_position'			=> 'center',
				'title_padding'				=> '1rem',
				'title_color'				=> '#000000',
				'title_fontsize'			=> '16px',
				'title_font'				=> 'regular',
				'title_text_transform'		=> 'none',
				'caption_color'				=> '#999999',
				'caption_fontsize'			=> '14px',
				'caption_font'				=> 'regular',
				'caption_text_transform'	=> 'none',
				'caption_padding_top'		=> '0.4444444444444444rem',
				'caption_line_height'		=> '100',
			), $values['options'])
		);
		// get images
		$images = $values['content']['xl'];
		// generate items
		$masonry_items = '';
		// random
		if($random !== 'disabled') {
			$col_array = explode('.', $random);
			$small_col = $col_array[0];
			$big_col   = $col_array[1];
		}
		// index
		$index = 0;
		// get shots
		if(is_array($images) && !empty($images)) {
			foreach ($images as $image) {
				// get image
				$img = Image::get($image, 'full');
				// is image still in library?
				if($img) {
					// mouseover
					if($mouseover == 'color') {
						if(strpos($mouseover_color, '#') !== false) {
							$rgba = Color::hex_to_rgb($mouseover_color);
							$mouseover_html = '<div class="gg-hover" style="background: rgba(' . $rgba['r'] . ', ' . $rgba['g'] . ', ' . $rgba['b'] . ', ' . ($mouseover_opacity / 100) . ');"></div>';
						} else {
							$mouseover_html = '';
						}
					} elseif($mouseover == 'shadow') {
						$mouseover_html = '<div class="gg-hover" style="box-shadow: 0px 0px 50px rgba(0,0,0,' . ($mouseover_opacity / 100) . ');"></div>';
					} else {
						$mouseover_html = '';
					}
					// title and caption visibility
					$title_caption = '';
					if($title_visibility != 'hidden') {
						$title_caption .= '<div class="gg-title-caption" data-title-visibility="' . $title_visibility . '">';
						if($title_visibility == 'both' || $title_visibility == 'title') {
							$title_caption .= '<div class="post-title ' . $title_font . '">' . $img['title'] . '</div>';
						}
						if($title_visibility == 'both' || $title_visibility == 'caption') {
							$title_caption .= '<div class="post-caption ' . $caption_font . '">' . $img['caption'] . '</div>';
						}
						$title_caption .= '</div>';
					}
					// image html
					if($target == 'lightbox') {
						$image = '<a class="semplice-lightbox gallerygrid-image mouseover-' . $mouseover . '"><img class="lightbox-item" src="' . $img['src'] . '" width="' . $img['width'] . '" height="' . $img['height'] . '" caption="' . $img['caption'] . '" alt="' . $img['alt'] . '">' . $mouseover_html . '</a>' . $title_caption;
					} else {
						$image = '<a class="mouseover-' . $mouseover . '"><img src="' . $img['src'] . '" width="' . $img['width'] . '" height="' . $img['height'] . '" alt="' . $img['alt'] . '">' . $mouseover_html . '</a>' . $title_caption;
					}
					if($random !== 'disabled' && $index % 4 == 0 && $index > 0) {
						$col = $big_col;
					} elseif($random !== 'disabled') {
						$col = $small_col;
					}
					// add thumb to holder
					$masonry_items .= '
						<div class="masonry-item thumb masonry-' . $id . '-item" data-xl-width="' . $col . '" data-sm-width="6" data-xs-width="12">
						' . $image . '
						</div>
					';
					// increment index
					$index ++;
				}
			}
			// get masonry
			$this->module['html'] = Masonry::html('gallerygrid', $id, $values['options'], $masonry_items, self::$is_editor, false); //$values['script_execution'] is last normally
		}
		// if there are no images show placeholder
		if(empty($masonry_items)) {
			$this->module['html'] = Placeholder::get('gallerygrid', $id, true, self::$is_editor, false);
		}
		// add to css
		$css = '
			' . Masonry::css($id, $values['options'], $col, self::$is_editor, $hor_gutter, $ver_gutter, false) . '
			#content-holder #' . $id . ' .thumb .post-title { 
				padding: ' . $title_padding . ' 0 0 0;
			}
			#' . $id . ' .thumb img,
			#' . $id . ' .thumb .gg-hover {
				border-radius: ' . $corner_radius . ';
			}
			#' . $id . ' .thumb .post-title {
				color: ' . $title_color . ';
				font-size: ' . $title_fontsize . ';
				text-transform: ' . $title_text_transform . ';
				text-align: ' . $title_position . ';
			}
			#' . $id . ' .thumb .post-caption {
				color: ' . $caption_color . ';
				font-size: ' . $caption_fontsize . ';
				text-transform: ' . $caption_text_transform . ';
				padding-top: ' . $caption_padding_top . ';
				text-align: ' . $title_position . ';
				text-align: ' . $title_position . ';
				line-height: ' . $caption_line_height . '% !important;
			}
		';
		// add mobile css
		$css .= $this->mobile_css($id, $values['options'], Get::breakpoints());
		// add to output
		$this->module['css'] = $css;
		// output
		return $this->module;
	}

	// -----------------------------------------
	// mobile css
	// -----------------------------------------

	public function mobile_css($id, $options, $breakpoints) {
		// vars
		$output = '';
		$atts = array(
			'#content-holder #' . $id . ' .thumb .post-title' => array(
				'title_padding' => 'padding-top',
			),
			'#' . $id . ' .thumb img' => array(
				'corner_radius' => 'border-radius' 
			),
			'#' . $id . ' .thumb .gg-hover' => array(
				'corner_radius' => 'border-radius' 
			),
			'#' . $id . ' .thumb .post-title' => array(
				'title_fontsize' => 'font-size',
			),
			'#' . $id . ' .thumb .post-caption' => array(
				'caption_fontsize' => 'font-size',
				'caption_padding_top' => 'padding-top',
				'caption_line_height' => 'line-height'
			)
		);
		// iterate breaktpoins
		foreach ($breakpoints as $bp => $width) {
			$css = '';
			foreach ($atts as $sel => $css_atts) {
				foreach ($css_atts as $attr => $css_attr) {
					if(isset($options[$attr . '_' . $bp])) {
						$css .= '[data-breakpoint="##breakpoint##"] ' . $sel . '{' . $css_attr . ': ' . $options[$attr . '_' . $bp] . '; }';
					}
				}
			}
			// add to css output
			if(!empty($css)) {
				if(self::$is_editor) {
					$output .= str_replace('##breakpoint##', $bp, $css);
				} else {
					$output .= '@media screen' . $width['min'] . $width['max'] . ' { ' . str_replace('[data-breakpoint="##breakpoint##"] ', '', $css) . '}';
				}
			}
		}
		return $output;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// same as editor
		return $this->editor($id, $values);
	}
}

// instance
Editor::$modules['gallerygrid'] = new GallerygridModule;
?>