<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Helper\Get;
use Semplice\Editor\Placeholder;

// -----------------------------------------
// module
// -----------------------------------------

class YoutubeModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// use video id if there or placeholder
		if(isset($values['options']['thumbnail'])) {
			$this->module['html'] = '
				<div class="smp-youtube is-content">
					<img src="' . $values['options']['thumbnail'] . '">
				</div>
			';
		} else {
			$this->module['html'] = Placeholder::get('youtube', $id, false, true, false);
		}
		// output
		return $this->module;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// values
		extract( shortcode_atts(
			array(
				'embed_mode' => 'thumbnail',
				'thumbnail'  => '',
				'autoplay' 	 => 'off',
				'ratio'		 => '',
				'controls'	 => '',
				'mute'		 => ''
			), $values['options'])
		);
		// vars
		$output = '';
		$css = '';
		$content = '';
		$controls = ($controls == 'hidden') ? '&controls=0' : '';
		$mute = ($mute == 'yes') ? '&mute=1' : '';
		// get video id
		$video_id = $this->video_id($values['content']['xl']);
		// autoplay
		if($autoplay == 'on' || $autoplay == 'loop') {
			// reset embed mode
			$embed_mode = 'video';
			// autoplay
			$props = '&autoplay=1&mute=1';
			$autoplay = ($autoplay == 'loop') ? $props . '&loop=1&playlist=' . $video_id : $props;
			// reset mute
			$mute = '';
		} else if($embed_mode == 'thumbnail') {
			$autoplay = '&autoplay=1';
		} else {
			$autoplay = '';
		}
		// is empty?
		if($video_id) {
			// embed url
			$embed_url = 'https://www.youtube.com/embed/' . $video_id . '?iv_load_policy=3&rel=0&modestbranding=1&playsinline=1' . $autoplay . $controls . $mute . '" title="YouTube video player';
			// has custom aspect ratio
			if(!empty($ratio)) {
				// eleminate any spaces
				$ratio = str_replace(' ', '', $ratio);
				// make array
				$ratio = explode(':', $ratio);
				// add padding to css
				$css .= 'padding-bottom: ' . ($ratio[1] / $ratio[0] * 100) . '%;';
			}
			// content
			if($embed_mode != 'thumbnail') {
				$content .= '<iframe src="' . $embed_url . '" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>';
			} else {
				$css .= 'background-image: url(' . $thumbnail . '); background-size: cover;';
				$content .= '<button>' . Get::svg('frontend', 'embed/youtube') . '</button>';
			}
			// open output
			$output = '
				<div class="smp-youtube is-content" data-embed-mode="' . $embed_mode . '" data-embed-url="' . $embed_url . '">
					<div class="responsive-video"' . ((!empty($css)) ? 'style="' . $css . '"' : '') . '>
						' . $content . '
					</div>
				</div>
			';
		} else {
			$output .= Placeholder::get('oembed', $id, false, false, false);
		}
		// add to output
		$this->module['html'] = $output;
		// output
		return $this->module;
	}

	// -----------------------------------------
	// get video id
	// -----------------------------------------

	public function video_id($url) {
		$video_id = explode("?v=", $url);
		return $video_id[1];
	}
}

// instance
Editor::$modules['youtube'] = new YoutubeModule;
?>