<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Editor\Placeholder;

// -----------------------------------------
// module
// -----------------------------------------

class EmbedModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// get label
		$label = (isset($values['options']) && isset($values['options']['label'])) ? $values['options']['label'] : true;
		// get placeholder
		$this->module['html'] = Placeholder::get('oembed', $id, false, true, $label);
		// output
		return $this->module;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// values
		extract( shortcode_atts(
			array(
				'type'	=> 'video',
				'ratio'  => '',
			), $values['options'])
		);
		// define output
		$padding = '';
		// get content
		$content = wp_oembed_get($values['content']['xl']);
		// is empty?
		if(!empty($content) && $content) {
			// aspect ratio if video
			if($type == 'video') {
				// has custom aspect ratio
				if(!empty($ratio)) {
					// eleminate any spaces
					$ratio = str_replace(' ', '', $ratio);
					// make array
					$ratio = explode(':', $ratio);
					// padding
					$padding = ' style="padding-bottom: ' . ($ratio[1] / $ratio[0] * 100) . '%"';
				}
				$this->module['html'] = '<div class="smp-embed is-content"><div class="responsive-video"' . $padding . '>' . $content . '</div></div>';
			} else {
				$this->module['html'] = '<div class="smp-embed is-content">' . $content . '</div>';
			}
		} else {
			$this->module['html'] = Placeholder::get('oembed', $id, false, false, false);
		}
		// output
		return $this->module;
	}
}

// instance
Editor::$modules['oembed'] = new EmbedModule;
?>