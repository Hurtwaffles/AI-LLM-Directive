<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Helper\Color;
use Semplice\Helper\Image;
use Semplice\Helper\Get;

// -----------------------------------------
// module
// -----------------------------------------

class MarqueeModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		$output = array(
			'html' => '',
			'css'  => '',
		);
		// extract options
		extract( shortcode_atts(
			array(
				'direction'		=> 'ltr',
				'mode'			=> 'text',
				'speed'			=> 200,
				'clones'		=> 3,
				'text'			=> 'SEMPLICE MARQUEE &mdash; CLICK TO EDIT ME',
				'color'			=> '#000000',
				'font'			=> 'inter_semibold',
				'fontsize'		=> '3rem',
				'lineheight'	=> '4rem',
				'margin_right'	=> '1rem',
				'corner_radius' => '0rem',
				'text_transform'=> 'none',
				'letter_spacing'=> '0rem',
				'width'			=> 'original',
				'custom_width'	=> 100,
			),$values['options'])
		);
		// links
		$links = isset($values['links']) ? $values['links'] : false;
		// has gradient
		$has_gradient = ($mode == 'text') ? $has_gradient = Color::has_gradient($color, '') : '';
		// mouseover
		$mouseover = $this->mouseover($id, $values['options']);
		// start output html
		$output['html'] = '<div class="is-content semplice-marquee' . (($mouseover) ? ' marquee-mouseover' : '') . '"><div class="semplice-marquee-inner" data-direction="' . $direction . '" data-options=\'{"direction": "' . $direction . '", "speed": ' . json_encode($this->speed($speed, $values['options'])) . ', "mode": "' . $mode . '", "mouseover": ' . json_encode($mouseover) . ' }\' data-font="' . $font . '"' . $has_gradient . '>';
		// add content by mode
		$content = $text;
		// spacing prefix
		$spacingPrefix = 'margin-right';
		if($direction == 'rtl') {
			$spacingPrefix = 'margin-left';
		}
		// mode
		if($mode == 'image') {
			// get images
			$images = $values['content']['xl'];
			if(is_array($images)) {
				$content = '';
				foreach($images as $image) {
					// get img
					$img = Image::get($image, 'full');
					if($img) {
						$img = '<img src="' . $img['src'] . '" alt="' . $img['alt'] . '" caption="' . $img['caption'] . '"/>';
						$url = false;
						// has link?
						if($links && isset($links[$image])) {
							// vars
							$link = $links[$image];
							$link_type = isset($link['type']) ? $link['type'] : 'url';
							// has link?
							if($link_type != 'url' || $link_type == 'url' && isset($link['url']) && !empty($link['url'])) {
								$url = '<a href="' . $this->url($link, 'url') . '" target="' . ((isset($link['target'])) ? $link['target'] : '_blank') . '">';
							}
						}
						// add url
						$content .= ($url) ? $url . $img . '</a>' : $img;
					}
				}
			}
			// output css
			if($width == 'custom') {
				$custom_width = 'width: ' . $custom_width . '%;';
			} else {
				$custom_width = '';
			}
			$output['css'] .= '
				#content-holder #' . $id . ' .semplice-marquee-image img { border-radius: ' . $corner_radius . '; }
				#content-holder #' . $id . ' .semplice-marquee-image img, #content-holder #' . $id . ' .semplice-marquee-image a { ' . $spacingPrefix . ': ' . $margin_right . ';' . $custom_width . '}
			';
		} else {
			// css
			$output['css'] .= '
				#content-holder #' . $id . ' .semplice-marquee-text {
					' . Color::css($color, self::$is_editor) . '
					font-size: ' . $fontsize . ';
					line-height: ' . $lineheight . ';
					' . $spacingPrefix . ': ' . $margin_right . ';
					text-transform: ' . $text_transform . ';
					letter-spacing: ' . $letter_spacing . ';
				}
			';
		}
		// get breakpoint css
		$output['css'] .= $this->breakpoint_css($values['options'], '[data-breakpoint="##breakpoint##"] #content-holder #' . $id, $mode, $margin_right, $spacingPrefix);
		// has content?
		if(strlen($content) === 0) {
			$mode = 'text';
			$content = 'SEMPLICE MARQUEE &mdash; CLICK TO EDIT ME';
		}
		// clones for the frontend animation
		$clones = intval($clones);
		for($i=1; $i<=$clones; $i++) {
			$output['html'] .= '<span class="semplice-marquee-content semplice-marquee-' . $mode . '">' . $content . '</span>';
		}
		// end output html
		$output['html'] .= '</div></div>';
		// add to html output
		$this->module['html'] = $output['html'];
		// add to css output
		$this->module['css'] = $output['css'];
		// return
		return $this->module;
	}

	// -----------------------------------------
	// output fronend
	// -----------------------------------------

	public function frontend($id, $values) {
		return $this->editor($id, $values);
	}

	// -----------------------------------------
	// breakpoint css
	// -----------------------------------------

	public function breakpoint_css($styles, $selector, $mode, $margin_right, $spacingPrefix) {
		// output css
		$output_css = '';
		// get breakpoints
		$breakpoints = Get::breakpoints(false);
		// iterate breakpoints
		foreach ($breakpoints as $breakpoint => $width) {
			// css
			$css = '';
			// spacing
			if(isset($styles['margin_right_' . $breakpoint])) {
				$spacing = $styles['margin_right_' . $breakpoint];
			} else {
				$spacing = $margin_right;
			}
			// mode
			if($mode == 'image') {
				// margin right
				$css .= $selector . ' .semplice-marquee-image img { ' . $spacingPrefix . ': ' . $spacing . '; }';
				// image width
				if(isset($styles['width']) && $styles['width'] == 'custom' && isset($styles['custom_width_' . $breakpoint])) {
					$css .= $selector . ' .semplice-marquee-image img { width: ' . $styles['custom_width_' . $breakpoint] . '%; }';
				}
			} else if($mode == 'text') {
				// margin right
				$css .= $selector . ' .semplice-marquee-text { ' . $spacingPrefix . ': ' . $spacing . '; }';
				// font size
				if(isset($styles['fontsize_' . $breakpoint])) {
					$css .= $selector . ' .semplice-marquee-text { font-size: ' . $styles['fontsize_' . $breakpoint] . '; }';
				}
				// line height
				if(isset($styles['lineheight_' . $breakpoint])) {
					$css .= $selector . ' .semplice-marquee-text { line-height: ' . $styles['lineheight_' . $breakpoint] . '; }';
				}
				// letter spacing
				if(isset($styles['letter_spacing_' . $breakpoint])) {
					$css .= $selector . ' .semplice-marquee-text { letter-spacing: ' . $styles['letter_spacing_' . $breakpoint] . '; }';
				}
			}
			// add to css output
			if(!empty($css)) {
				if(self::$is_editor) {
					$output_css .= str_replace('##breakpoint##', $breakpoint, $css);
				} else {
					$output_css .= '@media screen' . $width['min'] . $width['max'] . ' { ' . str_replace('[data-breakpoint="##breakpoint##"] ', '', $css) . '}';
				}
			}
		}
		// return
		return $output_css;
	}

	// -----------------------------------------
	// speed
	// -----------------------------------------

	public function speed($speed, $options) {
		// speed
		$speed = array(
			'xl' => $speed,
			'lg' => $speed,
			'md' => $speed,
			'sm' => $speed,
			'xs' => $speed
		);
		// get breakpoints
		$breakpoints = Get::breakpoints(false);
		// iterate breakpoints
		foreach ($breakpoints as $breakpoint => $width) {
			if(isset($options['speed_' . $breakpoint])) {
				$speed[$breakpoint] = $options['speed_' . $breakpoint];
			}
		}
		// ret
		return $speed;
	}

	// ----------------------------------------
	// get url
	// ----------------------------------------

	public function url($link, $default) {
		// vars
		$type = (isset($link['type'])) ? $link['type'] : $default;
		$url = home_url();
		// get url
		if($type != 'url' && isset($link[$type])) {
			$url = get_permalink($link[$type]);
		} else if($type == 'url' && isset($link['url'])) {
			$url = $link['url'];
		}
		return $url;
	}

	// ----------------------------------------
	// mouseover
	// ----------------------------------------

	public function mouseover($id, $options) {
		$prefix = 'mouseover_';
		// has mouseover enabled?
		if(isset($options['mouseover']) && $options['mouseover'] == 'active' && !self::$is_editor) {
			$mouseover = array(
				'timescale' => .3,
				'opacity' => .3
			);
			foreach($mouseover as $attr => $val) {
				if(isset($options[$prefix . $attr])) {
					$mouseover[$attr] = $options[$prefix . $attr];
				}
			}
			return $mouseover;
		} else {
			return false;
		}
	}
}

// instance
Editor::$modules['marquee'] = new MarqueeModule;
?>