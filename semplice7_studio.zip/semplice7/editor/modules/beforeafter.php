<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Editor\Placeholder;
use Semplice\Helper\Basic;
use Semplice\Helper\Get;
use Semplice\Helper\Image;

// -----------------------------------------
// module
// -----------------------------------------

class BeforeAfterModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// extract options
		extract( shortcode_atts(
			array(
				'before' 			=> '',
				'after'  			=> '',
				'start'	 			=> 50,
				'width'  			=> 3,
				'height'			=> 3,
				'stroke'			=> '#ffffff',
				'arrow_spacing'		=> 15,
				'arrow_width'		=> '0.8889rem',
				'direction'			=> 'horizontal',
			), $values['options'])
		);
		// content
		$content = '';
		// before after
		$states = array('before', 'after');
		// bg color
		$bg_color = '#ffffff';
		if(isset($values['options']['background-color'])) {
			$bg_color = $values['options']['background-color'];
		}
		// stroke width
		$stroke_width = 3;
		if(isset($values['options']['stroke-width'])) {
			$stroke_width = $values['options']['stroke-width'];
		}
		// images
		$default = array(
			'before' => array(
				'src' 	   => SEMPLICE_URI . '/assets/images/frontend/beforeafter/before.jpg',
				'alt' 	   => 'Default before image alt',
				'caption' => 'Default before image caption'
			),
			'after' => array(
				'src' 	   => SEMPLICE_URI . '/assets/images/frontend/beforeafter/after.jpg',
				'alt' 	   => 'Default after image alt',
				'caption' => 'Default after image caption'
			)
		);
		$images = array(
			'before' => ($before) ? Image::get($before, 'full') : $default['before'],
			'after'  => ($after) ? Image::get($after, 'full') : $default['after']
		); 
		// output
		$this->module['html'] = '
			<div id="beforeafter-' . $id . '" class="is-content beforeafter" data-direction="' . $direction . '" data-start="' . $start . '">
				<img src="' . $images['before']['src'] . '" data-label="Before" alt="' . $images['before']['alt'] . '" caption="' . $images['before']['caption']  . '" />
				<img src="' . $images['after']['src'] . '" data-label="After" alt="' . $images['after']['alt']  . '" caption="' . $images['after']['caption']  . '" />
			</div>
		';
		// css
		$this->module['css'] = '
			#' . $id . ' [data-ba-direction="horizontal"] .ba-bar, #' . $id . ' .twentytwenty-horizontal .ba-bar { width: ' . $width . 'px; background-color: ' . $bg_color . '; }
			#' . $id . ' [data-ba-direction="horizontal"] .ba-arrow svg path, #' . $id . ' .twentytwenty-horizontal .ba-arrow svg path { stroke-width: ' . $stroke_width . 'px; stroke: ' . $stroke . '; }
			#' . $id . ' [data-ba-direction="horizontal"] .ba-arrow, #' . $id . ' .twentytwenty-horizontal .ba-arrow { width: ' . $arrow_width . ';}
			#' . $id . ' [data-ba-direction="horizontal"] .ba-arrow svg, #' . $id . ' .twentytwenty-horizontal .ba-arrow svg { width: ' . $arrow_width . ';}
			#' . $id . ' [data-ba-direction="horizontal"] [data-ba-arrow-direction="left"], #' . $id . ' .twentytwenty-horizontal [data-ba-arrow-direction="left"] { margin-right: ' . $arrow_spacing . 'px; }
			#' . $id . ' [data-ba-direction="horizontal"] [data-ba-arrow-direction="right"], #' . $id . ' .twentytwenty-horizontal [data-ba-arrow-direction="right"] { margin-left: ' . $arrow_spacing . 'px; }
			#' . $id . ' [data-ba-direction="vertical"] .ba-bar, #' . $id . ' .twentytwenty-vertical .ba-bar { height: ' . $height . 'px; background-color: ' . $bg_color . '; }
			#' . $id . ' [data-ba-direction="vertical"] .ba-arrow svg path, #' . $id . ' .twentytwenty-vertical .ba-arrow svg path { stroke-width: ' . $stroke_width . 'px; stroke: ' . $stroke . '; }
			#' . $id . ' [data-ba-direction="vertical"] [data-ba-arrow-direction="down"], #' . $id . ' .twentytwenty-vertical [data-ba-arrow-direction="down"] { margin-bottom: ' . $arrow_spacing . 'px; }
			#' . $id . ' [data-ba-direction="vertical"] [data-ba-arrow-direction="up"], #' . $id . ' .twentytwenty-vertical [data-ba-arrow-direction="up"] { margin-top: ' . $arrow_spacing . 'px; }
			#' . $id . ' [data-ba-direction="vertical"] .ba-arrow, #' . $id . ' .twentytwenty-vertical .ba-arrow { width: ' . $arrow_width . ';}
			#' . $id . ' [data-ba-direction="vertical"] .ba-arrow svg, #' . $id . ' .twentytwenty-vertical .ba-arrow svg { width: ' . $arrow_width . ';}
		';
		// return
		return $this->module;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// same as editor
		return $this->editor($id, $values);
	}
}

// instance
Editor::$modules['beforeafter'] = new BeforeAfterModule;
?>