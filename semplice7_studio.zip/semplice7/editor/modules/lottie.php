<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Editor\Placeholder;

// -----------------------------------------
// module
// -----------------------------------------

class LottieModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// admin?
		if(self::$is_editor) {
			// get label
			$label = (isset($values['options']) && isset($values['options']['label'])) ? $values['options']['label'] : true;
			// add to html
			$this->module['html'] = '
				<div class="is-content semplice-lottie">
					<div id="' . $id . '_lottie" class="lottie-holder"></div>
				</div>
				' . Placeholder::get('lottie', $id, false, true, $label) . '
			';
		} else {
			// valid lottie
			$is_valid = false;
			// get content
			$content = $values['content']['xl'];
			// get lottie url
			if(isset($content['id'])) {
				$url = wp_get_attachment_url($content['id']);
				// has content + width and height defined?
				if($url && isset($content['width']) && isset($content['height'])) {
					$is_valid = true;
				}
			}
			// is valid lottie?
			if($is_valid) {
				$this->module['html'] = '<div class="is-content semplice-lottie"><div id="' . $id . '_lottie" class="lottie-holder"></div></div>';
			} else {
				$this->module['html'] = Placeholder::get('lottie', false, false, false, false);
			}
		}
		// output
		return $this->module;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		return $this->editor($id, $values);
	}
}

// instance
Editor::$modules['lottie'] = new LottieModule;
?>