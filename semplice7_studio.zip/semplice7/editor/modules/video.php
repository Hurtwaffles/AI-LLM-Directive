<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Editor\Placeholder;
use Semplice\Helper\Get;
use Semplice\Helper\Image;

// -----------------------------------------
// module
// -----------------------------------------

class VideoModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// get label
		$label = (isset($values['options']) && isset($values['options']['label'])) ? $values['options']['label'] : true;
		// get placeholder
		$this->module['html'] = Placeholder::get('video', $id, false, true, $label);
		// output
		return $this->module;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// values
		extract( shortcode_atts(
			array(
				'video_url'				=> '',
				'poster' 	    		=> '',
				'loop' 					=> '',
				'muted'					=> '',
				'autoplay'				=> '',
				'hide_controls'			=> '',
				'cover'					=> '',
			), $values['options'] )
		);
		// get content
		$content = $values['content']['xl'];
		// controls
		$controls = '';
		$controls_class = ' has-controls';
		if($hide_controls == 'on') {
			$controls = ' controls';
			$controls_class = ' hide-controls';
		}
		$controls = ($hide_controls == 'on') ? '' : ' controls';
		// get src
		if(!empty($content)) {
			$src = (is_numeric($content)) ? wp_get_attachment_url($content) : $content;
		} else {
			$src = $video_url;
		}
		// get video type
		$type = Get::video_type($src);
		// poster image
		$poster_css = '';
		$poster_html = '';
		if(!empty($poster)) {
			$poster = Image::get($poster, 'full');
			$poster_css = 'background: transparent url("' . $poster['src'] . '") 50% 50% / cover no-repeat;';
			$poster_html = ' poster="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" ';
		}
		// attributes
		$attributes = array(
			'loop' => $loop,
			'autoplay' => $autoplay,
			'muted' => $muted,
		);
		// define video atts
		$video_atts = ' ';
		foreach ($attributes as $attribute => $value) {
			if($value == 'on') {
				$video_atts .= $attribute . ' ';
			}
		}
		// css
		if(!self::$is_editor) {
			$this->module['css'] = '
				#content-holder #' . $id . ' video {
					' . $poster_css . '
				}
			';
		}
		// autoplay class
		$autoplay_class = ($autoplay == 'on' && $muted == 'on' && $hide_controls == 'on') ? ' smp-autoplay' : '';
		// has source?
		if(!empty($src)) {
			$this->module['html'] = '
				<div class="smp-video is-content' . $controls_class . $autoplay_class . '">
					<video class="video" preload="metadata" ' . $controls . ' webkit-playsinline playsinline' . $poster_html . $video_atts . '>
						<source src="' . $src . '" type="video/' . $type . '">
					</video>
				</div>
			';
		} else {
			$this->module['html'] = Placeholder::get('video', $id, false, false, false);
		}
		// output
		return $this->module;
	}
}

// instance
Editor::$modules['video'] = new VideoModule;
?>