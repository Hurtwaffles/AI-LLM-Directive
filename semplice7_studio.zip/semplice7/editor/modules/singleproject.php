<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Editor\Placeholder;
use Semplice\Admin\Customize;
use Semplice\Helper\PostQueries;
use Semplice\Helper\Get;

// -----------------------------------------
// module
// -----------------------------------------

class SingleprojectModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// output
		$output = array(
			'html' => '',
			'styles'  => array(
				'css' => '',
				'mobile_css' => array(
					'lg' => '',
					'md' => '',
					'sm' => '',
					'xs' => '',
				),
			),
			'postid' => false,
		);
		// extract options
		extract( shortcode_atts(
			array(
				'corner_radius'				=> 0,
				'title_visibility'			=> 'hidden',
				'title_position'			=> 'below',
				'title_padding'				=> '1rem',
				'title_color'				=> '#000000',
				'title_fontsize'			=> '16px',
				'title_font'				=> 'regular',
				'title_text_transform'		=> 'none',
				'category_color'			=> '#999999',
				'category_fontsize'			=> '14px',
				'category_font'				=> 'regular',
				'category_text_transform'	=> 'none',
				'category_padding_top'		=> '0.4444444444444444rem',
			), $values['options'])
		);
		// get project id
		$project_id = $values['content']['xl'];
		// global hover
		$hover = Get::customize('thumbhover');
		// is new?
		if(empty($project_id) && $project_id != 0) {
			// get posts
			$posts = get_posts(array('posts_per_page' => 1, 'post_type' => 'project', 'order' => 'ASC'));
			// get first post if there
			if(is_array($posts) && !empty($posts) && isset($posts[0])) {
				$project_id = $posts[0]->ID;
				$output['postid'] = $project_id;
			}
		}
		// get project
		$projects = PostQueries::get_projects(array($project_id), false, 1, 0, false, 'draft,publish');
		// title atts
		$atts = array(
			'title_visibility' => $title_visibility,
			'title_position' => $title_position,
			'category_font' => $category_font,
			'category_color' => $category_color,
			'title_font' => $title_font,
			'title_color' => $title_color
		);
		// show project or placeholder if empty
		if(isset($projects) && is_array($projects) && !empty($projects)) {
			$project = $projects[0];
			// video thumbnail hover
			$video_hover = '';
			if(isset($hover['hover_bg_type']) && $hover['hover_bg_type'] == 'vid' || isset($project['thumb_hover']['hover_bg_type']) && $project['thumb_hover']['hover_bg_type'] == 'vid') {
				$video_hover = ' video-hover';
			}
			// thumb hover css if custom thumb hover is set
			if(isset($project['thumb_hover'])) {
				$output['styles']['css'] .= Customize::$setting['thumbhover']->css('project-' . $project['post_id'], $project['thumb_hover'], false, '#content-holder [data-module="singleproject"]', false);
				$hover = $project['thumb_hover'];
			}
			$output['html'] = '
				<div id="project-' . $project['post_id'] . '" class="is-content thumb' . $video_hover . ' ' . $title_position . '">
					<div class="thumb-inner">
							' . Customize::$setting['thumbhover']->html($hover, $project, true) . '
							<img class="sp-thumbnail" src="' . $project['image']['src'] . '" width="' . $project['image']['width'] . '" height="' . $project['image']['height'] . '" alt="' . $project['post_title'] . '">
					</div>
					' . Editor::$modules['portfoliogrid']->title($atts, $project) . '
				</div>
			';
			// wrap for frontend
			if(!self::$is_editor) {
				$output['html'] = '<a href="' . $project['permalink'] . '" class="pg-link">' . $output['html'] . '</a>';
			}
		} else {
			$output['html'] = Placeholder::get('singleproject', $id, false, true, false);
		}
		// title and corner css
		$output['styles'] = Editor::$modules['portfoliogrid']->title_corner_css($id, $values, $output['styles']);
		// output
		return $this->module = array(
			'html'   => $output['html'],
			'css'  	 => $output['styles']['css'],
			'postid' => $output['postid']
		);
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// same as editor
		return $this->editor($id, $values);
	}
}

// instance
Editor::$modules['singleproject'] = new SingleprojectModule;
?>