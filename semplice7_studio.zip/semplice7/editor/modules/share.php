<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Editor\Placeholder;
use Semplice\Helper\Get;
use Semplice\Helper\Typography;

// -----------------------------------------
// module
// -----------------------------------------

class ShareModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// get options
		extract(shortcode_atts(
			array(
				'type' 					=> 'icons',
				'icon_text_visibility' 	=> 'visible',
			), $values['options'])
		);
		// add html to output
		$this->module['html'] = $this->html($id, $type, $icon_text_visibility);
		// add css to output
		$this->module['css'] = $this->css($id, $values['options']);
		// output
		return $this->module;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// same as editor
		return $this->editor($id, $values);
	}

	// -----------------------------------------
	// html
	// -----------------------------------------

	public function html($id, $type, $text_visibility) {
		// vars
		$html = '<div class="is-content share-box">';
		$html .= ($type == 'icons') ? '<div class="share-icons-wrapper"><p class="' . $text_visibility . '">' . __('Share on', 'semplice') . '</p>' : '';
		$links = array(
			'facebook' => 'href="//facebook.com/sharer/sharer.php?u=' . get_the_permalink() . '" onclick="window.open(this.href,this.title,\'width=500,height=500,top=200px,left=200px\');  return false;" rel="nofollow" target="_blank"',
			'x'		   => 'href="//twitter.com/share?url=' . get_the_permalink() . '" onclick="window.open(this.href,this.title,\'width=500,height=500,top=200px,left=200px\');  return false;" rel="nofollow" target="_blank"',
			'linkedin' => 'href="//linkedin.com/sharing/share-offsite/?url=' . get_the_permalink() . '" onclick="window.open(this.href,this.title,\'width=500,height=500,top=200px,left=200px\');  return false;" rel="nofollow" target="_blank"'
		);
		// networks
		$networks = array('facebook', 'x', 'linkedin');
		// iterate
		foreach($networks as $network) {
			if($type == 'buttons') {
				$html .= '
					<div class="semplice-share first">
						<div class="text">' . ucfirst($network) . '</div>
						<div class="share-button button-' . $network . '">
							<a ' . $links[$network] . '>Share on ' . ucfirst($network) . '</a>
						</div>
					</div>
				';
			} else {
				$html .= '
					<div class="semplice-share-icons first">
						<div class="share-icon icon-' . $network . '">
							<a ' . $links[$network] . '>' . Get::svg('frontend', '/networks/' . $network) . '</a>
						</div>
					</div>
				';
			}
		}
		// close output
		$html .= ($type == 'icons') ? '</div></div>' : '</div>';
		// return
		return $html;
	}

	// -----------------------------------------
	// css
	// -----------------------------------------

	public function css($id, $options) {
		// css
		$css = '';
		// prefix
		$prefix = '#content-holder #' . $id . ' .share-box ';
		// atts
		$attributes = array(
			'button_bg_color' 		=> array('.text', 'background-color'),
			'button_border_color' 	=> array('.text', 'border-color'),
			'button_text_color' 	=> array('.text', 'color'),
			'button_border_radius'	=> array('.text, #content-holder #' . $id . ' .share-box .share-button', 'border-radius'),
			'icon_color' 			=> array('.share-icon svg path', 'fill'),
			'icon_scale'			=> array('.share-icon svg', 'height'),
			'icon_padding'			=> array('.share-icon a', 'padding'),
			'icon_text_color' 		=> array('.share-icons-wrapper p', 'color'),
			'icon_font_size'		=> array('.share-icons-wrapper p', 'font-size'),
			'icon_letter_spacing'	=> array('.share-icons-wrapper p', 'letter-spacing'),
			'icon_text_transform'	=> array('.share-icons-wrapper p', 'text-transform'),
		);
		// iterate $values
		if(!empty($options)) {
			foreach ($options as $option => $value) {
				// is option in attributes?
				if(isset($attributes[$option]) && !empty($value)) {
					// is padding?
					if($option == 'icon_padding') {
						$value = '0 ' . $value;
					}
					$css .= $prefix . $attributes[$option][0] . ' { ' . $attributes[$option][1] . ': ' . $value . '; }'; 
				}
			}
			// font family
			if(!empty($options['icon_font_family'])) {
				$css .= $prefix . ' .share-icons-wrapper p { ' . Typography::get_font_family($options['icon_font_family']) . ' }';
			}
		}
		// margin to compensate letter spacing
		if(!empty($options['icon_letter_spacing'])) {
			// letter spacing
			$letter_spacing = $options['icon_letter_spacing'];
			// margin
			$margin = '-' . $letter_spacing;
			// is negative?
			if(strpos($letter_spacing, '-') !== false) {
				$margin = str_replace('-', '', $letter_spacing);
			}
			$css .= $prefix . ' .share-icons-wrapper p { margin-right: ' . $margin . '; }';
		}
		return $css;
	}
}
// instance
Editor::$modules['share'] = new ShareModule;
?>