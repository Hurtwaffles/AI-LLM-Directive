<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Editor\Placeholder;
use Semplice\Helper\Get;

// -----------------------------------------
// module
// -----------------------------------------

class SocialprofilesModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// extract options
		extract( shortcode_atts(
			array(
				'order'				=> '',
				'profiles'			=> '',
				'distributed'		=> 'default',
				'align'				=> 'center',
				'icon_color'		=> '#000000',
				'icon_scale'		=> '1.4444rem',
				'icon_padding'		=> '0.5556rem'
			), $values['options'])
		);
		// output
		$output = array(
			'html' => '',
			'css' => ''
		);
		// iterate order
		if(is_array($order) && !empty($order)) {
			foreach ($order as $index => $profile) {
				// get username
				$username = 'semplicelabs';
				$color = 'default';
				if(is_array($profiles) && isset($profiles[$profile])) {
					if(isset($profiles[$profile]['username'])) {
						$username = $profiles[$profile]['username'];
					}
					if(isset($profiles[$profile]['color']) && $profiles[$profile]['color'] != 'default' && $profiles[$profile]['color'] != 'transparent') {
						$color = $profiles[$profile]['color'];
						$output['css'] .= '#content-holder #' . $id . ' .socialprofiles .social-profile-' . $profile . ' a svg path { fill: ' . $color . '; }';
					}
					if(isset($profiles[$profile]['hoverColor']) && $profiles[$profile]['hoverColor'] != 'default' && $profiles[$profile]['hoverColor'] != 'transparent') {
						$hoverColor = $profiles[$profile]['hoverColor'];
						$output['css'] .= '.is-frontend #content-holder #' . $id . ' .socialprofiles .social-profile-' . $profile . ' a:hover svg path { fill: ' . $hoverColor . ' !important; }';
					}
				}
				// change twitter to x
				$profile_svg = ($profile == 'twitter') ? 'x' : $profile;
				$output['html'] .= '<li class="social-profile social-profile-' . $profile . '"><a href="' . $this->get_link($profile, $username) . '" target="_blank">' . Get::svg('frontend', 'networks/' . $profile_svg) . '</a></li>';
			}
		} else {
			$output['html'] .= '<li class="empty">' . Get::svg('editor', 'modules/socialprofiles') . '<p>No profiles added.</p></li>';
		}
		// prefix
		$prefix = '#content-holder #' . $id . ' .socialprofiles ';
		// default hover
		$output['css'] .= $prefix . ' .social-profile a:hover svg path { fill: #000000; }'; 
		// css attributes
		$attributes = array(
			'icon_color' 			=> array('.social-profile svg path', 'fill'),
			'icon_color_hover'		=> array('.social-profile a:hover svg path', 'fill'),
			'icon_scale'			=> array('.social-profile svg', 'height'),
			'icon_padding'			=> array('.social-profile a', 'padding'),
		);
		// iterate $values
		if(!empty($values['options'])) {
			foreach ($values['options'] as $option => $value) {
				// is option in attributes?
				if(isset($attributes[$option]) && !empty($value)) {
					// is padding?
					if($option == 'icon_padding') {
						$output['css'] .= $prefix . '{ margin: 0 -' . $value . '; }'; 
						$value = '0 ' . $value;
					}
					$output['css'] .= $prefix . $attributes[$option][0] . ' { ' . $attributes[$option][1] . ': ' . $value . '; }'; 
				}
			}
			// get css
			$output['css'] .= $this->breakpoints_css($values['options'], $attributes, $prefix, $id);
		}
		// define output
		$this->module['css'] = $output['css'];
		$this->module['html'] = '
			<div class="socialprofiles is-content" data-distributed="' . $distributed . '" data-align="' . $align . '">
				<div class="inner">
					<ul>
						' . $output['html'] . '
					</ul>
				</div>
			</div>
		';
		// output
		return $this->module;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// same as editor
		return $this->editor($id, $values);
	}

	// -----------------------------------------
	// breakpoint css
	// -----------------------------------------

	public function breakpoints_css($options, $attributes, $prefix, $id) {
		// css
		$css = '';
		// breakpoints
		$breakpoints = Get::breakpoints(false);
		// iterate breakpoints
		foreach ($breakpoints as $breakpoint => $width) {
			// iterate atts for this breakpoint
			$breakpoint_css = '';
			// change prefix for editor
			if(self::$is_editor) {
				$prefix = '[data-breakpoint="' . $breakpoint . '"] ' . $prefix;
			}
			foreach ($options as $option => $value) {
				if($breakpoint != 'xl' && isset($options[$option . '_' . $breakpoint])) {
					$value = $options[$option . '_' . $breakpoint];
				}
				// is option in attributes?
				if(isset($attributes[$option]) && !empty($value)) {
					// is padding?
					if($option == 'icon_padding') {
						$breakpoint_css .= $prefix . '{ margin: 0 -' . $value . '; }'; 
						$value = '0 ' . $value;
					}
					$breakpoint_css .= $prefix . $attributes[$option][0] . ' { ' . $attributes[$option][1] . ': ' . $value . '; }'; 
				}
			}
			// only add breakpoint if css is not empty
			if(!empty($breakpoint_css)) {
				// breakpoint open
				if(!self::$is_editor) {
					$css .= '@media screen' . $width['min'] . $width['max'] . ' { ' . $breakpoint_css . ' }';	
				} else {
					$css .= $breakpoint_css;
				}
			}
		}
		// ret
		return $css;
	}

	// -----------------------------------------
	// get link
	// -----------------------------------------

	public function get_link($profile, $username) {
		$profiles = Get::social_profiles();
		// get link
		$link = $profiles[$profile]['url'] . $username;
		// exceptions
		if($profile == 'tumblr') {
			$link = 'https://' . $username . '.tumblr.com';
		} else if($profile == 'linkedin') {
			$link = $username;
		} else if($profile == 'youtube') {
			// is new format?
			if(strpos($username, 'youtube.com') !== false) {
				$link = $username;
			}
		}
		// return
		return $link;
	}
}
// instance
Editor::$modules['socialprofiles'] = new SocialprofilesModule;
?>