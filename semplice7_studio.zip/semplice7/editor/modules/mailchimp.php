<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Editor\Placeholder;
use Semplice\Helper\Get;

// -----------------------------------------
// module
// -----------------------------------------

class MailchimpModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// values
		extract( shortcode_atts(
			array(
				'form_action_url'					=> '',
				'fname'								=> 'enabled',
				'placeholder_name'					=> 'First Name',
				'placeholder_email'					=> 'E-Mail Address',
				'alignment'							=> 'left',
				'layout'							=> 'horizontal',
				'spacing'							=> '0rem',
				'input_color'						=> '#000000',
				'input_bg_color'					=> '#f0f0f0',
				'input_holder_color'				=> '#aaaaaa',
				'input_width'						=> '12.77777777777778rem',
				'input_text_align'					=> 'left',
				'input_font_family'					=> 'regular',
				'input_font_size'					=> '1rem',
				'input_padding_ver'					=> '1.111111111111111rem',
				'input_padding_hor'					=> '1.666666666666667rem',
				'input_border_width'				=> 0,
				'input_border_color'				=> '#000000',
				'input_border_radius'				=> 0,			
				'input_mouseover_color'				=> '#000000',
				'input_holder_mouseover_color' 		=> '#666666',
				'input_bg_mouseover_color'			=> '#e9e9e9',
				'input_border_mouseover_color'		=> '#000000',
				'submit_label'						=> 'Subscribe',
				'submit_color'						=> '#000000',
				'submit_font_family'				=> 'regular',
				'submit_font_size'					=> '1rem',
				'submit_letter_spacing'				=> 0,
				'submit_bg_color'					=> '#ffd300',
				'submit_padding_ver'				=> '1.111111111111111rem',
				'submit_padding_hor'				=> '1.666666666666667rem',
				'submit_border_width'				=> 0,
				'submit_border_color'				=> '#000000',
				'submit_border_radius'				=> 0,
				'submit_mouseover_color'			=> '#000000',
				'submit_mouseover_letter_spacing'	=> 0,
				'submit_bg_mouseover_color'			=> '#ffe152',
				'submit_border_mouseover_color'		=> '#000000',
			), $values['options'])
		);
		// add css to output
		$this->module['css'] = $this->breakpoint_css($values['options'], $id);
		// first name
		$fname_input = '<input type="text" value="" name="FNAME" id="mce-FNAME" class="mailchimp-input ' . $input_font_family . '" size="16" placeholder="' . $placeholder_name . '">';
		// always show on editor, only in frontend if selected
		if(!self::$is_editor && $fname == 'disabled') {
			$fname_input = '';
		}
		// add html to output
		$this->module['html'] = '
			<div class="mailchimp-newsletter" data-fname="' . $fname . '">
				<div class="mailchimp-inner is-content">
					<form action="' . $form_action_url . '" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate">
						' . $fname_input . '
						<input type="email" value="" name="EMAIL" id="mce-EMAIL" class="mailchimp-input ' . $input_font_family . '" size="16" placeholder="' . $placeholder_email .'" required>
						<button class="mailchimp-submit-button ' . $submit_font_family . '" type="submit"  value="Subscribe" name="subscribe" id="mc-embedded-subscribe">' . $submit_label . '</button>
					</form>
				</div>
			</div>
		';
		// return
		return $this->module;
	}

	// -----------------------------------------
	// breakpoint css
	// -----------------------------------------

	public function breakpoint_css($options, $id) {
		// vars
		$output = '';
		$sel = '[data-breakpoint="##breakpoint##"] #content-holder #' . $id . ' ';
		$breakpoints = Get::breakpoints(true);
		$css_atts = array(
			'form' => array(
				'target' => 'form',
				'values' => array(
					'layout' => 'flex-direction',
					'alignment' => 'justify-content'
				),
			),
			'input' => array(
				'target' => '.mailchimp-input',
				'values' => array(
					'input_color' => 'color',
					'input_bg_color' => 'background-color',
					'spacing' => 'margin',
					'input_width' => 'width',
					'input_text_align' => 'text-align',
					'input_font_size' => 'font-size',
					'input_padding_ver' => 'padding-top, padding-bottom',
					'input_padding_hor' => 'padding-left, padding-right',
					'input_border_width' => 'border-width',
					'input_border_color' => 'border-color',
					'input_border_radius' => 'border-radius'
				),
			),
			'inputHover' => array(
				'target' => '.mailchimp-input:hover, .mailchimp-input:focus',
				'values' => array(
					'input_mouseover_color' => 'color',
					'input_bg_mouseover_color' => 'background-color',
					'input_border_mouseover_color' => 'border-color'
				),
			),
			'inputPlaceholder' => array(
				'target' => 'input::placeholder',
				'values' => array(
					'input_holder_color' => 'color'
				),
			),
			'inputPlaceholderHover' => array(
				'target' => 'input::hover:placeholder',
				'values' => array(
					'input_holder_mouseover_color' => 'color'
				),
			),
			'submit' => array(
				'target' => 'button',
				'values' => array(
					'submit_width' => 'width',
					'submit_color' => 'color',
					'submit_font_size' => 'font-size',
					'submit_letter_spacing' => 'letter-spacing',
					'submit_bg_color' => 'background-color',
					'submit_border_width' => 'border-width',
					'submit_border_color' => 'border-color',
					'submit_border_radius' => 'border-radius',
					'submit_padding_ver' => 'padding-top, padding-bottom',
					'submit_padding_hor' => 'padding-left, padding-right'
				),
			),
			'submitHover' => array(
				'target' => 'button:hover',
				'values' => array(
					'submit_mouseover_color' => 'color',
					'submit_mouseover_letter_spacing' => 'letter-spacing',
					'submit_bg_mouseover_color' => 'background-color',
					'submit_border_mouseover_color' => 'border-color',
				),
			)
		);
		// iterate breakpoints and atts
		foreach($breakpoints as $breakpoint => $width) {
			// vars
			$bp = ($breakpoint != 'xl') ? '_' . $breakpoint : '';
			$layout = Get::bp_val($options, 'layout', $bp, 'horizontal');
			$css = '';
			$bp_css = '';
			foreach($css_atts as $type => $atts) {
				$css = '';
				foreach($atts['values'] as $option => $attr) {
					$val = false;
					if(isset($options[$option . $bp])) {
						$val = $options[$option . $bp];
					}
					// spacing
					if($option == 'spacing') {
						$val = Get::bp_val($options, 'spacing', $bp, '0rem');
						$val = ($layout == 'vertical') ? '0 0 ' . $val . ' 0' : '0 ' . $val . ' 0 0';
					}
					if($val) {
						// layout
						if($option == 'layout') {
							$val = ($val == 'vertical') ? 'column' : 'row';
						}
						$split_atts = explode(',', $attr);
						// iterate atts if array
						if(count($split_atts) > 1) {
							foreach($split_atts as $attr) {
								$css .= $attr . ': ' . $val . ';';
							}
						} else {
							$css .= $attr . ': ' . $val . ';';
						}
					}
					// width
					if($attr == 'width' && $layout == 'vertical') {
						$css .= $attr . ': 100% !important;';
					}
				}
				if(!empty($css)) {
					$bp_css .= $sel . $atts['target'] . ' {' . $css . '}';
				}
			}
			// add to css output
			if(!empty($bp_css)) {
				if($breakpoint != 'xl') {
					if(self::$is_editor) {
						$output .= str_replace('##breakpoint##', $bp, $bp_css);
					} else {
						$output .= '@media screen' . $width['min'] . $width['max'] . ' { ' . str_replace('[data-breakpoint="##breakpoint##"] ', '', $bp_css) . '}';
					}
				} else {
					$output .= str_replace('[data-breakpoint="##breakpoint##"]', '', $bp_css);
				}
			}
		}
		// return
		return $output;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// same as editor
		return $this->editor($id, $values);
	}
}
// instance
Editor::$modules['mailchimp'] = new MailchimpModule;
?>