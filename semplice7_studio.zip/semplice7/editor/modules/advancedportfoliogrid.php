<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Editor\Placeholder;
use Semplice\Helper\PostQueries;
use Semplice\Helper\Get;
use Semplice\Helper\Color;
use Semplice\Helper\Image;

// -----------------------------------------
// module
// -----------------------------------------

class AdvancedportfoliogridModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// get grid
		$this->module = $this->grid($id, $values);
		// output
		return $this->module;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// get grid
		$this->module = $this->grid($id, $values);
		// output
		return $this->module;
	}

	// -----------------------------------------
	// get grid
	// -----------------------------------------

	public function grid($id, $content) {
		// vars
		$output = array(
			'html' => '',
			'css'  => '',
		);
		$has_posts = true;
		$dir = SEMPLICE_DIR;
		// preset set?
		$preset = 'horizontal-fullscreen';
		if(isset($content['options']['preset']) && !empty($content['options']['preset'])) {
			$preset = $content['options']['preset'];
		}
		// are there posts?
		if(isset($content['options']['order']) && !empty($content['options']['order']) && is_array($content['options']['order'])) {
			// get posts
			$posts = PostQueries::get_apg_posts('content', $content['options']['order']);
			// section element
			$section_element = '';
			// is normal loadout?
			if(isset($content['section_element'])) {
				$section_element = $content['section_element'];
			}
			// grids
			switch($preset) {
				case 'horizontal-fullscreen':
					require $dir . '/editor/apg-grids/horizontal_fullscreen.php';
				break;
				case 'text':
					require $dir . '/editor/apg-grids/text.php';
				break;
				case 'splitscreen':
					require $dir . '/editor/apg-grids/splitscreen.php';
				break;
				case 'table':
					require $dir . '/editor/apg-grids/table.php';
				break;
			}
		} else {
			$output['html'] = Placeholder::get('advancedportfoliogrid', $id, false, self::$is_editor, false);
			// set status to false
			$has_posts = false;
			// set posts
			$posts = false;
		}
		return array(
			'html' 			=> $output['html'],
			'css' 			=> $output['css'],
			'hasProjects' 	=> $has_posts,
			'preset' 		=> $preset,
		);
	}

	// -----------------------------------------
	// breakpoint css
	// -----------------------------------------

	public function breakpoints_css($id, $grid, $options, $gridDir) {
		// css
		$css = '';
		// define atts
		switch($grid) {
			case 'hor-full':
				$selector = '#' . $id . ' .apg-hor-full ';
				$atts = array(
					'hor_full_title_padding' => array('attribute' => 'padding', 'target' => '.apg-post-title'),
					'hor_full_title_fontsize' => array('attribute' => 'font-size', 'target' => '.apg-post-title .title, #' . $id . ' .apg-text-seperator'),
					'hor_full_title_letter_spacing' => array('attribute' => 'letter-spacing', 'target' => '.apg-post-title .title'),
					'hor_full_title_line_height' => array('attribute' => 'line-height', 'target' => '.apg-post-title .title'),
					'hor_full_type_fontsize' => array('attribute' => 'font-size', 'target' => '.apg-post-title .type'),
					'hor_full_type_padding_top' => array('attribute' => 'padding-top', 'target' => '.apg-post-title .type'),
				);
			break;
			case 'text':
				$selector = '#' . $id . ' ';
				$atts = array(
					'text_title_padding' => array('attribute' => 'padding', 'target' => '.apg-text'),
					'text_title_fontsize' => array('attribute' => 'font-size', 'target' => '.apg-text .apg-post-title .title, #' . $id . ' .apg-text-seperator'),
					'text_title_letter_spacing' => array('attribute' => 'letter-spacing', 'target' => '.apg-text .apg-post-title .title'),
					'text_title_line_height' => array('attribute' => 'line-height', 'target' => '.apg-text .apg-post-title .title'),
				);
			break;
			case 'splitscreen':
				$selector = '#' . $id . ' .apg-splitscreen ';
				$atts = array(
					'splitscreen_title_fontsize' => array('attribute' => 'font-size', 'target' => '.apg-post-title .title, #' . $id . ' .apg-text-seperator'),
					'splitscreen_title_letter_spacing' => array('attribute' => 'letter-spacing', 'target' => '.apg-post-title .title'),
					'splitscreen_title_line_height' => array('attribute' => 'line-height', 'target' => '.apg-post-title .title'),
					'splitscreen_type_fontsize' => array('attribute' => 'font-size', 'target' => '.apg-post-title .description'),
					'splitscreen_type_padding_top' => array('attribute' => 'padding-top', 'target' => '.apg-post-title .description'),
					'splitscreen_details_padding_top' => array('attribute' => 'margin-top', 'target' => '.apg-post-title .details'),
					'splitscreen_details_border' => array('attribute' => 'border-width', 'target' => '.apg-post-title .details'),
					'splitscreen_details_border_radius' => array('attribute' => 'border-radius', 'target' => '.apg-post-title .details'),
					'splitscreen_details_fontsize' => array('attribute' => 'font-size', 'target' => '.apg-post-title .details a'),
					'splitscreen_details_letter_spacing' => array('attribute' => 'letter-spacing', 'target' => '.apg-post-title .details a'),
				);
			break;
			case 'table':
				$selector = '#' . $id . ' .apg-table ';
				$atts = array(
					'table_padding_hor' => array('attribute' => array('padding-left', 'padding-right'), 'target' => '.apg-table-head, .apg-table-link'),
					'table_head_padding' => array('attribute' => array('padding-top', 'padding-bottom'), 'target' => '.apg-table-head'),
					'table_head_font_size' => array('attribute' => 'font-size', 'target' => '.apg-table-head'),
					'table_head_letter_spacing' => array('attribute' => 'letter-spacing', 'target' => '.apg-table-head'),
					'table_seperator_width' => array('attribute' => 'border-top-width', 'target' => '.apg-table-link'),
					'table_padding' => array('attribute' => ['padding-top', 'padding-bottom'], 'target' => '.apg-table-link'),
					'table_font_size' => array('attribute' => 'font-size', 'target' => '.apg-table-link'),
					'table_line_height' => array('attribute' => 'line-height', 'target' => '.apg-table-link'),
					'table_letter_spacing' => array('attribute' => 'letter-spacing', 'target' => '.apg-table-link'),
				);
			break;
		}
		// breakpoints
		$breakpoints = Get::breakpoints(false);
		// iterate breakpoints
		foreach ($breakpoints as $breakpoint => $width) {
			// iterate atts for this breakpoint
			$breakpoint_css = '';
			foreach ($atts as $attribute => $data) {
				if(isset($options[$attribute . '_' . $breakpoint])) {
					$value = $options[$attribute . '_' . $breakpoint];
					if (strpos($attribute, 'line_height') !== false && false === strpos($attribute, 'table_')) {
						$value = $value . '%';
					}
					if(is_array($data['attribute'])) {
						$breakpoint_css .= $selector . $data['target'] . ' {';
						foreach($data['attribute'] as $cssAttribute) {
							$breakpoint_css .= $cssAttribute . ': ' . $value . ' !important;';
						}
						$breakpoint_css .= '}';
					} else {
						$breakpoint_css .= $selector . $data['target'] . ' { ' . $data['attribute'] . ': ' . $value . ' !important; }';
					}
				}
			}
			// special cases
			switch($grid) {
				case 'hor-full':
					// arrow size
					if(isset($options['hor_full_arrow_size_' . $breakpoint])) {
						$size = $options['hor_full_arrow_size_' . $breakpoint];
						$sizes = array('small' => 52, 'medium' => 64, 'large' => 78, 'insane' => 100);
						$breakpoint_css .= $selector . '.flickity-prev-next-button { width: ' . $sizes[$size] . 'px; height: ' . $sizes[$size] . 'px; }';
					}
					// offset
					if(isset($options['hor_full_title_offset_' . $breakpoint])) {
						$breakpoint_css .= $selector . '.apg-post-title { margin: ' . $options['hor_full_title_offset_' . $breakpoint] . ' 0 !important;}';
					}
				break;
				case 'text':
					// get paddings
					$paddings = array('ver' => '0.5555555555555556rem', 'hor' => '1rem');
					$prefix = 'text_title_item_padding_';
					foreach ($paddings as $dir => $value) {
						if(isset($options[$prefix . $dir . '_' . $breakpoint])) {
							$paddings[$dir] = $options[$prefix . $dir . '_' . $breakpoint];
						} else if(isset($options[$prefix . $dir])) {
							$paddings[$dir] = $options[$prefix . $dir];
						}
						// divide by 2
						$paddings[$dir] = (floatval(str_replace('rem', '', $paddings[$dir])) / 2) . 'rem';
					}
					// apply paddings
					if($gridDir == 'column-dir') {
						$breakpoint_css .= $selector . ' .apg-text .apg-post-title { padding-top: ' . $paddings['ver'] . '; padding-bottom: ' . $paddings['ver'] . '; }';
					} else {
						$breakpoint_css .= $selector . ' .apg-text .apg-post-text { padding-top: ' . $paddings['ver'] . '; padding-bottom: ' . $paddings['ver'] . '; }';
						$breakpoint_css .= $selector . ' .apg-text .apg-grid-item { padding-left: ' . $paddings['hor'] . '; padding-right: ' . $paddings['hor'] . '; }';
					}
					// negative margin
					$breakpoint_css .= '#' . $id . ' .row-dir { margin: -' . $paddings['ver'] . ' -' . $paddings['hor'] . '; }';
				break;
				case 'splitscreen':
					// padding
					if(isset($options['splitscreen_title_padding_' . $breakpoint])) {
						$breakpoint_css .= $selector . '.apg-post-title { padding: 0rem ' . $options['splitscreen_title_padding_' . $breakpoint] . '!important;}';
					}
					// offset
					if(isset($options['splitscreen_title_offset_' . $breakpoint])) {
						$breakpoint_css .= $selector . '.apg-post-title { margin: ' . $options['splitscreen_title_offset_' . $breakpoint] . ' 0rem !important;}';
					}
					// get button paddings
					$paddings = array('ver' => '0.8888rem', 'hor' => '1.6667rem');
					$prefix = 'splitscreen_details_padding_';
					foreach ($paddings as $dir => $value) {
						if(isset($options[$prefix . $dir . '_' . $breakpoint])) {
							$paddings[$dir] = $options[$prefix . $dir . '_' . $breakpoint];
						} else if(isset($options[$prefix . $dir])) {
							$paddings[$dir] = $options[$prefix . $dir];
						}
					}
					if(!isset($options['splitscreen_details_type']) || isset($options['splitscreen_details_type']) && $options['splitscreen_details_type'] == 'button') {
						$breakpoint_css .= $selector . '.apg-post-title .details a { padding: ' . $paddings['ver'] . ' ' . $paddings['hor'] . ' !important;}';
					}
				break;
				case 'table':
					// column visibility and width
					$content_order = ['date', 'title', 'type', 'client'];
					if(isset($options['content_order'])) {
						$content_order = $options['content_order'];
					}
					$columns = array(
						'date'	=> 1,
						'title'	=> 4,
						'type'	=> 4,
						'client'=> 3
					);
					// grid column css
					$grid_columns_css 	= 'grid-template-columns: ';
					// itearte
					foreach($content_order as $column) {
						// get default column width
						$column_width = $columns[$column];
						// visibility
						$visibility = 'block';
						// first chedck xl visibility
						if(isset($options['table_' . $column . '_visibility']) && $options['table_' . $column . '_visibility'] == 'hidden') {
							$visibility = 'none';
						}
						// now check breapoint visibility
						if(isset($options['table_' . $column . '_visibility_' . $breakpoint]) && $options['table_' . $column . '_visibility_' . $breakpoint] == 'hidden') {
							$visibility = 'none';
						}
						// set visibility
						$breakpoint_css .= $selector . '[data-table-column="' . $column . '"] { display: ' . $visibility . ' !important; }';
						// add co grid column css if visible
						if($visibility == 'block') {
							// get xl width
							if(isset($options['table_' . $column . '_width'])) {
								$column_width = $options['table_' . $column . '_width'];
							}
							// get breakpoint width
							if(isset($options['table_' . $column . '_width_' . $breakpoint])) {
								$column_width = $options['table_' . $column . '_width_' . $breakpoint];
							}
							// add to css
							$grid_columns_css .= 'calc(100% / 12 * ' . $column_width . ') ';
						}							
					}
					// set width
					if($grid_columns_css != 'grid-template-columns: ') {
						$breakpoint_css .= $selector . ' .apg-table-head, ' . $selector . ' .apg-table-link { ' . $grid_columns_css . '; }';
					}						
				break;
			}
			// only add breakpoint if css is not empty
			if(!empty($breakpoint_css)) {
				// breakpoint open
				$css .= '@media screen' . $width['min'] . $width['max'] . ' { ' . $breakpoint_css . ' }';
			}	
		}
		// return
		return $css;
	}

	// -----------------------------------------
	// set custom styles
	// -----------------------------------------

	public function custom_styles($id, $grid, $post, $values) {
		// is editor?
		if(self::$is_editor) {
			// defaults
			if(isset($values['background-color']) && $values['background-color']) {
				$bg_color = $values['background-color'];
			} else {
				$bg_color = 'transparent';
			}
			// thumb
			$upload_visibility = '';
			$thumb_id = 0;
			if(isset($values['thumbnail']) && $values['has_custom_thumb']) {
				$thumb_src = '..' . substr($values['thumbnail'], -12);
				$thumb_id = $values['thumbnail'];
			} else {
				$thumb_src = 'Upload Thumbnail';
				$upload_visibility = ' show-upload';
			}
			// picker id
			$picker_id = 'picker_' . substr(md5(rand()), 0, 9);
			return '
				<div class="apg-custom-styles no-ep">
					<div class="acs-bgcolor attribute">
						<div class="' . $picker_id . '-picker-holder apg-picker-holder"></div>
						<div class="color-picker ' . $picker_id . ' has-tooltip" data-picker-id="' . $picker_id . '" data-holder="' . $picker_id . '" data-show-color="true" data-mode="solid" data-tooltip="BG Color" data-tooltip-settings="top,center,auto">
							<div class="color-preview" style="' . Color::bg_css($bg_color, self::$is_editor, false) . '"></div>
							<input type="text" value="' . $bg_color . '" data-input-type="color" data-gradient="true" data-option-id="option_apgbgcolr" data-type="apg" name="background-color" data-id="' . $id . '" data-target="' . $post['post_id'] . '" data-apg-style="true">
						</div>
					</div>
					<div class="apg-custom-thumbnail" data-default-thumb="' . $post['thumbnail']['src'] . '">
						<div class="apg-thumb-icon apg-thumb-upload has-tooltip" data-id="' . $id . '" data-post-id="' . $post['post_id'] . '" data-thumb-id="' . $thumb_id . '" data-tooltip="BG Image" data-tooltip-settings="top,center,auto">' . Get::svg('editor', 'modules/image') . '</div>
						<div class="apg-upload-holder"><!-- upload holder --></div>
					</div>
				</div>
			';
		}
	}

	// -----------------------------------------
	// get custom options
	// -----------------------------------------

	public function custom_options($post_id, $thumbnail, $options) {
		// output
		$values = array(
			'thumbnail' 		=> $thumbnail,
			'has_custom_thumb' 	=> false,
			'background-color' 	=> false,
			'custom_class' 		=> '',
			'description' 		=> 'You can change this description and the title above by simply editing it.',
			'type' 				=> false,
			'date'				=> '2021',
			'client'			=> 'Semplice',
			'title' 			=> false,
			'link'				=> ''
		);
		// posts set already?
		if(isset($options['posts']) && is_array($options['posts'])) {
			$posts = $options['posts'];
			// is post set?
			if(isset($posts[$post_id]) && is_array($posts[$post_id])) {
				foreach ($values as $attribute => $value) {
					if(isset($posts[$post_id][$attribute])) {
						// is thumbnail?
						if($attribute == 'thumbnail') {
							$img = Image::get($posts[$post_id][$attribute], 'full');
							$values[$attribute] = $img['src'];
							$values['has_custom_thumb'] = true;
						} else if($attribute == 'custom_class') {
							$values[$attribute] = ' ' . $posts[$post_id][$attribute];
						} else {
							$values[$attribute] = $posts[$post_id][$attribute];
						}
					}
				}
			}
		}
		// ret values
		return $values;
	}

	// -----------------------------------------
	// get thumbnail
	// -----------------------------------------

	public function thumbnail($thumbnail, $grid, $id, $post) {
		// no thumbnail?
		if(!$thumbnail && $grid != 'table') {
			// return button
			if(self::$is_editor) {
				return '
					<div class="missing-thumbnail">
						<p>Missing thumbnail for<br />"' . $post['post_title'] . '"</p>
						<button class="apg-thumb-upload no-ep click-handler" data-handler="run" data-action-type="mediaLibrary" data-action="init" data-type="upload" data-upload="apg" data-input-type="upload" data-sub-type="inline" data-upload-type="image" data-video-support="false" data-id="' . $id . '" data-post-id="' . $post['post_id'] . '" data-thumb-id="0">Upload Thumbnail</button>
					</div>';
			} else {
				return '<div class="missing-thumbnail"><p>Missing thumbnail for<br />"' . $post['post_title'] . '"</p></div>';
			}
		} else {
			// return image
			return '<img src="' . $thumbnail . '">';
		}
	}
}

// instance
Editor::$modules['advancedportfoliogrid'] = new AdvancedportfoliogridModule;
?>