<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Editor\Placeholder;

// -----------------------------------------
// module
// -----------------------------------------

class CodeModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// get label
		$label = (isset($values['options']) && isset($values['options']['label'])) ? $values['options']['label'] : true;
		// get placeholder
		$this->module['html'] = Placeholder::get('code', $id, false, true, $label);
		// output
		return $this->module;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// values
		extract( shortcode_atts(
			array(
				'is_video' 	    		=> 'no',
				'is_shortcode'			=> 'no',
			), $values['options'] )
		);
		// get content
		$content = $values['content']['xl'];
		// shortcode & video
		$content = ($is_shortcode == 'yes') ? do_shortcode($content) : $content;
		$content = ($is_video == 'yes') ? '<div class="responsive-video">' . $content . '</div>' : $content;
		// add to html
		$this->module['html'] = '<div class="is-content smp-code">' . $content . '</div>';
		// return
		return $this->module;
	}
}

// instance
Editor::$modules['code'] = new CodeModule;
?>