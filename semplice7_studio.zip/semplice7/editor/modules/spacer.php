<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Editor\Placeholder;
use Semplice\Helper\Get;

// -----------------------------------------
// module
// -----------------------------------------

class SpacerModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// define styles
		$output_css = '';
		// background-color
		if(isset($values['options']['background-color'])) {
			$output_css .= '#content-holder #' . $id . ' .spacer { background: ' . $values['options']['background-color'] . '; }';
		}
		// height
		if(isset($values['options']['height'])) {
			$output_css .= '#content-holder #' . $id . ' .spacer { height: ' . $values['options']['height'] . '; }';
		}
		// get breakpoints
		$breakpoints = Get::breakpoints(false);
		// iterate breakpoints
		foreach ($breakpoints as $breakpoint => $width) {
			// css
			$css = '';
			// align
			if(isset($values['options']['height_' . $breakpoint])) {
				$css .= '[data-breakpoint="##breakpoint##"] #content-holder #' . $id . ' .spacer { height: ' . $values['options']['height_' . $breakpoint] . '; }';
			}			
			// add to css output
			if(!empty($css)) {
				if(self::$is_editor) {
					$output_css .= str_replace('##breakpoint##', $breakpoint, $css);
				} else {
					$output_css .= '@media screen' . $width['min'] . $width['max'] . ' { ' . str_replace('[data-breakpoint="##breakpoint##"] ', '', $css) . '}';
				}
			}
		}
		// define output
		$this->module['css'] = $output_css;
		$this->module['html'] = '
			<div class="spacer-container">
				<div class="is-content">
					<div class="spacer"><!-- horizontal spacer --></div>
				</div>
			</div>
		';
		// output
		return $this->module;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// same as editor
		return $this->editor($id, $values);
	}
}

// instance
Editor::$modules['spacer'] = new SpacerModule;
?>