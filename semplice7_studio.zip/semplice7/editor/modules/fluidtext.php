<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Helper\Basic;
use Semplice\Helper\Get;

// -----------------------------------------
// module
// -----------------------------------------

class FluidtextModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// get content
		$content = $values['content']['xl'];
		// add paragraph to content
		$this->module['html'] = '<div class="is-content wysiwyg-editor wysiwyg-edit" data-wysiwyg-id="' . $id . '">' . $content  . '</div>';
		// add to css
		$this->module['css'] = $this->css($id, $values['options']);
		// output
		return $this->module;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// get content
		$content = $values['content']['xl'];
		// add paragraph to content
		$this->module['html'] = '<div class="is-content' . Basic::has_animate_gradient($values['motions']) . '">' . $content . '</div>';
		// add to css
		$this->module['css'] = $this->css($id, $values['options']);
		// output
		return $this->module;
	}

	// -----------------------------------------
	// get css
	// -----------------------------------------

	public function css($id, $options) {
		// block element
		$block_element = (isset($options['block_element'])) ? $options['block_element'] : 'p';
		// values
		$values = array(
			'min-font-size' => 18,
			'max-font-size' => 72,
			'fluid-font-size' => 20,
			'fluid-line-height' => 160,
			'fluid-letter-spacing' => 0
		);
		// iterate values
		foreach ($values as $attribute => $val) {
			// has value?
			$val = (isset($options[$attribute])) ? $options[$attribute] : $val;
			// units
			if($attribute == 'fluid-font-size') {
				$values[$attribute] = ($val / 10) . 'vw';
			} else if($attribute == 'fluid-line-height') {
				$values[$attribute] = $val . '%';
			} else if(!empty($val)) {
				$values[$attribute] = ($val / 18) . 'rem';
			}
		}
		// add to css
		$css = '
			#' . $id . ' .is-content ' . $block_element . ' {
				font-size: clamp(' . $values['min-font-size'] . ', ' . $values['fluid-font-size'] . ', ' . $values['max-font-size'] . ') !important;
				line-height: ' . $values['fluid-line-height'] . ' !important;
				letter-spacing: ' . $values['fluid-letter-spacing'] . ' !important;
				margin-bottom: calc(' . $values['fluid-font-size'] . ' * ' . (intval($values['fluid-line-height']) / 100) . ') !important;
			}
			#' . $id . ' .is-content ' . $block_element . ':last-child {
				margin-bottom: 0px !important;
			}
		';
		// line height and letter spacing for breakpoints on frontend
		if(!self::$is_editor) {
			$breakpoints = Get::breakpoints(false);
			foreach ($breakpoints as $breakpoint => $width) {
				$bp_css = '';
				$bp = '_' . $breakpoint;
				// line-height
				if(isset($options['fluid-line-height' . $bp])) {
					$bp_css .= '
						line-height: ' . $options['fluid-line-height' . $bp] . '% !important;
						margin-bottom: calc(' . $values['fluid-font-size'] . ' * ' . (intval($options['fluid-line-height' . $bp]) / 100) . ') !important;
					';
				}
				// letter spacing
				if(isset($options['fluid-letter-spacing' . $bp])) {
					$bp_css .= '
						letter-spacing: ' . (floatval($options['fluid-letter-spacing' . $bp]) / 18) . 'rem !important;
					';
				}
				// add to css output
				$css .= (!empty($bp_css)) ? '@media screen' . $width['min'] . $width['max'] . ' { #' . $id . ' .is-content ' . $block_element . ' { ' . $bp_css . ' }}' : '';
			}
		}
		// return
		return $css;
	}
}

// instance
Editor::$modules['fluidtext'] = new FluidtextModule;
?>