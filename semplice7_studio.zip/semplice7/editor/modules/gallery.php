<?php

// namespace
namespace Semplice\Editor\Modules;

// use
use Semplice\Editor;
use Semplice\Editor\Placeholder;
use Semplice\Helper\Color;
use Semplice\Helper\Image;
use Semplice\Helper\Get;

// -----------------------------------------
// module
// -----------------------------------------

class GalleryModule extends Editor {

	public $module;

	// -----------------------------------------
	// constructor
	// -----------------------------------------

	public function __construct() {
		$this->module = array(
			'html' => '',
			'css'  => '',
		);
	}

	// -----------------------------------------
	// output editor
	// -----------------------------------------

	public function editor($id, $values) {
		// vars
		$output = '';
		$gallery_output = '';
		$classes = '';
		$slide_classes = '';
		$css = '';
		$videos = array();
		// attributes
		extract( shortcode_atts(
			array(
				'images'				=> '',
				'slide_width'			=> 'grid',
				'slide_width_custom'	=> 100,
				'width'					=> 'grid-width',
				'max_width'				=> 100,
				'height'				=> 'auto',
				'max_height'			=> 75,
				'spacing'				=> '0rem',
				'vertical_align'		=> 'flex-start',
				'freescroll'			=> 'false',
				'cover_mode'			=> 'disabled',
				'cover_height'			=> 100,
				'animation_status'		=> 'enabled',
				'animation'				=> 'sgs-crossfade',
				'radius'				=> '0rem',
				'arrows_visibility'		=> 'true',
				'arrows_shape'			=> 'default',
				'arrows_custom'			=> false,
				'arrows_color'			=> '#ffffff',
				'arrows_bg_color'		=> '#000000',
				'arrows_bg_opacity'		=> 0,
				'pagination_visibility'	=> 'false',
				'pagination_style'		=> 'dots',
				'pagination_color'		=> '#000000',
				'pagination_position'	=> 'below',
				'caption_visibility'	=> 'hidden',
				'caption_color'			=> '#000000',
				'caption_font'			=> 'regular',
				'caption_fontsize'		=> '0.8888888888888889rem',
				'caption_text_transform'=> 'none',
			), $values['options'])
		);
		// freescroll, animations and classes
		$fade = 'false';
		if($freescroll == 'true') {
			$classes .= ' sgs-freescroll';
			$slide_classes = 'sgs-transform ';
		} else if($animation_status == 'disabled') {
			$classes .= ' sgs-nofade';
		} else if($animation == 'sgs-crossfade') {
			$classes .= ' sgs-crossfade';
		} else if($animation == 'sgs-slide') {
			$slide_classes = 'sgs-transform ';
		}
		// arrow color
		if($arrows_bg_color != 'transparent') {
			$arrow_bg_color = Color::hex_to_rgb($arrows_bg_color);
			$arrow_bg_color = 'rgba(' . $arrow_bg_color['r'] . ', ' . $arrow_bg_color['g'] . ', ' . $arrow_bg_color['b'] . ', ' . ($arrows_bg_opacity / 100) . ')';
		} else {
			$arrow_bg_color = 'transparent';
		}
		// get content
		$content = $values['content']['xl'];
		if(is_array($content)) {
			$output .= '<div id="gallery-' . $id . '" class="is-content semplice-gallery semplice-gallery ' . $classes . '" data-cover-mode="' . $cover_mode . '">';
			foreach($content as $media) {
				// image
				if(false !== strpos(get_post_mime_type($media), 'image')) {
					// get img
					$img = Image::get($media, 'full');
					// is image still in library?
					if(false !== $img) {						
						$gallery_output .= '
							<div class="sgs-slide ' . $slide_classes . 'sgs-' . $width . ' sgs-slide-width-' . $slide_width . '">
								<img src="' . $img['src'] . '" alt="' . $img['alt'] . '" caption="' . $img['caption'] . '"/>
							</div>
						';
					}
				} else if(false !== strpos(get_post_mime_type($media), 'video')) {
					// get video url
					$src = wp_get_attachment_url($media);
					// caption
					$video_caption = wp_get_attachment_caption($media);
					$video_caption = !empty($video_caption) ? $video_caption : '&nbsp;';
					// get video type
					$type = Get::video_type($src);;
					// is video url?
					if(!empty($src)) {
						$gallery_output .= '
							<div class="sgs-slide ' . $slide_classes . 'sgs-' . $width . ' sgs-slide-width-' . $slide_width . '">
								<video class="video" webkit-playsinline playsinline preload="metadata" muted="muted" loop="loop">
									<source src="' . $src . '" type="video/' . $type . '">
								</video>
								<div class="video-caption">' . $video_caption . '</div>
							</div>
						';
						// add to videos
						$videos[$media] = $src;
					}
				}					
			}
			// add to output
			$output .= $gallery_output;
			$output .= '</div><div class="flickity-meta pagination-' . $pagination_position . ' sgs-pagination-' . $pagination_visibility . '" data-caption-visibility="' . $caption_visibility . '" data-pagination-style="' . $pagination_style . '" data-freescroll="' . $freescroll . '"><div class="flickity-caption" data-font="' . $caption_font . '"></div></div>';
			// add videos
			if(self::$is_editor) {
				$output .= '<div class="videos" data-content=\'' . json_encode($videos) . '\'></div>';
			}
			// custom css for nav and pagination
			$css .= '
				#' . $id . ' .flickity-viewport { border-radius: ' . $radius . '; }
				#' . $id . ' .flickity-prev-next-button .arrow { fill: ' . $arrows_color . ' !important; }
				#' . $id . ' .flickity-page-dots .flickity-page-dot { background: ' . $pagination_color . ' !important; }
				#' . $id . ' .flickity-meta .flickity-caption { color: ' . $caption_color . '; font-size: ' . $caption_fontsize . '; text-transform: ' . $caption_text_transform . '; }
				#' . $id . ' .flickity-button-icon path { fill: ' . $arrows_color . '; }
				#' . $id . ' .flickity-prev-next-button { background-color: ' . $arrow_bg_color . '; }
				' . (($caption_visibility == 'visible') ? '#' . $id . ' .flickity-meta .flickity-caption { display: block; }' : '');
			// css layout options
			$breakpoints = Get::breakpoints(true);
			// iterate breakpoints
			foreach ($breakpoints as $breakpoint => $bp_width) {
				// bp css
				$bp_css = '';
				// bp
				$bp = ($breakpoint == 'xl' ? false : '_' . $breakpoint);
				// selector
				$selector = '[data-breakpoint="##breakpoint##"] #' . $id;
				// is cover mode disabled?
				if($cover_mode == 'disabled') {
					// slide width
					if($slide_width == 'image') {
						$bp_css .= $selector . ' .sgs-slide { width: auto; max-width: 100%; }';
					} else if($slide_width == 'custom') {
						$slide_width_custom_bp = isset($values['options']['slide_width_custom' . $bp]) ? $values['options']['slide_width_custom' . $bp] : $slide_width_custom;
						$bp_css .= $selector . ' .sgs-slide { width: ' . $slide_width_custom_bp . '%; }';
					} else {
						$bp_css .= $selector . ' .sgs-slide { width: 100%; }';
					}
					// max image width (now called custom width in the ep)
					if($width == 'max-width') {
						$max_width_bp = isset($values['options']['max_width' . $bp]) ? $values['options']['max_width' . $bp] : $max_width;
						if($slide_width == 'custom' || $slide_width == 'grid') {
							$bp_css .= $selector . ' .sgs-slide img, ' . $selector . ' .sgs-slide video { width: ' . $max_width_bp . '%; max-width: 100%; }';
						} else if($slide_width == 'image') {
							$bp_css .= $selector . ' .sgs-slide { width: ' . $max_width_bp . '%; }';
							$bp_css .= $selector . ' .sgs-slide img, ' . $selector . ' .sgs-slide video { width: 100%; max-width: 100%; }';
						}
					} else if($width == 'original') {
						$bp_css .= $selector . ' .sgs-slide img, ' . $selector . ' .sgs-slide video { width: auto; max-width: 100%; }';
					} else {
						$bp_css .= $selector . ' .sgs-slide img, ' . $selector . ' .sgs-slide video { width: 100%; max-width: 100%; }';
					}
					// max image height
					if($height == 'max-height') {
						$max_height_bp = isset($values['options']['max_height' . $bp]) ? $values['options']['max_height' . $bp] : $max_height;
						$bp_css .= $selector . ' .sgs-slide img, ' . $selector . ' .sgs-slide video { max-height: ' . $max_height_bp . 'vh; }';
						if($width != 'max-width') {
							$bp_css .= $selector . ' .sgs-slide img, ' . $selector . ' .sgs-slide video { width: auto; }';
						}
					} else {
						$bp_css .= $selector . ' .sgs-slide img, ' . $selector . ' .sgs-slide video { max-height: inherit; }';
					}
					// spacing
					if($slide_width == 'image' || $slide_width == 'custom') {
						$spacing_bp = isset($values['options']['spacing' . $bp]) ? $values['options']['spacing' . $bp] : $spacing;
						$bp_css .= $selector . ' .sgs-slide { margin-right: ' . $spacing_bp . '; }';
					}
					// vertical align
					$align_bp = isset($values['options']['vertical_align' . $bp]) ? $values['options']['vertical_align' . $bp] : $vertical_align;
					$bp_css .= $selector . ' .flickity-slider { display: flex; align-items: ' . $align_bp . '; }';
				} else {
					$cover_height_bp = isset($values['options']['cover_height' . $bp]) ? $values['options']['cover_height' . $bp] : $cover_height;
					$bp_css .= $selector . ' [data-cover-mode="enabled"] { height: ' . $cover_height_bp . 'vh; }';
					// reset width and height
					$bp_css .= $selector . ' .sgs-slide img, ' . $selector . ' .sgs-slide video { width: 100%; max-width: 100%; max-height: inherit; }';
					$bp_css .= $selector . ' .sgs-slide { width: 100%; }';
				}
				// add to css output
				if(!empty($bp_css)) {
					if(self::$is_editor) {
						$css .= str_replace('##breakpoint##', $breakpoint, $bp_css);
					} else {
						$css .= '@media screen' . $bp_width['min'] . $bp_width['max'] . ' { ' . str_replace('[data-breakpoint="##breakpoint##"] ', '', $bp_css) . '}';
					}
				}
			}
		}
		// if there are no images show placeholder
		if(empty($gallery_output)) {
			$output .= Placeholder::get('gallery', $id, true, self::$is_editor, false);
		}
		// save output
		$this->module['html'] = $output;
		$this->module['css'] = $css;
		// return
		return $this->module;
	}

	// -----------------------------------------
	// output frontend
	// -----------------------------------------

	public function frontend($id, $values) {
		// same as editor
		return $this->editor($id, $values);
	}
}

// instance
Editor::$modules['gallery'] = new GalleryModule;
?>